#!/bin/bash
# NerdyBrowser: makes a WireGuard server on a fresh Ubuntu/Debian VPS and prints your phone's config.
# Run as root. Also open UDP port 51820 in your hosting company's firewall.
set -e
[ "$(id -u)" = 0 ] || { echo "Run this as root (sudo -i)"; exit 1; }
PORT=51820
apt-get update -y >/dev/null && apt-get install -y wireguard curl >/dev/null
umask 077; mkdir -p /etc/wireguard; cd /etc/wireguard
IFACE=$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')
IP=$(curl -4 -s https://ifconfig.me || curl -4 -s https://api.ipify.org)
wg genkey | tee server.key | wg pubkey > server.pub
wg genkey | tee phone.key | wg pubkey > phone.pub
wg genpsk > phone.psk
cat > wg0.conf <<CONF
[Interface]
Address = 10.66.66.1/24
ListenPort = $PORT
PrivateKey = $(cat server.key)
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o $IFACE -j MASQUERADE

[Peer]
PublicKey = $(cat phone.pub)
PresharedKey = $(cat phone.psk)
AllowedIPs = 10.66.66.2/32
CONF
echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-wg.conf
sysctl -p /etc/sysctl.d/99-wg.conf >/dev/null
command -v ufw >/dev/null && ufw allow $PORT/udp >/dev/null 2>&1 || true
systemctl enable --now wg-quick@wg0 >/dev/null
echo
echo "=== COPY EVERYTHING BETWEEN THE LINES INTO NerdyBrowser > VPN > Advanced ==="
cat <<CLIENT
[Interface]
PrivateKey = $(cat phone.key)
Address = 10.66.66.2/32
DNS = 1.1.1.1, 1.0.0.1
MTU = 1380

[Peer]
PublicKey = $(cat server.pub)
PresharedKey = $(cat phone.psk)
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = $IP:$PORT
PersistentKeepalive = 25
CLIENT
echo "=== END ==="
