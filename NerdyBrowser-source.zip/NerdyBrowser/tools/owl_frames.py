import asyncio, hashlib, os, re, shutil
from playwright.async_api import async_playwright
exec(open('/tmp/owl/gen.py').read().split('# ---------------------------------------------------------------- keyframe builder')[0])
RES='/home/claude/NerdyBrowser/app/src/main/res'
os.makedirs(RES+'/drawable-nodpi',exist_ok=True)
for f in os.listdir(RES+'/drawable-nodpi'):
    if f.startswith('owl_f'): os.remove(RES+'/drawable-nodpi/'+f)
STEP=0.25; N=int(16/STEP)
html='''<html><head><link rel="stylesheet" href="http://127.0.0.1:8766/css/owl.css"><style>html,body{margin:0;background:transparent}
.b{width:192px;height:192px;display:grid;place-items:center}
.b svg{width:150px;height:150px;filter:drop-shadow(0 0 9px rgba(255,150,60,.8)) drop-shadow(0 4px 8px rgba(255,120,40,.35))}</style></head><body><div class="b" id="b">'''+owl('wd','owl alive')+'</div></body></html>'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':192,'height':192})
        await pg.set_content(html); await pg.wait_for_timeout(500)
        seen={}; order=[]
        for i in range(N):
            t=i*STEP
            await pg.evaluate("t=>document.getAnimations().forEach(a=>{a.pause();a.currentTime=t*1000})",t)
            await pg.wait_for_timeout(40)
            png=await pg.screenshot(omit_background=True,clip={'x':0,'y':0,'width':192,'height':192})
            h=hashlib.md5(png).hexdigest()
            if h not in seen:
                seen[h]=len(seen); open(f'{RES}/drawable-nodpi/owl_f{seen[h]:02d}.png','wb').write(png)
            order.append(seen[h])
        await b.close()
    print('unique',len(seen),'slots',len(order)); print(order)
    open('/tmp/owl/order.txt','w').write(','.join(map(str,order)))
asyncio.run(main())
