import math, re
WWW='/home/claude/NerdyBrowser/app/src/main/assets/www'

# ---------------------------------------------------------------- markup (with wings)
def owl(p, cls):
    return f'''<svg class="{cls}" viewBox="0 0 120 120" aria-hidden="true"><defs>
<linearGradient id="{p}b" x1="0.2" y1="0" x2="0.8" y2="1"><stop offset="0" stop-color="#FFE08A"/><stop offset=".5" stop-color="#FFB02E"/><stop offset="1" stop-color="#F26B2A"/></linearGradient>
<linearGradient id="{p}e" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#E88A1F"/><stop offset="1" stop-color="#B8481C"/></linearGradient>
<linearGradient id="{p}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF9A3C"/><stop offset="1" stop-color="#D2501E"/></linearGradient>
<radialGradient id="{p}w" cx=".38" cy=".32" r=".8"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".7" stop-color="#F1EEF8"/><stop offset="1" stop-color="#C9C3DC"/></radialGradient>
<radialGradient id="{p}p" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="#4B3A8F"/><stop offset="1" stop-color="#150F33"/></radialGradient>
<linearGradient id="{p}k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF7A8A"/><stop offset="1" stop-color="#D81B60"/></linearGradient>
<linearGradient id="{p}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#D81B60" stop-opacity="0"/><stop offset="1" stop-color="#D81B60" stop-opacity=".45"/></linearGradient>
</defs>
<g class="ow-all">
<path class="ow-earL" d="M26 20 L46 30 L36 46 C28 42 24 32 26 20Z" fill="url(#{p}e)"/><path class="ow-earR" d="M94 20 L74 30 L84 46 C92 42 96 32 94 20Z" fill="url(#{p}e)"/>
<path d="M60 20 C32 20 16 38 16 64 C16 90 34 106 60 106 C86 106 104 90 104 64 C104 38 88 20 60 20Z" fill="url(#{p}b)"/>
<path d="M60 20 C32 20 16 38 16 64 C16 90 34 106 60 106 C86 106 104 90 104 64 C104 38 88 20 60 20Z" fill="url(#{p}s)"/>
<ellipse cx="40" cy="36" rx="20" ry="9" transform="rotate(-24 40 36)" fill="#fff" opacity=".35"/>
<g class="ow-eyeL"><circle cx="42" cy="60" r="19" fill="url(#{p}w)" stroke="#1a1238" stroke-width="4"/><g class="ow-pup"><circle cx="45" cy="62" r="9.5" fill="url(#{p}p)"/><circle cx="48.5" cy="58" r="3.2" fill="#fff"/></g></g>
<g class="ow-eyeR"><circle cx="78" cy="60" r="19" fill="url(#{p}w)" stroke="#1a1238" stroke-width="4"/><g class="ow-pup"><circle cx="81" cy="62" r="9.5" fill="url(#{p}p)"/><circle cx="84.5" cy="58" r="3.2" fill="#fff"/></g></g>
<path class="ow-beak" d="M53 75 Q60 72 67 75 L60 92Z" fill="url(#{p}k)"/>
<g class="ow-wL"><path d="M16 72 C3 78 4 102 20 111 C31 107 35 92 31 81 C29 74 22 70 16 72Z" fill="url(#{p}g)" stroke="#B8481C" stroke-width="1.2"/><path d="M13 82 C17 90 20 98 22 106 M20 79 C24 86 26 95 26 103" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="1.8" stroke-linecap="round"/></g>
<g class="ow-wR"><path d="M104 72 C117 78 116 102 100 111 C89 107 85 92 89 81 C91 74 98 70 104 72Z" fill="url(#{p}g)" stroke="#B8481C" stroke-width="1.2"/><path d="M107 82 C103 90 100 98 98 106 M100 79 C96 86 94 95 94 103" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="1.8" stroke-linecap="round"/></g>
</g></svg>'''

# ---------------------------------------------------------------- keyframe builder (time based)
T=16.0
def kf(name, ev, fmt):
    ev=sorted(ev)
    if ev[0][0]>0: ev=[(0,ev[0][1])]+ev
    if ev[-1][0]<T: ev=ev+[(T,ev[0][1])]
    out=[]
    for t,v in ev:
        out.append(f"{t/T*100:.3f}%{{transform:{fmt(v)}}}")
    return f"@keyframes {name}{{"+"".join(out)+"}\n"
tr=lambda v:f"translate({v[0]}px,{v[1]}px)"
sy=lambda v:f"scaleY({v})"
def circle(t0,dur,ccw=False,R=6):
    pts=[(0,-R),(R*.707,-R*.707),(R,0),(R*.707,R*.707),(0,R),(-R*.707,R*.707),(-R,0),(-R*.707,-R*.707),(0,-R)]
    if ccw: pts=[(-x,y) for x,y in pts]
    r=[]
    for i,(x,y) in enumerate(pts): r.append((t0+dur*i/8,(round(x,2),round(y,2))))
    return r
Z=(0,0)
def pup(side):
    cx=6 if side=='L' else -6
    ev=[(0,Z),(1.4,Z)]
    ev+=circle(1.6,2.4)+[(4.5,Z)]                  # slow lazy roll
    ev+=[(4.9,Z),(5.1,(-7,1)),(5.6,(-7,1)),(5.8,(7,-1)),(6.3,(7,-1)),(6.6,Z)]   # quick double take
    ev+=[(8.0,Z)]+circle(8.2,0.9,ccw=True)+[(9.6,Z)]   # fast roll the other way
    ev+=[(10.2,Z),(10.5,(-5,-5)),(11.5,(-5,-5)),(11.8,Z)]  # thinking
    ev+=[(12.0,Z),(12.4,(cx,2)),(13.2,(cx,2)),(13.6,Z)]    # cross eyed
    return ev
def blinks(times,extra=[]):
    ev=[(0,1)]
    for t in times: ev+=[(t,1),(t+.08,.08),(t+.17,.08),(t+.29,1)]
    for t in extra: ev+=[(t,1),(t+.12,.08),(t+.45,.08),(t+.6,1)]
    return ev
BL=[0.9,4.8,7.2,9.8,13.6]
body=[(0,'none'),(10.0,'none'),(10.6,'rotate(-8deg)'),(11.5,'rotate(-8deg)'),(12.0,'none'),
      (12.3,'none'),(12.5,'rotate(3deg)'),(12.75,'rotate(-3deg)'),(13.0,'rotate(3deg)'),(13.25,'none'),
      (14.7,'none'),(15.0,'scale(1.05,.93)'),(15.25,'translateY(-9%) scale(.97,1.05)'),(15.5,'scale(1.04,.95)'),(15.75,'none')]
def ear(side):
    t=5.8 if side=='R' else 9.2
    a=14 if side=='R' else -14
    ev=[(0,'none'),(t-.2,'none'),(t,f'rotate({a}deg)'),(t+.22,f'rotate({-a/3}deg)'),(t+.4,'none'),(12.0,'none'),(12.1,f'rotate({a}deg)'),(12.35,'none')]
    return ev
beak=[(0,'none'),(8.3,'none'),(8.4,'scaleY(.65)'),(8.5,'scaleY(1.05)'),(8.6,'scaleY(.65)'),(8.7,'none'),(12.4,'none'),(12.5,'scaleY(.7)'),(12.6,'none'),(12.7,'scaleY(.7)'),(12.8,'none')]
# wings: a "hi" wave with the right wing while it winks, both flare on the hop
wR=[(0,'none'),(13.7,'none'),(14.0,'rotate(-38deg)'),(14.2,'rotate(-26deg)'),(14.4,'rotate(-40deg)'),(14.6,'rotate(-26deg)'),(14.9,'none'),(15.0,'none'),(15.25,'rotate(26deg)'),(15.6,'none')]
wL=[(0,'none'),(14.9,'none'),(15.25,'rotate(-26deg)'),(15.6,'none'),(3.3,'none')]
wL=sorted(wL)
idf=lambda v:v

AMB=':is(.owl.alive:not([data-s]),.owl.alive[data-s="amb"])'
css=f'''/* ===== NerdyBrowser mascot: the owl. Generated; edit tools/owl_gen.py if you want to change the routine ===== */
.owl{{overflow:visible}}
.owl .ow-all,.owl .ow-earL,.owl .ow-earR,.owl .ow-eyeL,.owl .ow-eyeR,.owl .ow-pup,.owl .ow-beak{{transform-box:fill-box;transform-origin:center}}
.owl .ow-all{{transform-origin:50% 92%}}
.owl .ow-earL{{transform-origin:70% 90%}}
.owl .ow-earR{{transform-origin:30% 90%}}
.owl .ow-beak{{transform-origin:50% 10%}}
.owl .ow-wL,.owl .ow-wR{{transform-box:view-box}}
.owl .ow-wL{{transform-origin:16px 76px}}
.owl .ow-wR{{transform-origin:104px 76px}}
@keyframes ow-glow{{0%,100%{{filter:drop-shadow(0 0 5px color-mix(in srgb,var(--acc2,#f0642f) 38%,transparent)) drop-shadow(0 8px 14px color-mix(in srgb,var(--acc2,#f0642f) 22%,transparent))}}50%{{filter:drop-shadow(0 0 14px color-mix(in srgb,var(--acc2,#f0642f) 78%,transparent)) drop-shadow(0 8px 20px color-mix(in srgb,var(--acc2,#f0642f) 40%,transparent))}}}}
.owlglow{{animation:ow-glow 4.6s ease-in-out infinite}}
'''
css+="@media (prefers-reduced-motion:no-preference){\n"
rules=[('ow-pupL','.ow-eyeL .ow-pup'),('ow-pupR','.ow-eyeR .ow-pup'),('ow-blinkL','.ow-eyeL'),('ow-blinkR','.ow-eyeR'),('ow-body','.ow-all'),('ow-earL','.ow-earL'),('ow-earR','.ow-earR'),('ow-beak','.ow-beak'),('ow-wavR','.ow-wR'),('ow-wavL','.ow-wL')]
for n,sel in rules:
    css+=f"  {AMB} {sel}{{animation:{n} var(--t,16s) var(--dl,0s) ease-in-out infinite}}\n"
css+="}\n"
css+=kf('ow-pupL',pup('L'),tr)+kf('ow-pupR',pup('R'),tr)
css+=kf('ow-blinkL',blinks(BL),sy)+kf('ow-blinkR',blinks(BL,[13.9]),sy)
css+=kf('ow-body',body,idf)+kf('ow-earL',ear('L'),idf)+kf('ow-earR',ear('R'),idf)+kf('ow-beak',beak,idf)
css+=kf('ow-wavR',wR,idf)+kf('ow-wavL',wL,idf)

# ---- mood states: look (watching you type), cover (wings over eyes), peek, tap/go
CL='rotate(-112deg) scale(1.45)'; CR='rotate(112deg) scale(1.45)'
PL='rotate(-62deg) scale(1.3)'
css+=f'''
/* look: eyes open, glancing down at the box you are typing in */
.owl.alive[data-s="look"] .ow-pup{{transform:translate(0,6.5px);transition:transform .35s ease-out}}
/* cover: wings fly up, eyes squeeze shut */
@keyframes ow-coverL{{0%{{transform:none}}60%{{transform:{CL.replace('1.45','1.52')}}}100%{{transform:{CL}}}}}
@keyframes ow-coverR{{0%{{transform:none}}60%{{transform:{CR.replace('1.45','1.52')}}}100%{{transform:{CR}}}}}
@keyframes ow-coverPL{{0%{{transform:{PL}}}100%{{transform:{CL}}}}}
@keyframes ow-peekL{{0%{{transform:{CL}}}100%{{transform:{PL}}}}}
@keyframes ow-unL{{0%{{transform:{CL}}}60%{{transform:rotate(-10deg)}}100%{{transform:none}}}}
@keyframes ow-unR{{0%{{transform:{CR}}}60%{{transform:rotate(10deg)}}100%{{transform:none}}}}
@keyframes ow-shut{{from{{transform:scaleY(1)}}to{{transform:scaleY(.08)}}}}
@keyframes ow-open{{from{{transform:scaleY(.08)}}to{{transform:scaleY(1)}}}}
@keyframes ow-peekeye{{from{{transform:scaleY(.08)}}to{{transform:scaleY(.7)}}}}
@keyframes ow-peekpup{{from{{transform:translate(0,0)}}to{{transform:translate(3px,6px)}}}}
@keyframes ow-tick{{0%{{transform:none}}40%{{transform:rotate(-2.2deg) scale(1.02)}}100%{{transform:none}}}}
.owl.alive[data-s="cover"] .ow-wL{{animation:ow-coverL .4s cubic-bezier(.3,1.3,.5,1) forwards}}
.owl.alive[data-s="cover"] .ow-wR{{animation:ow-coverR .4s cubic-bezier(.3,1.3,.5,1) forwards}}
.owl.alive[data-s="cover"].fp .ow-wL{{animation:ow-coverPL .3s ease-out forwards}}
.owl.alive[data-s="cover"] .ow-eyeL,.owl.alive[data-s="cover"] .ow-eyeR{{animation:ow-shut .18s .08s ease-in forwards}}
.owl.alive[data-s="cover"].tk .ow-all{{animation:ow-tick .16s}}
.owl.alive[data-s="peek"] .ow-wL{{animation:ow-peekL .35s ease-out forwards}}
.owl.alive[data-s="peek"] .ow-wR{{transform:{CR}}}
.owl.alive[data-s="peek"] .ow-eyeL{{animation:ow-peekeye .3s .1s ease-out forwards}}
.owl.alive[data-s="peek"] .ow-eyeR{{transform:scaleY(.08)}}
.owl.alive[data-s="peek"] .ow-eyeL .ow-pup{{animation:ow-peekpup .3s .1s ease-out forwards}}
.owl.alive[data-s="look"].fc .ow-wL{{animation:ow-unL .5s ease-out}}
.owl.alive[data-s="look"].fc .ow-wR{{animation:ow-unR .5s ease-out}}
.owl.alive[data-s="look"].fc .ow-eyeL,.owl.alive[data-s="look"].fc .ow-eyeR{{animation:ow-open .35s ease-out}}
/* tap / go: giggle, wings out, eyes spin */
@keyframes ow-giggle{{0%,100%{{transform:none}}15%{{transform:rotate(-9deg) scale(1.06)}}35%{{transform:rotate(8deg) scale(1.06)}}55%{{transform:rotate(-6deg) translateY(-6%)}}75%{{transform:rotate(4deg)}}}}
@keyframes ow-spin{{0%{{transform:translate(0,-6px)}}12.5%{{transform:translate(6px,0)}}25%{{transform:translate(0,6px)}}37.5%{{transform:translate(-6px,0)}}50%{{transform:translate(0,-6px)}}62.5%{{transform:translate(6px,0)}}75%{{transform:translate(0,6px)}}87.5%{{transform:translate(-6px,0)}}100%{{transform:translate(0,-6px)}}}}
@keyframes ow-flapL{{0%,100%{{transform:none}}25%{{transform:rotate(-34deg)}}50%{{transform:rotate(-6deg)}}75%{{transform:rotate(-30deg)}}}}
@keyframes ow-flapR{{0%,100%{{transform:none}}25%{{transform:rotate(34deg)}}50%{{transform:rotate(6deg)}}75%{{transform:rotate(30deg)}}}}
.owl.alive[data-s="tap"] .ow-all{{animation:ow-giggle .9s ease-in-out}}
.owl.alive[data-s="tap"] .ow-pup{{animation:ow-spin .9s linear}}
.owl.alive[data-s="tap"] .ow-wL{{animation:ow-flapL .9s ease-in-out}}
.owl.alive[data-s="tap"] .ow-wR{{animation:ow-flapR .9s ease-in-out}}
'''
open(WWW+'/css/owl.css','w').write(css)

# ---------------------------------------------------------------- replace the svg in splash + home
def swap(path, start_marker, new_svg):
    t=open(path).read()
    a=t.index(start_marker); b=t.index('</svg>',a)+6
    t=t[:a]+new_svg+t[b:]
    open(path,'w').write(t)
swap(WWW+'/index.html','<svg class="sp-logo',owl('ow','sp-logo owl alive').replace('<svg class="sp-logo owl alive"','<svg class="sp-logo owl alive" id="splogo"'))
swap(WWW+'/pages/newtab.html','<svg class="owl alive"',owl('mo','owl alive'))
print(len(css))
