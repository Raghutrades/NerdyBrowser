package com.nerdyintruder.nerdybrowser;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Everything the media downloader does off the main thread: reading sizes, reading HLS playlists,
 * downloading, joining video + sound, shrinking pictures and saving into Downloads/NerdyBrowser.
 * No DRM handling at all: protected streams are skipped.
 */
class MediaGrab {

    /** one thing the person can pick in the list */
    static class Item {
        String kind = "v";      // v video, a audio, i image
        String how = "direct";  // direct | hls | merge | resize
        String url, url2, ref, label = "", mime = "", group = "";
        int w, h, br, maxDim;
        long bytes = -1, bytes2 = -1;
        double dur;
        boolean vo, ao, protectedStream, checked;
        long seq;

        String key() {
            return how + "|" + url + "|" + (url2 == null ? "" : url2) + "|" + maxDim;
        }
    }

    interface Prog {
        void add(long n);

        void total(long t);

        boolean stop();
    }

    interface Sink {
        void add(Item it);
    }

    // ------------------------------------------------------------------ network

    static HttpURLConnection open(String url, String ua, String ref, String method, String range) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(9000);
        c.setReadTimeout(15000);
        c.setInstanceFollowRedirects(true);
        if (ua != null) c.setRequestProperty("User-Agent", ua);
        if (ref != null && !ref.isEmpty()) c.setRequestProperty("Referer", ref);
        String ck = CookieManager.getInstance().getCookie(url);
        if (ck != null) c.setRequestProperty("Cookie", ck);
        if (range != null) c.setRequestProperty("Range", range);
        c.setRequestProperty("Accept", "*/*");
        return c;
    }

    /** fills bytes and mime. Returns false when the address clearly is not a file (web page, error). */
    static boolean probe(Item it, String ua) {
        try {
            HttpURLConnection c = open(it.url, ua, it.ref, "HEAD", null);
            int code = c.getResponseCode();
            long len = c.getContentLengthLong();
            String ct = c.getContentType();
            c.disconnect();
            if (code >= 400 || len <= 0) {
                HttpURLConnection g = open(it.url, ua, it.ref, "GET", "bytes=0-0");
                int gc = g.getResponseCode();
                String cr = g.getHeaderField("Content-Range");
                String gt = g.getContentType();
                long gl = g.getContentLengthLong();
                g.disconnect();
                if (gc >= 400) return code < 400 || code == 403 || code == 405 || code == 401;
                if (cr != null && cr.contains("/")) {
                    try {
                        len = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim());
                    } catch (Exception ignored) {
                    }
                } else if (gc == 200 && gl > 0) len = gl;
                if (gt != null) ct = gt;
            }
            if (len > 0) it.bytes = len;
            if (ct != null) {
                ct = ct.split(";")[0].trim().toLowerCase(Locale.ROOT);
                if (ct.startsWith("text/html") || ct.equals("application/json")) return false;
                if (it.mime.isEmpty() && !ct.equals("application/octet-stream") && !ct.equals("binary/octet-stream")) it.mime = ct;
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    static String fetchText(String url, String ua, String ref) throws IOException {
        HttpURLConnection c = open(url, ua, ref, "GET", null);
        if (c.getResponseCode() >= 400) {
            c.disconnect();
            throw new IOException("HTTP " + c.getResponseCode());
        }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > 3 * 1024 * 1024) break;
        }
        in.close();
        c.disconnect();
        return bo.toString("UTF-8");
    }

    static String resolve(String base, String rel) {
        try {
            return new URL(new URL(base), rel).toString();
        } catch (Exception e) {
            return rel;
        }
    }

    static boolean looksLikePlaylist(String url, String mime) {
        String p = url.toLowerCase(Locale.ROOT);
        int q = p.indexOf('?');
        if (q > 0) p = p.substring(0, q);
        return p.endsWith(".m3u8") || (mime != null && mime.contains("mpegurl"));
    }

    // ------------------------------------------------------------------ HLS

    private static final Pattern ATTR = Pattern.compile("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)");

    static Map<String, String> attrs(String line) {
        Map<String, String> m = new HashMap<>();
        int i = line.indexOf(':');
        Matcher x = ATTR.matcher(i >= 0 ? line.substring(i + 1) : line);
        while (x.find()) {
            String v = x.group(2);
            if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) v = v.substring(1, v.length() - 1);
            m.put(x.group(1), v);
        }
        return m;
    }

    static class Seg {
        String url, keyUri, iv;
        long seq;
    }

    static class Media {
        final List<Seg> segs = new ArrayList<>();
        String map;
        double total;
        boolean endlist, drm, ranged;
    }

    static Media parseMedia(String text, String base) {
        Media m = new Media();
        long seq = 0;
        String keyUri = null, iv = null;
        double pend = 0;
        for (String raw : text.split("\\r?\\n")) {
            String l = raw.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                try {
                    seq = Long.parseLong(l.substring(22).trim());
                } catch (Exception ignored) {
                }
            } else if (l.startsWith("#EXTINF:")) {
                try {
                    String d = l.substring(8);
                    int c = d.indexOf(',');
                    pend = Double.parseDouble(c >= 0 ? d.substring(0, c) : d);
                } catch (Exception ignored) {
                }
            } else if (l.startsWith("#EXT-X-KEY:")) {
                Map<String, String> a = attrs(l);
                String meth = a.get("METHOD") == null ? "NONE" : a.get("METHOD");
                String kf = a.get("KEYFORMAT");
                if (meth.equals("NONE")) {
                    keyUri = null;
                    iv = null;
                } else if (meth.equals("AES-128") && (kf == null || kf.equals("identity")) && a.get("URI") != null) {
                    keyUri = resolve(base, a.get("URI"));
                    iv = a.get("IV");
                } else {
                    m.drm = true;
                }
            } else if (l.startsWith("#EXT-X-MAP:")) {
                Map<String, String> a = attrs(l);
                if (a.get("URI") != null) m.map = resolve(base, a.get("URI"));
                if (a.get("BYTERANGE") != null) m.ranged = true;
            } else if (l.startsWith("#EXT-X-BYTERANGE")) {
                m.ranged = true;
            } else if (l.equals("#EXT-X-ENDLIST")) {
                m.endlist = true;
            } else if (!l.startsWith("#")) {
                Seg s = new Seg();
                s.url = resolve(base, l);
                s.keyUri = keyUri;
                s.iv = iv;
                s.seq = seq++;
                m.segs.add(s);
                m.total += pend;
                pend = 0;
            }
        }
        return m;
    }

    /**
     * Reads a playlist address. A master list gives one item per quality, a plain list gives one item.
     * Items are handed to the sink as soon as each one is known.
     */
    static void expandHls(Item src, String ua, Sink sink) {
        try {
            String text = fetchText(src.url, ua, src.ref);
            if (!text.startsWith("#EXTM3U")) return;
            if (!text.contains("#EXT-X-STREAM-INF")) {
                Media m = parseMedia(text, src.url);
                if (m.drm) {
                    Item d = copy(src);
                    d.protectedStream = true;
                    d.label = "Protected stream";
                    sink.add(d);
                    return;
                }
                if (m.ranged || !m.endlist || m.segs.isEmpty()) return; // live or byte-range streams are not supported
                Item it = copy(src);
                it.how = "hls";
                it.dur = m.total;
                it.label = "Stream";
                sink.add(it);
                return;
            }
            Map<String, String> audio = new HashMap<>();
            String[] lines = text.split("\\r?\\n");
            for (String raw : lines) {
                String l = raw.trim();
                if (l.startsWith("#EXT-X-MEDIA:")) {
                    Map<String, String> a = attrs(l);
                    if ("AUDIO".equals(a.get("TYPE")) && a.get("URI") != null && a.get("GROUP-ID") != null && !audio.containsKey(a.get("GROUP-ID"))) {
                        audio.put(a.get("GROUP-ID"), resolve(src.url, a.get("URI")));
                    }
                }
            }
            int shown = 0;
            for (int i = 0; i < lines.length && shown < 10; i++) {
                String l = lines[i].trim();
                if (!l.startsWith("#EXT-X-STREAM-INF:")) continue;
                Map<String, String> a = attrs(l);
                String u = null;
                for (int j = i + 1; j < lines.length; j++) {
                    String n = lines[j].trim();
                    if (n.isEmpty()) continue;
                    if (!n.startsWith("#")) u = resolve(src.url, n);
                    break;
                }
                if (u == null) continue;
                Item it = copy(src);
                it.url = u;
                it.how = "hls";
                try {
                    it.br = Integer.parseInt(a.get("BANDWIDTH"));
                } catch (Exception ignored) {
                }
                String res = a.get("RESOLUTION");
                if (res != null && res.contains("x")) {
                    try {
                        it.w = Integer.parseInt(res.substring(0, res.indexOf('x')));
                        it.h = Integer.parseInt(res.substring(res.indexOf('x') + 1));
                    } catch (Exception ignored) {
                    }
                }
                String ag = a.get("AUDIO");
                if (ag != null && audio.containsKey(ag)) {
                    it.url2 = audio.get(ag);
                    it.how = "hls";
                }
                try {
                    Media m = parseMedia(fetchText(u, ua, src.ref), u);
                    if (m.drm) {
                        it.protectedStream = true;
                    } else if (m.ranged || !m.endlist || m.segs.isEmpty()) {
                        continue;
                    } else {
                        it.dur = m.total;
                        if (it.br > 0 && m.total > 0) it.bytes = (long) (it.br / 8.0 * m.total);
                    }
                } catch (Exception ignored) {
                }
                shown++;
                sink.add(it);
            }
        } catch (Exception ignored) {
        }
    }

    static Item copy(Item s) {
        Item d = new Item();
        d.kind = s.kind;
        d.how = s.how;
        d.url = s.url;
        d.url2 = s.url2;
        d.ref = s.ref;
        d.label = s.label;
        d.mime = s.mime;
        d.group = s.group;
        d.w = s.w;
        d.h = s.h;
        d.br = s.br;
        d.maxDim = s.maxDim;
        d.bytes = s.bytes;
        d.bytes2 = s.bytes2;
        d.dur = s.dur;
        d.vo = s.vo;
        d.ao = s.ao;
        d.seq = s.seq;
        return d;
    }

    /** downloads every piece of a playlist into one file (.ts or fragmented mp4) */
    static void hlsDownload(String playlistUrl, File out, String ua, String ref, Prog p) throws Exception {
        Media m = parseMedia(fetchText(playlistUrl, ua, ref), playlistUrl);
        if (m.drm) throw new IOException("This stream is protected and cannot be saved");
        if (m.segs.isEmpty()) throw new IOException("The stream has no pieces");
        Map<String, byte[]> keys = new HashMap<>();
        OutputStream os = new FileOutputStream(out);
        try {
            if (m.map != null) copyUrl(m.map, os, ua, ref, p, null);
            for (Seg s : m.segs) {
                if (p.stop()) throw new IOException("Cancelled");
                Cipher ci = null;
                if (s.keyUri != null) {
                    byte[] k = keys.get(s.keyUri);
                    if (k == null) {
                        ByteArrayOutputStream kb = new ByteArrayOutputStream();
                        copyUrl(s.keyUri, kb, ua, ref, null, null);
                        k = kb.toByteArray();
                        keys.put(s.keyUri, k);
                    }
                    byte[] iv = new byte[16];
                    if (s.iv != null && s.iv.toLowerCase(Locale.ROOT).startsWith("0x")) {
                        String hx = s.iv.substring(2);
                        while (hx.length() < 32) hx = "0" + hx;
                        for (int i = 0; i < 16; i++) iv[i] = (byte) Integer.parseInt(hx.substring(i * 2, i * 2 + 2), 16);
                    } else {
                        long q = s.seq;
                        for (int i = 15; i >= 8; i--) {
                            iv[i] = (byte) (q & 0xff);
                            q >>= 8;
                        }
                    }
                    ci = Cipher.getInstance("AES/CBC/PKCS5Padding");
                    ci.init(Cipher.DECRYPT_MODE, new SecretKeySpec(k, "AES"), new IvParameterSpec(iv));
                }
                IOException last = null;
                for (int tryNo = 0; tryNo < 3; tryNo++) {
                    try {
                        copyUrl(s.url, os, ua, ref, p, ci);
                        last = null;
                        break;
                    } catch (IOException e) {
                        last = e;
                        if (ci != null) break; // a half-read encrypted piece cannot be retried in place
                    }
                }
                if (last != null) throw last;
            }
        } finally {
            os.close();
        }
    }

    private static void copyUrl(String url, OutputStream os, String ua, String ref, Prog p, Cipher ci) throws IOException {
        HttpURLConnection c = open(url, ua, ref, "GET", null);
        int code = c.getResponseCode();
        if (code >= 400) {
            c.disconnect();
            throw new IOException("HTTP " + code);
        }
        InputStream in = c.getInputStream();
        if (ci != null) in = new CipherInputStream(in, ci);
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) {
            os.write(buf, 0, n);
            if (p != null) {
                p.add(n);
                if (p.stop()) {
                    in.close();
                    c.disconnect();
                    throw new IOException("Cancelled");
                }
            }
        }
        in.close();
        c.disconnect();
    }

    /** plain single-file download into a temporary file */
    static void fetchTo(String url, File out, String ua, String ref, Prog p) throws Exception {
        HttpURLConnection c = open(url, ua, ref, "GET", null);
        int code = c.getResponseCode();
        if (code >= 400) {
            c.disconnect();
            throw new IOException("The site refused the download (HTTP " + code + ")");
        }
        long len = c.getContentLengthLong();
        if (len > 0 && p != null) p.total(len);
        InputStream in = c.getInputStream();
        OutputStream os = new FileOutputStream(out);
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                if (p != null) {
                    p.add(n);
                    if (p.stop()) throw new IOException("Cancelled");
                }
            }
        } finally {
            os.close();
            in.close();
            c.disconnect();
        }
    }

    // ------------------------------------------------------------------ join video + sound (no re-encoding)

    /** copies the first video and first sound track of the given files into one file. Returns false if the phone cannot do it. */
    static boolean mux(File[] ins, File out, boolean webm) {
        MediaMuxer mm = null;
        List<MediaExtractor> exs = new ArrayList<>();
        List<Integer> map = new ArrayList<>();
        boolean started = false;
        try {
            mm = new MediaMuxer(out.getPath(), webm ? MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM : MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            boolean haveV = false, haveA = false;
            for (File f : ins) {
                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(f.getPath());
                boolean used = false;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat fmt = ex.getTrackFormat(i);
                    String mime = fmt.getString(MediaFormat.KEY_MIME);
                    if (mime == null) continue;
                    boolean v = mime.startsWith("video/"), a = mime.startsWith("audio/");
                    if ((v && haveV) || (a && haveA) || (!v && !a)) continue;
                    ex.selectTrack(i);
                    map.add(mm.addTrack(fmt));
                    if (v) haveV = true;
                    else haveA = true;
                    used = true;
                    exs.add(ex);
                    break;
                }
                if (!used) ex.release();
            }
            if (exs.isEmpty()) return false;
            mm.start();
            started = true;
            ByteBuffer buf = ByteBuffer.allocate(4 * 1024 * 1024);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            while (true) {
                int best = -1;
                long bt = Long.MAX_VALUE;
                for (int k = 0; k < exs.size(); k++) {
                    long t = exs.get(k).getSampleTime();
                    if (t >= 0 && t < bt) {
                        bt = t;
                        best = k;
                    }
                }
                if (best < 0) break;
                MediaExtractor ex = exs.get(best);
                buf.clear();
                int size = ex.readSampleData(buf, 0);
                if (size < 0) {
                    ex.unselectTrack(ex.getSampleTrackIndex());
                    break;
                }
                bi.offset = 0;
                bi.size = size;
                bi.presentationTimeUs = bt;
                bi.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                mm.writeSampleData(map.get(best), buf, bi);
                ex.advance();
            }
            return true;
        } catch (Throwable e) {
            return false;
        } finally {
            for (MediaExtractor e : exs) {
                try {
                    e.release();
                } catch (Throwable ignored) {
                }
            }
            if (mm != null) {
                try {
                    if (started) mm.stop();
                } catch (Throwable ignored) {
                }
                try {
                    mm.release();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** true when the first video track of the file needs the webm container */
    static boolean wantsWebm(File f) {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(f.getPath());
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("video/")) return m.equals("video/x-vnd.on2.vp9") || m.equals("video/x-vnd.on2.vp8");
            }
        } catch (Throwable ignored) {
        } finally {
            ex.release();
        }
        return false;
    }

    // ------------------------------------------------------------------ pictures

    /** shrinks a picture so its longest side is at most maxDim. Returns the extension used (jpg or png). */
    static String resize(File src, File out, int maxDim) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(src.getPath(), o);
        int w = o.outWidth, h = o.outHeight;
        if (w <= 0 || h <= 0) throw new IOException("Not a picture this phone can read");
        int big = Math.max(w, h), ss = 1;
        while (big / (ss * 2) >= maxDim) ss *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = ss;
        Bitmap b = BitmapFactory.decodeFile(src.getPath(), o);
        if (b == null) throw new IOException("Could not read the picture");
        float sc = (float) maxDim / Math.max(b.getWidth(), b.getHeight());
        if (sc < 1f) {
            Bitmap s = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
            if (s != b) b.recycle();
            b = s;
        }
        boolean png = b.hasAlpha();
        FileOutputStream fo = new FileOutputStream(out);
        try {
            b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 90, fo);
        } finally {
            fo.close();
            b.recycle();
        }
        return png ? "png" : "jpg";
    }

    // ------------------------------------------------------------------ saving

    static String extFor(String mime, String url, String fallback) {
        String ext = null;
        if (mime != null && !mime.isEmpty()) ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (ext == null || ext.isEmpty()) {
            try {
                String p = Uri.parse(url).getLastPathSegment();
                if (p != null) {
                    Matcher m = Pattern.compile("\\.([A-Za-z0-9]{2,5})$").matcher(p);
                    if (m.find()) ext = m.group(1).toLowerCase(Locale.ROOT);
                }
            } catch (Exception ignored) {
            }
        }
        if (ext == null || ext.isEmpty() || ext.equals("bin") || ext.equals("php") || ext.equals("html")) ext = fallback;
        return ext;
    }

    static String mimeForExt(String ext, String fallback) {
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? fallback : m;
    }

    /** puts a finished file into Downloads/NerdyBrowser/<category>. Returns where it ended up. */
    static Uri publish(Context c, File f, String name, String mime, String category) throws IOException {
        String sub = category == null || category.isEmpty() ? "NerdyBrowser" : "NerdyBrowser/" + category;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + sub);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IOException("Could not create the file in Downloads");
            OutputStream os = c.getContentResolver().openOutputStream(u);
            if (os == null) throw new IOException("Could not write to Downloads");
            copyFile(f, os);
            ContentValues d = new ContentValues();
            d.put(MediaStore.MediaColumns.IS_PENDING, 0);
            c.getContentResolver().update(u, d, null, null);
            return u;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), sub);
        File dest = new File(dir, name);
        try {
            dir.mkdirs();
            copyFile(f, new FileOutputStream(dest));
        } catch (IOException e) {
            File alt = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (alt == null) throw e;
            dest = new File(alt, name);
            copyFile(f, new FileOutputStream(dest));
        }
        return Uri.fromFile(dest);
    }

    private static void copyFile(File f, OutputStream os) throws IOException {
        InputStream in = new java.io.FileInputStream(f);
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            in.close();
            os.close();
        }
    }
}
