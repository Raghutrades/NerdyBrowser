package com.nerdyintruder.nerdybrowser;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * NerdyBrowser's own download manager.
 * - pause / resume (HTTP Range, checked with ETag so a changed file never gets glued together)
 * - keeps going by itself when the internet drops or switches (waits, then continues from the same byte)
 * - speed limit per file and for everything together
 * - remembers unfinished downloads across app restarts
 */
final class Dl {
    static final long BASE = 5000000000000L;
    static final int QUEUED = 0, RUNNING = 1, WAITING = 2, PAUSED = 3, DONE = 4, FAILED = 5;

    interface Host {
        void changed();

        void finished(Task t);
    }

    static final class Task {
        long id;
        String url, ua = "", ref = "", cookie = "", name = "download", mime = "", cat = "Other", etag = "", uri = "", err = "";
        boolean sort = true;
        volatile long total = -1, got = 0, limit = 0, speed = 0, ts = 0;
        volatile int state = QUEUED;
        volatile boolean pause, cancel, active, resumeReq;
        long lastGot, lastTick;
    }

    private static final class Fatal extends IOException {
        Fatal(String m) {
            super(m);
        }
    }

    private final Context ctx;
    private final Host host;
    private final File dir, store;
    private final LinkedHashMap<Long, Task> tasks = new LinkedHashMap<>();
    private final ThreadPoolExecutor pool = new ThreadPoolExecutor(3, 3, 30, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
    private final Object net = new Object();
    private volatile boolean online = true;
    private volatile long globalLimit = 0;
    private volatile String proxy = "";
    private volatile boolean wifiOnly = false;
    private long lastSave = 0;

    Dl(Context c, Host h) {
        ctx = c;
        host = h;
        File d = c.getExternalFilesDir("dl");
        if (d == null) d = new File(c.getFilesDir(), "dl");
        dir = d;
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        store = new File(c.getFilesDir(), "dl.json");
        pool.allowCoreThreadTimeOut(true);
        watchNetwork();
        load();
    }

    // ---------- public api ----------
    long add(String url, String ua, String ref, String cookie, String name, String mime, String cat, boolean sort, long limit) {
        Task t = new Task();
        synchronized (tasks) {
            long id = BASE + 1;
            for (Long k : tasks.keySet()) if (k >= id) id = k + 1;
            t.id = id;
            tasks.put(id, t);
        }
        t.url = url;
        t.ua = ua == null ? "" : ua;
        t.ref = ref == null ? "" : ref;
        t.cookie = cookie == null ? "" : cookie;
        t.name = name == null || name.isEmpty() ? "download" : name;
        t.mime = mime == null ? "" : mime;
        t.cat = cat == null ? "Other" : cat;
        t.sort = sort;
        t.limit = limit;
        t.ts = System.currentTimeMillis();
        save(true);
        submit(t);
        host.changed();
        return t.id;
    }

    boolean owns(long id) {
        return id >= BASE;
    }

    /** the half-downloaded file, so the Downloads screen can show what has arrived so far */
    File partFile(long id) {
        Task t = get(id);
        return t == null ? null : part(t);
    }

    Task get(long id) {
        synchronized (tasks) {
            return tasks.get(id);
        }
    }

    void pause(long id) {
        Task t = get(id);
        if (t == null || t.state == DONE) return;
        t.pause = true;
        t.resumeReq = false;
        if (!t.active) {
            t.state = PAUSED;
            t.speed = 0;
        }
        save(true);
        host.changed();
    }

    void resume(long id) {
        Task t = get(id);
        if (t == null || t.state == DONE) return;
        t.pause = false;
        t.err = "";
        if (t.state == FAILED || t.state == PAUSED) t.state = QUEUED;
        synchronized (t) {
            if (t.active) t.resumeReq = true;
            else submit(t);
        }
        synchronized (net) {
            net.notifyAll();
        }
        save(true);
        host.changed();
    }

    void pauseAll() {
        for (Task t : list()) if (t.state != DONE && t.state != FAILED) pause(t.id);
    }

    void resumeAll() {
        for (Task t : list()) if (t.state == PAUSED || t.state == FAILED) resume(t.id);
    }

    void remove(long id) {
        Task t;
        synchronized (tasks) {
            t = tasks.remove(id);
        }
        if (t == null) return;
        t.cancel = true;
        synchronized (net) {
            net.notifyAll();
        }
        if (t.state != DONE) //noinspection ResultOfMethodCallIgnored
            part(t).delete();
        save(true);
        host.changed();
    }

    void setLimit(long id, long bytesPerSec) {
        Task t = get(id);
        if (t == null) return;
        t.limit = Math.max(0, bytesPerSec);
        save(true);
        host.changed();
    }

    void setGlobalLimit(long bytesPerSec) {
        globalLimit = Math.max(0, bytesPerSec);
    }

    void setWifiOnly(boolean b) {
        wifiOnly = b;
    }

    private boolean metered() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm != null && cm.isActiveNetworkMetered();
        } catch (Exception e) {
            return false;
        }
    }

    void setParallel(int n) {
        n = Math.max(1, Math.min(6, n));
        if (n > pool.getCorePoolSize()) {
            pool.setMaximumPoolSize(n);
            pool.setCorePoolSize(n);
        } else {
            pool.setCorePoolSize(n);
            pool.setMaximumPoolSize(n);
        }
    }

    /** "socks5://127.0.0.1:9050", "http://host:port", "host:port" or empty */
    void setProxy(String p) {
        proxy = p == null ? "" : p.trim();
    }

    JSONArray toJson() {
        JSONArray a = new JSONArray();
        for (Task t : list()) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", t.id);
                o.put("sm", 1);
                o.put("title", t.name);
                int s = t.state;
                o.put("status", s == DONE ? 8 : s == FAILED ? 16 : s == RUNNING ? 2 : s == QUEUED ? 1 : 4);
                o.put("st", s);
                o.put("total", t.total);
                o.put("got", t.got);
                o.put("mime", t.mime);
                o.put("ts", t.ts);
                o.put("spd", s == RUNNING ? t.speed : 0);
                o.put("limit", t.limit);
                o.put("url", t.url);
                o.put("err", t.err);
                o.put("reason", s == FAILED ? 1000 : 0);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        return a;
    }

    private List<Task> list() {
        synchronized (tasks) {
            return new ArrayList<>(tasks.values());
        }
    }

    // ---------- engine ----------
    private File part(Task t) {
        return new File(dir, t.id + ".part");
    }

    private void submit(final Task t) {
        if (t.state == DONE) return;
        try {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    runTask(t);
                }
            });
        } catch (Exception e) {
            t.state = FAILED;
            t.err = "Could not start";
        }
    }

    private void runTask(Task t) {
        synchronized (t) {
            if (t.active) {
                t.resumeReq = true;
                return;
            }
            t.active = true;
        }
        try {
            int fails = 0;
            while (!t.cancel) {
                if (t.pause) {
                    t.state = PAUSED;
                    t.speed = 0;
                    break;
                }
                if (!online || (wifiOnly && metered())) {
                    t.state = WAITING;
                    t.speed = 0;
                    host.changed();
                    synchronized (net) {
                        if ((!online || (wifiOnly && metered())) && !t.pause && !t.cancel) {
                            try {
                                net.wait(3000);
                            } catch (InterruptedException ignored) {
                            }
                        }
                    }
                    continue;
                }
                long before = t.got;
                try {
                    t.state = RUNNING;
                    host.changed();
                    attempt(t);
                    if (t.state == RUNNING && !t.pause && !t.cancel) {
                        finish(t);
                    }
                    break;
                } catch (Fatal f) {
                    t.state = FAILED;
                    t.err = f.getMessage() == null ? "Failed" : f.getMessage();
                    break;
                } catch (IOException e) {
                    if (t.pause || t.cancel) continue;
                    if (t.got > before) fails = 0;
                    fails++;
                    t.speed = 0;
                    t.state = WAITING;
                    if (fails > 14) {
                        t.state = FAILED;
                        t.err = "Gave up after repeated errors";
                        break;
                    }
                    host.changed();
                    long wait = Math.min(30000L, 1000L << Math.min(fails, 5));
                    long end = System.currentTimeMillis() + wait;
                    int ep = epoch;
                    synchronized (net) {
                        while (!t.pause && !t.cancel && System.currentTimeMillis() < end) {
                            try {
                                net.wait(500);
                            } catch (InterruptedException ignored) {
                            }
                            // the moment the connection comes back after a drop, don't wait out the delay
                            if (ep != epoch) break;
                        }
                    }
                }
            }
        } finally {
            boolean again;
            synchronized (t) {
                t.active = false;
                again = t.resumeReq && !t.cancel && t.state != DONE && t.state != FAILED;
                t.resumeReq = false;
            }
            save(true);
            host.changed();
            if (again) {
                t.pause = false;
                submit(t);
            }
        }
    }

    private volatile int epoch = 0;

    private HttpURLConnection open(String u) throws IOException {
        return connect(u, proxy);
    }

    static HttpURLConnection connect(String u, String p) throws IOException {
        URL url = new URL(u);
        if (p.isEmpty()) return (HttpURLConnection) url.openConnection();
        boolean socks = p.startsWith("socks");
        String hp = p.replaceFirst("^[a-zA-Z0-9]+://", "");
        int i = hp.lastIndexOf(':');
        if (i < 0) return (HttpURLConnection) url.openConnection();
        String host = hp.substring(0, i);
        int port;
        try {
            port = Integer.parseInt(hp.substring(i + 1).replaceAll("[^0-9]", ""));
        } catch (Exception e) {
            return (HttpURLConnection) url.openConnection();
        }
        Proxy px = new Proxy(socks ? Proxy.Type.SOCKS : Proxy.Type.HTTP, InetSocketAddress.createUnresolved(host, port));
        return (HttpURLConnection) url.openConnection(px);
    }

    private void attempt(Task t) throws IOException {
        File part = part(t);
        long have = part.exists() ? part.length() : 0;
        if (t.got != have) t.got = have;
        HttpURLConnection c = open(t.url);
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (!t.ua.isEmpty()) c.setRequestProperty("User-Agent", t.ua);
            if (!t.cookie.isEmpty()) c.setRequestProperty("Cookie", t.cookie);
            if (!t.ref.isEmpty()) c.setRequestProperty("Referer", t.ref);
            if (have > 0) {
                c.setRequestProperty("Range", "bytes=" + have + "-");
                if (!t.etag.isEmpty()) c.setRequestProperty("If-Range", t.etag);
            }
            int code = c.getResponseCode();
            if (code == 416) {
                if (t.total > 0 && have >= t.total) return;
                //noinspection ResultOfMethodCallIgnored
                part.delete();
                t.got = 0;
                throw new IOException("restart");
            }
            if (code != 200 && code != 206) {
                if (code >= 500 || code == 429 || code == 408) throw new IOException("HTTP " + code);
                throw new Fatal("Server said " + code + (code == 403 || code == 401 ? " (link expired or needs login, open the page again)" : ""));
            }
            boolean append = code == 206 && have > 0;
            if (!append) {
                have = 0;
                t.got = 0;
            }
            long len = c.getContentLengthLong();
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                if (cr != null && cr.contains("/")) {
                    try {
                        t.total = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim());
                    } catch (Exception ignored) {
                    }
                } else if (len > 0) t.total = have + len;
            } else if (len > 0) t.total = len;
            String et = c.getHeaderField("ETag");
            if (et == null || et.startsWith("W/")) et = c.getHeaderField("Last-Modified");
            if (et != null && !et.startsWith("W/")) t.etag = et;
            InputStream in = c.getInputStream();
            FileOutputStream out = new FileOutputStream(part, append);
            try {
                byte[] buf = new byte[32768];
                long winStart = System.currentTimeMillis(), winBytes = 0, lastSaveTick = winStart;
                long lastLim = -1;
                t.lastTick = winStart;
                t.lastGot = t.got;
                int n;
                while ((n = in.read(buf)) >= 0) {
                    if (t.cancel) return;
                    if (t.pause) {
                        t.state = PAUSED;
                        return;
                    }
                    out.write(buf, 0, n);
                    t.got += n;
                    winBytes += n;
                    long now = System.currentTimeMillis();
                    if (now - t.lastTick >= 1000) {
                        long inst = (t.got - t.lastGot) * 1000 / Math.max(1, now - t.lastTick);
                        t.speed = t.speed == 0 ? inst : (t.speed * 6 + inst * 4) / 10;
                        t.lastTick = now;
                        t.lastGot = t.got;
                    }
                    if (now - lastSaveTick > 4000) {
                        lastSaveTick = now;
                        save(false);
                    }
                    long lim = effective(t);
                    if (lim != lastLim) {
                        lastLim = lim;
                        winStart = now;
                        winBytes = 0;
                    }
                    if (lim > 0) {
                        long due = winBytes * 1000 / lim;
                        long el = now - winStart;
                        while (due > el && !t.pause && !t.cancel) {
                            try {
                                Thread.sleep(Math.min(due - el, 200));
                            } catch (InterruptedException ignored) {
                            }
                            long l2 = effective(t);
                            if (l2 != lim) break;
                            el = System.currentTimeMillis() - winStart;
                        }
                        if (el > 3000) {
                            winStart = System.currentTimeMillis();
                            winBytes = 0;
                        }
                    }
                }
                out.flush();
            } finally {
                try {
                    out.close();
                } catch (IOException ignored) {
                }
                try {
                    in.close();
                } catch (IOException ignored) {
                }
            }
            if (!t.pause && !t.cancel && t.total > 0 && t.got < t.total) throw new IOException("connection cut");
            if (t.total <= 0) t.total = t.got;
        } finally {
            try {
                c.disconnect();
            } catch (Exception ignored) {
            }
        }
    }

    /** the speed this one file may use right now (bytes per second, 0 = no limit) */
    private long effective(Task t) {
        long l = t.limit, g = globalLimit;
        if (g > 0) {
            int run = 0;
            for (Task x : list()) if (x.state == RUNNING) run++;
            long share = g / Math.max(1, run);
            if (l <= 0 || share < l) l = share;
        }
        return l;
    }

    private void finish(Task t) {
        File p = part(t);
        t.speed = 0;
        try {
            String rel = t.sort ? "NerdyBrowser/" + t.cat : "NerdyBrowser";
            String mt = t.mime == null || t.mime.isEmpty() ? "application/octet-stream" : t.mime;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver r = ctx.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, t.name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mt);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + rel);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new IOException("Could not create the file");
                OutputStream os = r.openOutputStream(u);
                InputStream is = new java.io.FileInputStream(p);
                try {
                    byte[] b = new byte[65536];
                    int n;
                    while ((n = is.read(b)) >= 0) os.write(b, 0, n);
                } finally {
                    is.close();
                    if (os != null) os.close();
                }
                ContentValues v2 = new ContentValues();
                v2.put(MediaStore.MediaColumns.IS_PENDING, 0);
                r.update(u, v2, null, null);
                t.uri = u.toString();
                //noinspection ResultOfMethodCallIgnored
                p.delete();
            } else {
                File out = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), rel), t.name);
                //noinspection ResultOfMethodCallIgnored
                out.getParentFile().mkdirs();
                if (!p.renameTo(out)) {
                    InputStream is = new java.io.FileInputStream(p);
                    OutputStream os = new FileOutputStream(out);
                    try {
                        byte[] b = new byte[65536];
                        int n;
                        while ((n = is.read(b)) >= 0) os.write(b, 0, n);
                    } finally {
                        is.close();
                        os.close();
                    }
                    //noinspection ResultOfMethodCallIgnored
                    p.delete();
                }
                t.uri = Uri.fromFile(out).toString();
            }
        } catch (Exception e) {
            // could not move into Downloads: keep the file in the app's own folder
            File keep = new File(dir, t.name);
            //noinspection ResultOfMethodCallIgnored
            p.renameTo(keep);
            t.uri = Uri.fromFile(keep).toString();
        }
        t.state = DONE;
        t.ts = System.currentTimeMillis();
        if (t.total <= 0) t.total = t.got;
        save(true);
        host.finished(t);
    }

    // ---------- network watch ----------
    private void watchNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            cm.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network n) {
                    online = true;
                    epoch++;
                    synchronized (net) {
                        net.notifyAll();
                    }
                }

                @Override
                public void onLost(Network n) {
                    online = false;
                }
            });
        } catch (Exception ignored) {
        }
    }

    // ---------- saving ----------
    private void save(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastSave < 3000) return;
        lastSave = now;
        try {
            JSONArray a = new JSONArray();
            for (Task t : list()) {
                JSONObject o = new JSONObject();
                o.put("id", t.id);
                o.put("url", t.url);
                o.put("ua", t.ua);
                o.put("ref", t.ref);
                o.put("ck", t.cookie);
                o.put("name", t.name);
                o.put("mime", t.mime);
                o.put("cat", t.cat);
                o.put("sort", t.sort);
                o.put("etag", t.etag);
                o.put("total", t.total);
                o.put("got", t.got);
                o.put("limit", t.limit);
                o.put("state", t.state);
                o.put("uri", t.uri);
                o.put("ts", t.ts);
                a.put(o);
            }
            File tmp = new File(store.getPath() + ".tmp");
            FileOutputStream fo = new FileOutputStream(tmp);
            fo.write(a.toString().getBytes("UTF-8"));
            fo.close();
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(store);
        } catch (Exception ignored) {
        }
    }

    private void load() {
        try {
            if (!store.exists()) return;
            java.io.FileInputStream fi = new java.io.FileInputStream(store);
            byte[] b = new byte[(int) store.length()];
            int n = 0;
            while (n < b.length) {
                int r = fi.read(b, n, b.length - n);
                if (r < 0) break;
                n += r;
            }
            fi.close();
            JSONArray a = new JSONArray(new String(b, 0, n, "UTF-8"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Task t = new Task();
                t.id = o.getLong("id");
                t.url = o.optString("url");
                t.ua = o.optString("ua");
                t.ref = o.optString("ref");
                t.cookie = o.optString("ck");
                t.name = o.optString("name", "download");
                t.mime = o.optString("mime");
                t.cat = o.optString("cat", "Other");
                t.sort = o.optBoolean("sort", true);
                t.etag = o.optString("etag");
                t.total = o.optLong("total", -1);
                t.got = o.optLong("got", 0);
                t.limit = o.optLong("limit", 0);
                t.uri = o.optString("uri");
                t.ts = o.optLong("ts", 0);
                int s = o.optInt("state", QUEUED);
                // the app was closed in the middle of a download: carry on where it stopped
                t.state = (s == RUNNING || s == WAITING) ? QUEUED : s;
                tasks.put(t.id, t);
                if (t.state == QUEUED) submit(t);
            }
        } catch (Exception ignored) {
        }
    }

    static String speedText(long bps) {
        if (bps <= 0) return "No limit";
        if (bps < 1024 * 1024) return String.format(Locale.US, "%d KB/s", bps / 1024);
        return String.format(Locale.US, "%.1f MB/s", bps / 1048576.0);
    }
}
