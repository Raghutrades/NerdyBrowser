package com.nerdyintruder.nerdybrowser;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Prices for the start page market band: Indian and world indices, crude, gold, silver, crypto, USD/INR.
 * Read by the app (through the VPN / proxy if one is on), never by the page. Delayed public quotes, not trading data.
 */
final class Quotes {
    interface Cb {
        void ready(String json);
    }

    // group, name, symbol
    private static final String[][] LIST = {
            {"in", "Nifty 50", "^NSEI"}, {"in", "Sensex", "^BSESN"}, {"in", "Bank Nifty", "^NSEBANK"}, {"in", "Nifty IT", "^CNXIT"},
            {"in", "Nifty Midcap", "^NSEMDCP50"}, {"in", "India VIX", "^INDIAVIX"}, {"in", "USD/INR", "USDINR=X"},
            {"us", "S&P 500", "^GSPC"}, {"us", "Nasdaq", "^IXIC"}, {"us", "Dow Jones", "^DJI"}, {"us", "Russell 2000", "^RUT"}, {"us", "VIX", "^VIX"},
            {"as", "Nikkei 225", "^N225"}, {"as", "Hang Seng", "^HSI"}, {"as", "Shanghai", "000001.SS"}, {"as", "Shenzhen", "399001.SZ"},
            {"as", "Kospi", "^KS11"}, {"as", "Taiwan", "^TWII"}, {"as", "Straits Times", "^STI"}, {"as", "ASX 200", "^AXJO"},
            {"eu", "FTSE 100", "^FTSE"}, {"eu", "DAX", "^GDAXI"}, {"eu", "CAC 40", "^FCHI"}, {"eu", "Euro Stoxx 50", "^STOXX50E"},
            {"cm", "Crude WTI", "CL=F"}, {"cm", "Brent", "BZ=F"}, {"cm", "Gold", "GC=F"}, {"cm", "Silver", "SI=F"},
            {"cm", "Natural Gas", "NG=F"}, {"cm", "Copper", "HG=F"}, {"cm", "US Dollar Idx", "DX-Y.NYB"},
            {"cr", "Bitcoin", "BTC-USD"}, {"cr", "Ethereum", "ETH-USD"}, {"cr", "Solana", "SOL-USD"}, {"cr", "XRP", "XRP-USD"},
    };

    private volatile boolean busy = false;
    private volatile long last = 0;
    private volatile String cache = "";

    String cached() {
        return cache;
    }

    boolean busy() {
        return busy;
    }

    boolean stale(long ms) {
        return System.currentTimeMillis() - last > ms;
    }

    void refresh(final String proxy, final Cb cb) {
        if (busy) return;
        busy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String out = "";
                try {
                    out = build(proxy);
                } catch (Throwable ignored) {
                }
                if (!out.isEmpty()) {
                    cache = out;
                    last = System.currentTimeMillis();
                }
                busy = false;
                cb.ready(out);
            }
        }).start();
    }

    private String build(final String proxy) throws Exception {
        final JSONObject[] res = new JSONObject[LIST.length];
        ExecutorService ex = Executors.newFixedThreadPool(8);
        for (int i = 0; i < LIST.length; i++) {
            final int k = i;
            ex.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        res[k] = one(LIST[k], proxy);
                    } catch (Throwable ignored) {
                    }
                }
            });
        }
        ex.shutdown();
        ex.awaitTermination(20, TimeUnit.SECONDS);
        JSONArray arr = new JSONArray();
        for (JSONObject o : res) if (o != null) arr.put(o);
        if (arr.length() == 0) return "";
        JSONObject root = new JSONObject();
        root.put("t", System.currentTimeMillis());
        root.put("q", arr);
        return root.toString();
    }

    private JSONObject one(String[] d, String proxy) throws Exception {
        String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + java.net.URLEncoder.encode(d[2], "UTF-8") + "?interval=1d&range=5d";
        HttpURLConnection c = Dl.connect(url, proxy);
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(9000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) >= 0) {
                bo.write(b, 0, n);
                if (bo.size() > 600000) break;
            }
            JSONObject j = new JSONObject(bo.toString("UTF-8"));
            JSONObject r = j.getJSONObject("chart").getJSONArray("result").getJSONObject(0);
            JSONObject m = r.getJSONObject("meta");
            double px = m.optDouble("regularMarketPrice", Double.NaN);
            double prev = Double.NaN;
            // previous close = the close before the latest bar (more reliable than chartPreviousClose for a 5 day range)
            try {
                JSONArray cl = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close");
                int idx = cl.length() - 1;
                while (idx >= 0 && cl.isNull(idx)) idx--;
                int p2 = idx - 1;
                while (p2 >= 0 && cl.isNull(p2)) p2--;
                if (p2 >= 0) prev = cl.getDouble(p2);
            } catch (Exception ignored) {
            }
            if (Double.isNaN(prev)) prev = m.optDouble("chartPreviousClose", m.optDouble("previousClose", Double.NaN));
            if (Double.isNaN(px) || px <= 0) return null;
            JSONObject o = new JSONObject();
            o.put("g", d[0]);
            o.put("n", d[1]);
            o.put("s", d[2]);
            o.put("p", px);
            if (!Double.isNaN(prev) && prev > 0) {
                o.put("c", px - prev);
                o.put("pc", (px - prev) / prev * 100.0);
            }
            o.put("cur", m.optString("currency", ""));
            o.put("ts", m.optLong("regularMarketTime", 0) * 1000L);
            return o;
        } finally {
            c.disconnect();
        }
    }
}
