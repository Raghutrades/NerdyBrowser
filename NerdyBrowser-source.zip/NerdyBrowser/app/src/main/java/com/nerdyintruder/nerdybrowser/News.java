package com.nerdyintruder.nerdybrowser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Xml;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * The start page news. The page itself never touches the network: this class reads public RSS feeds
 * (through the VPN / proxy if one is on), blends them across categories, shrinks a thumbnail for each story
 * and hands the page one ready-made JSON blob.
 */
final class News {
    interface Cb {
        void ready(String json);
    }

    // category, source, feed
    private static final String[][] FEEDS = {
            {"in", "Times of India", "https://timesofindia.indiatimes.com/rssfeedstopstories.cms"},
            {"in", "The Hindu", "https://www.thehindu.com/news/national/feeder/default.rss"},
            {"in", "NDTV", "https://feeds.feedburner.com/ndtvnews-top-stories"},
            {"in", "Indian Express", "https://indianexpress.com/section/india/feed/"},
            {"mk", "Economic Times", "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms"},
            {"mk", "Mint", "https://www.livemint.com/rss/markets"},
            {"mk", "Business Standard", "https://www.business-standard.com/rss/markets-106.rss"},
            {"tc", "Gadgets 360", "https://www.gadgets360.com/rss/news"},
            {"tc", "The Verge", "https://www.theverge.com/rss/index.xml"},
            {"tc", "TechCrunch", "https://techcrunch.com/feed/"},
            {"au", "Autocar India", "https://www.autocarindia.com/rss/all"},
            {"au", "ET Auto", "https://auto.economictimes.indiatimes.com/rss/topstories"},
            {"wd", "BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"},
            {"wd", "Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"},
            {"cr", "CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"},
            {"sp", "ESPNcricinfo", "https://www.espncricinfo.com/rss/content/story/feeds/0.xml"},
            {"en", "Times of India Entertainment", "https://timesofindia.indiatimes.com/rssfeeds/1081479906.cms"},
    };
    private static final String[] ORDER = {"in", "mk", "tc", "wd", "au", "sp", "cr", "en"};

    static final long FRESH_MS = 15 * 60 * 1000L;

    private final File file, imgDir;
    private volatile boolean busy = false;

    News(Context c) {
        file = new File(c.getFilesDir(), "news2.json");
        imgDir = new File(c.getCacheDir(), "newsimg");
        //noinspection ResultOfMethodCallIgnored
        imgDir.mkdirs();
    }

    /** a saved story picture (only names this class made: 16 hex letters + .jpg), or null */
    File imageFile(String name) {
        if (name == null || !name.matches("[a-f0-9]{16}\\.jpg")) return null;
        File f = new File(imgDir, name);
        return f.exists() && f.length() > 0 ? f : null;
    }

    /** the last blend we saved, or "" */
    String cached() {
        try {
            if (!file.exists()) return "";
            FileInputStream in = new FileInputStream(file);
            byte[] b = new byte[(int) file.length()];
            int n = 0;
            while (n < b.length) {
                int r = in.read(b, n, b.length - n);
                if (r < 0) break;
                n += r;
            }
            in.close();
            return new String(b, 0, n, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    boolean stale() {
        return !file.exists() || System.currentTimeMillis() - file.lastModified() > FRESH_MS;
    }

    boolean busy() {
        return busy;
    }

    void clear() {
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    void refresh(final String proxy, final Cb cb) {
        if (busy) return;
        busy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String out = "";
                try {
                    out = build(proxy);
                } catch (Throwable ignored) {
                }
                busy = false;
                cb.ready(out);
            }
        }).start();
    }

    private static final class Item {
        String cat, src, title, link, desc, img = "", thumb = "";
        long ts;
    }

    private String build(final String proxy) throws Exception {
        final List<Item> all = Collections.synchronizedList(new ArrayList<Item>());
        ExecutorService ex = Executors.newFixedThreadPool(6);
        for (final String[] f : FEEDS) {
            ex.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        List<Item> l = readFeed(f[0], f[1], f[2], proxy);
                        all.addAll(l);
                    } catch (Throwable ignored) {
                    }
                }
            });
        }
        ex.shutdown();
        ex.awaitTermination(25, TimeUnit.SECONDS);
        List<Item> snap;
        synchronized (all) {
            snap = new ArrayList<>(all);
        }
        if (snap.isEmpty()) return "";
        // newest first inside each category, no duplicates
        Collections.sort(snap, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return Long.compare(b.ts, a.ts);
            }
        });
        Set<String> seen = new HashSet<>();
        List<List<Item>> buckets = new ArrayList<>();
        for (String c : ORDER) buckets.add(new ArrayList<Item>());
        for (Item it : snap) {
            String key = it.title.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
            if (key.length() > 60) key = key.substring(0, 60);
            if (!seen.add(key)) continue;
            for (int i = 0; i < ORDER.length; i++) {
                if (ORDER[i].equals(it.cat)) {
                    if (buckets.get(i).size() < 14) buckets.get(i).add(it);
                    break;
                }
            }
        }
        // the blend: one from each category in turn, so every scroll is a mix
        List<Item> blend = new ArrayList<>();
        for (int round = 0; round < 14; round++) {
            for (List<Item> b : buckets) if (round < b.size()) blend.add(b.get(round));
        }
        if (blend.size() > 90) blend = new ArrayList<>(blend.subList(0, 90));
        // a picture for every story: the one in the feed, or else the one the article page itself shows
        ExecutorService ix = Executors.newFixedThreadPool(8);
        int want = Math.min(blend.size(), 64);
        for (int i = 0; i < want; i++) {
            final Item it = blend.get(i);
            ix.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (it.img.isEmpty()) it.img = pageImage(it.link, proxy);
                        if (!it.img.isEmpty()) it.thumb = thumb(it.img, it.link, proxy);
                    } catch (Throwable ignored) {
                    }
                }
            });
        }
        ix.shutdown();
        ix.awaitTermination(28, TimeUnit.SECONDS);
        cleanImages();
        JSONArray arr = new JSONArray();
        for (Item it : blend) {
            JSONObject o = new JSONObject();
            o.put("c", it.cat);
            o.put("s", it.src);
            o.put("t", it.title);
            o.put("l", it.link);
            o.put("d", it.desc);
            o.put("ts", it.ts);
            if (!it.thumb.isEmpty()) o.put("im", it.thumb);
            arr.put(o);
        }
        JSONObject root = new JSONObject();
        root.put("t", System.currentTimeMillis());
        root.put("items", arr);
        String s = root.toString();
        try {
            File tmp = new File(file.getPath() + ".tmp");
            FileOutputStream fo = new FileOutputStream(tmp);
            fo.write(s.getBytes("UTF-8"));
            fo.close();
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(file);
        } catch (Exception ignored) {
        }
        return s;
    }

    private static HttpURLConnection open(String url, String proxy) throws Exception {
        HttpURLConnection c = Dl.connect(url, proxy);
        c.setConnectTimeout(8000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*");
        return c;
    }

    private static String strip(String h) {
        if (h == null) return "";
        String s = h.replaceAll("(?s)<[^>]*>", " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&#8217;", "'").replace("&lt;", "<").replace("&gt;", ">").replaceAll("\\s+", " ").trim();
        if (s.length() > 170) s = s.substring(0, 168).trim() + "…";
        return s;
    }

    private static long parseDate(String s) {
        if (s == null) return 0;
        s = s.trim();
        String[] pats = {"EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, d MMM yyyy HH:mm:ss Z", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"};
        for (String p : pats) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(p, Locale.US);
                java.util.Date d = f.parse(s);
                if (d != null) return d.getTime();
            } catch (Exception ignored) {
            }
        }
        return 0;
    }

    private static List<Item> readFeed(String cat, String src, String url, String proxy) throws Exception {
        List<Item> out = new ArrayList<>();
        HttpURLConnection c = open(url, proxy);
        try {
            if (c.getResponseCode() != 200) return out;
            InputStream in = c.getInputStream();
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, null);
            Item cur = null;
            String tag = "";
            int ev = p.getEventType();
            long now = System.currentTimeMillis();
            while (ev != XmlPullParser.END_DOCUMENT && out.size() < 10) {
                if (ev == XmlPullParser.START_TAG) {
                    tag = p.getName();
                    if (tag.equals("item") || tag.equals("entry")) {
                        cur = new Item();
                        cur.cat = cat;
                        cur.src = src;
                        cur.title = "";
                        cur.link = "";
                        cur.desc = "";
                    } else if (cur != null) {
                        if (tag.equals("media:content") || tag.equals("media:thumbnail") || tag.equals("enclosure")) {
                            String u = p.getAttributeValue(null, "url");
                            String ty = p.getAttributeValue(null, "type");
                            String md = p.getAttributeValue(null, "medium");
                            boolean img = tag.equals("media:thumbnail") || (ty != null && ty.startsWith("image")) || "image".equals(md)
                                    || (u != null && u.matches("(?i).*\\.(jpg|jpeg|png|webp)(\\?.*)?$"));
                            if (u != null && img && cur.img.isEmpty()) cur.img = u;
                        } else if (tag.equals("link")) {
                            String h = p.getAttributeValue(null, "href");
                            if (h != null && cur.link.isEmpty()) cur.link = h;
                        }
                    }
                } else if (ev == XmlPullParser.TEXT || ev == XmlPullParser.CDSECT) {
                    if (cur != null) {
                        String tx = p.getText();
                        if (tx != null) {
                            if (tag.equals("title")) cur.title += tx;
                            else if (tag.equals("link") && cur.link.isEmpty()) cur.link = tx.trim();
                            else if (tag.equals("description") || tag.equals("summary") || tag.equals("content") || tag.equals("content:encoded")) {
                                if (cur.desc.length() < 3000) cur.desc += tx;
                            } else if ((tag.equals("pubDate") || tag.equals("updated") || tag.equals("published") || tag.equals("dc:date")) && cur.ts == 0) {
                                cur.ts = parseDate(tx);
                            }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    String n = p.getName();
                    if ((n.equals("item") || n.equals("entry")) && cur != null) {
                        cur.title = strip(cur.title);
                        if (cur.img.isEmpty()) {
                            java.util.regex.Matcher m = java.util.regex.Pattern.compile("<img[^>]+src=[\"']([^\"']+)[\"']").matcher(cur.desc);
                            if (m.find()) cur.img = m.group(1).replace("&amp;", "&");
                        }
                        cur.desc = strip(cur.desc);
                        if (cur.ts == 0) cur.ts = now - out.size() * 60000L;
                        if (cur.title.length() > 8 && cur.link.startsWith("http")) out.add(cur);
                        cur = null;
                    }
                    tag = "";
                }
                ev = p.next();
            }
        } finally {
            c.disconnect();
        }
        return out;
    }

    /** reads the top of an article page and returns its share picture (og:image / twitter:image), or "" */
    private static String pageImage(String link, String proxy) {
        try {
            HttpURLConnection c = open(link, proxy);
            c.setRequestProperty("Accept", "text/html,*/*");
            c.setRequestProperty("Range", "bytes=0-90000");
            try {
                int code = c.getResponseCode();
                if (code != 200 && code != 206) return "";
                InputStream in = c.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) >= 0) {
                    bo.write(b, 0, n);
                    if (bo.size() > 100000) break;
                }
                String h = new String(bo.toByteArray(), "UTF-8");
                java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                        "<meta[^>]+(?:property|name)=[\"'](?:og:image(?::secure_url)?|twitter:image(?::src)?)[\"'][^>]*content=[\"']([^\"']+)[\"']",
                        java.util.regex.Pattern.CASE_INSENSITIVE).matcher(h);
                if (!m.find()) {
                    m = java.util.regex.Pattern.compile(
                            "<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"'](?:og:image|twitter:image)[\"']",
                            java.util.regex.Pattern.CASE_INSENSITIVE).matcher(h);
                    if (!m.find()) return "";
                }
                String u = m.group(1).replace("&amp;", "&").trim();
                if (u.startsWith("//")) u = "https:" + u;
                else if (u.startsWith("/")) {
                    java.net.URL base = new java.net.URL(link);
                    u = base.getProtocol() + "://" + base.getHost() + u;
                }
                return u.startsWith("http") ? u : "";
            } finally {
                c.disconnect();
            }
        } catch (Throwable e) {
            return "";
        }
    }

    private static String key(String url) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
            byte[] d = md.digest(url.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format(Locale.US, "%02x", d[i] & 0xff));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(url.hashCode()) + "00000000";
        }
    }

    /**
     * downloads a story picture, shrinks it to about 560px wide and saves it as a small JPEG file.
     * Returns the page-relative address of the saved file, or "" when it could not be made.
     */
    private String thumb(String url, String referer, String proxy) throws Exception {
        if (!url.startsWith("http")) return "";
        String name = key(url) + ".jpg";
        File out = new File(imgDir, name);
        if (out.exists() && out.length() > 0) {
            //noinspection ResultOfMethodCallIgnored
            out.setLastModified(System.currentTimeMillis());
            return "../newsimg/" + name;
        }
        HttpURLConnection c = open(url, proxy);
        c.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8");
        try {
            java.net.URL ru = new java.net.URL(referer);
            c.setRequestProperty("Referer", ru.getProtocol() + "://" + ru.getHost() + "/");
        } catch (Exception ignored) {
        }
        try {
            if (c.getResponseCode() != 200) return "";
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) >= 0) {
                bo.write(b, 0, n);
                if (bo.size() > 4000000) return "";
            }
            byte[] raw = bo.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
            if (o.outWidth < 120 || o.outHeight < 80) return "";
            int ss = 1;
            while (o.outWidth / (ss * 2) >= 560) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length, o2);
            if (bm == null) return "";
            if (bm.getWidth() > 560) {
                int h = Math.round(bm.getHeight() * 560f / bm.getWidth());
                Bitmap sc = Bitmap.createScaledBitmap(bm, 560, Math.max(1, h), true);
                if (sc != bm) bm.recycle();
                bm = sc;
            }
            ByteArrayOutputStream jo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 74, jo);
            if (jo.size() > 110000) {
                jo.reset();
                bm.compress(Bitmap.CompressFormat.JPEG, 52, jo);
            }
            bm.recycle();
            FileOutputStream fo = new FileOutputStream(out);
            try {
                fo.write(jo.toByteArray());
            } finally {
                fo.close();
            }
            return "../newsimg/" + name;
        } finally {
            c.disconnect();
        }
    }

    /** pictures not used for four days are removed, so the cache never grows */
    private void cleanImages() {
        try {
            File[] l = imgDir.listFiles();
            if (l == null) return;
            long old = System.currentTimeMillis() - 4L * 24 * 3600 * 1000;
            for (File f : l) if (f.lastModified() < old) f.delete();
        } catch (Exception ignored) {
        }
    }
}
