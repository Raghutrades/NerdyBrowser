package com.nerdyintruder.nerdybrowser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StatFs;
import android.os.SystemClock;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.net.http.SslError;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.ScriptHandler;
import androidx.webkit.UserAgentMetadata;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.app.Dialog;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/**
 * NerdyBrowser shell.
 * - the toolbar, menus, settings, bookmarks and About page are a local web app (assets/www/index.html)
 *   shown in one small WebView called "chrome". Only that WebView can talk to this class.
 * - every tab is its own WebView. Pages from the internet never get any bridge to the app.
 * - PaneLayout puts several tabs on screen at once (split layouts).
 * - Blocker + assets/www/data/inject.js do the ad, tracker, popup and fingerprint blocking.
 */
public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String BASE = "https://" + HOST + "/assets/www/";
    static final String HOME = BASE + "pages/newtab.html";
    static final int REQ_FILE = 5501, REQ_LOCK = 5502, REQ_VPN = 5503, REQ_PICK = 5504;

    // ---------- tiny layout that places panes by fractions, with draggable dividers ----------
    static class PaneLayout extends FrameLayout {
        interface OnChange {
            void changed(float[][] rects);
        }

        static class Div {
            boolean vert;
            float pos, a, b, start;
            View view;
        }

        static final float EPS = 0.004f, MIN = 0.14f;
        float[][] rects = {{0, 0, 1, 1}};
        int gap = 0, handleColor = 0xFF888888;
        float density = 3f;
        OnChange listener;
        final ArrayList<Div> divs = new ArrayList<>();

        class Handle extends View {
            final Div d;
            final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            final RectF rf = new RectF();
            float startRaw;
            float[][] snap;

            Handle(Context c, Div d) {
                super(c);
                this.d = d;
            }

            @Override
            protected void onDraw(Canvas cv) {
                paint.setColor(handleColor);
                paint.setAlpha(210);
                float w = getWidth(), h = getHeight();
                float t = 4 * density, len = 46 * density;
                if (d.vert) {
                    float l = Math.min(h, len);
                    rf.set((w - t) / 2f, (h - l) / 2f, (w + t) / 2f, (h + l) / 2f);
                } else {
                    float l = Math.min(w, len);
                    rf.set((w - l) / 2f, (h - t) / 2f, (w + l) / 2f, (h + t) / 2f);
                }
                cv.drawRoundRect(rf, t, t, paint);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRaw = d.vert ? e.getRawX() : e.getRawY();
                        d.start = d.pos;
                        snap = new float[rects.length][];
                        for (int i = 0; i < rects.length; i++) snap[i] = rects[i].clone();
                        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float cur = d.vert ? e.getRawX() : e.getRawY();
                        float total = d.vert ? PaneLayout.this.getWidth() : PaneLayout.this.getHeight();
                        if (total > 0) drag(d, snap, (cur - startRaw) / total);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (listener != null) {
                            float[][] copy = new float[rects.length][];
                            for (int i = 0; i < rects.length; i++) copy[i] = rects[i].clone();
                            listener.changed(copy);
                        }
                        return true;
                    default:
                        return true;
                }
            }
        }

        PaneLayout(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
        }

        void drag(Div d, float[][] snap, float delta) {
            int ia = d.vert ? 0 : 1, ib = d.vert ? 2 : 3;
            float lo = -1f, hi = 1f;
            for (float[] r : snap) {
                if (Math.abs(r[ia] + r[ib] - d.start) < EPS) lo = Math.max(lo, MIN - r[ib]);
                if (Math.abs(r[ia] - d.start) < EPS) hi = Math.min(hi, r[ib] - MIN);
            }
            delta = Math.max(lo, Math.min(hi, delta));
            if (Math.abs(d.start + delta - 0.5f) < 0.02f && 0.5f - d.start >= lo && 0.5f - d.start <= hi) delta = 0.5f - d.start;
            for (int i = 0; i < snap.length && i < rects.length; i++) {
                float[] r = snap[i];
                if (Math.abs(r[ia] + r[ib] - d.start) < EPS) rects[i][ib] = r[ib] + delta;
                if (Math.abs(r[ia] - d.start) < EPS) {
                    rects[i][ia] = r[ia] + delta;
                    rects[i][ib] = r[ib] - delta;
                }
            }
            d.pos = d.start + delta;
            requestLayout();
        }

        void rebuildDividers() {
            for (Div d : divs) removeView(d.view);
            divs.clear();
            int n = 0;
            for (int i = 0; i < getChildCount(); i++) if (!(getChildAt(i) instanceof Handle)) n++;
            n = Math.min(n, rects.length);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j) continue;
                    float[] p = rects[i], q = rects[j];
                    if (Math.abs(p[0] + p[2] - q[0]) < EPS) {
                        float a = Math.max(p[1], q[1]), b = Math.min(p[1] + p[3], q[1] + q[3]);
                        if (b - a > EPS) addDiv(true, q[0], a, b);
                    }
                    if (Math.abs(p[1] + p[3] - q[1]) < EPS) {
                        float a = Math.max(p[0], q[0]), b = Math.min(p[0] + p[2], q[0] + q[2]);
                        if (b - a > EPS) addDiv(false, q[1], a, b);
                    }
                }
            }
            for (Div d : divs) {
                d.view = new Handle(getContext(), d);
                addView(d.view, new FrameLayout.LayoutParams(-2, -2));
            }
        }

        private void addDiv(boolean vert, float pos, float a, float b) {
            for (Div d : divs) {
                if (d.vert == vert && Math.abs(d.pos - pos) < EPS) {
                    d.a = Math.min(d.a, a);
                    d.b = Math.max(d.b, b);
                    return;
                }
            }
            Div d = new Div();
            d.vert = vert;
            d.pos = pos;
            d.a = a;
            d.b = b;
            divs.add(d);
        }

        void invalidateHandles() {
            for (int i = 0; i < getChildCount(); i++) if (getChildAt(i) instanceof Handle) getChildAt(i).invalidate();
        }

        @Override
        protected void onMeasure(int wms, int hms) {
            int w = MeasureSpec.getSize(wms), h = MeasureSpec.getSize(hms);
            setMeasuredDimension(w, h);
            int hit = Math.round(30 * density);
            int pi = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Handle) {
                    Div d = ((Handle) c).d;
                    int cw = d.vert ? hit : Math.round((d.b - d.a) * w);
                    int ch = d.vert ? Math.round((d.b - d.a) * h) : hit;
                    c.measure(MeasureSpec.makeMeasureSpec(Math.max(0, cw), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(Math.max(0, ch), MeasureSpec.EXACTLY));
                } else {
                    float[] r = rects[Math.min(pi, rects.length - 1)];
                    pi++;
                    int cw = Math.max(0, Math.round(r[2] * w) - gap);
                    int ch = Math.max(0, Math.round(r[3] * h) - gap);
                    c.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
                }
            }
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t;
            int pi = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Handle) {
                    Div d = ((Handle) c).d;
                    int x = d.vert ? Math.round(d.pos * w) - c.getMeasuredWidth() / 2 : Math.round(d.a * w);
                    int y = d.vert ? Math.round(d.a * h) : Math.round(d.pos * h) - c.getMeasuredHeight() / 2;
                    c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
                } else {
                    float[] rc = rects[Math.min(pi, rects.length - 1)];
                    pi++;
                    int x = Math.round(rc[0] * w) + gap / 2;
                    int y = Math.round(rc[1] * h) + gap / 2;
                    c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
                }
            }
        }
    }

    // ---------- pull-down-to-refresh indicator ----------
    static class PullView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rf = new RectF();
        float progress;
        int color = 0xFFF0642F;

        PullView(Context c) {
            super(c);
            setVisibility(GONE);
            setElevation(14f);
        }

        void show(float pr) {
            progress = pr;
            animate().cancel();
            setRotation(0f);
            setAlpha(Math.min(1f, pr * 1.6f));
            setVisibility(VISIBLE);
            invalidate();
        }

        void spin() {
            progress = 1f;
            setAlpha(1f);
            setVisibility(VISIBLE);
            animate().rotationBy(1080f).setDuration(900).start();
        }

        void hideNow() {
            animate().cancel();
            setVisibility(GONE);
            setRotation(0f);
            progress = 0f;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f - 2f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(w / 11f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(color);
            rf.set(w * 0.28f, h * 0.28f, w * 0.72f, h * 0.72f);
            cv.drawArc(rf, -90f, 290f * progress, false, p);
        }
    }

    // ---------- a browser tab ----------
    class Tab {
        int id;
        WebView web;
        String title = "New tab", url = "";
        int progress = 100, blocked, alerts;
        boolean loading, desktop, js = true, images = true, dark, canBack, canFwd;
        String pendingHttp;
        int refreshSec;
        boolean picking, autoDesk;
        Runnable refreshTask;
        ScriptHandler script;
        final HashMap<String, Integer> hostCounts = new HashMap<>();
        final LinkedHashMap<String, String[]> sniffed = new LinkedHashMap<>(); // media links the page asked for: url -> {referer}

        boolean prevDesktop;

        boolean isHome() {
            return url.startsWith(BASE + "pages/");
        }

        String host() {
            try {
                String h = Uri.parse(url).getHost();
                return h == null ? "" : h;
            } catch (Exception e) {
                return "";
            }
        }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Dl dl;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private final HashSet<String> httpOk = new HashSet<>();
    private SharedPreferences vault;
    private JSONObject st = new JSONObject();
    private FrameLayout root;
    private PaneLayout paneLayout;
    private WebView chrome;
    private TextView fab;
    private View lockCover, customView;
    private WebChromeClient.CustomViewCallback customCb;
    private WebViewAssetLoader loader;
    private final Blocker blocker = new Blocker();
    private String injectTpl = "", cineJs = "";
    private String defaultUa = "", chromeVer = "120.0.0.0";
    private float density = 3f;
    private int nextId = 1, activePane = 0, barPx, totalBlocked;
    private int[] paneTabs = new int[]{0};
    private float[][] rects = {{0, 0, 1, 1}};
    private int accent = 0xFFF0642F, lineCol = 0xFFE6E6E6;
    private boolean chromeFull = true, barBottom, fullscreen, appDark, ready, statePosted, findOpen, locked;
    private long backAt, stoppedAt;
    private String pendingOpen;
    private boolean pendingShare, pendingApp, appMode;
    private String pendingWs;
    private final HashMap<String, Bitmap> favicons = new HashMap<>();
    private ValueCallback<Uri[]> fileCb;
    private Vpn vpn;
    private boolean vpnUp, barsHidden;
    private String vpnMsg = "", curProxy = "";
    private long lastToggle;
    private PullView pullView;
    private float pullStartY;
    private boolean pullArmed, pullActive;
    private int pullSeq, edgeSide;
    private float edgeX0, edgeY0, edgeDx;
    private boolean edgeOn;
    private TextView edgeHint, mediaFab, closeHint, actPill;
    private int closeSeq;
    private boolean closeArmed, closeActive;
    private float closeStartY;
    private boolean mediaPolling;
    private float mfDx, mfDy, mfX0, mfY0;
    private boolean mfMoved;
    private int mfMiss;
    private final ArrayList<FrameLayout> paneWraps = new ArrayList<>();
    private String injectSigLast = "", pickerJs = "", mediaJs = "";
    private final Runnable applyTask = this::applyAllNow;

    // =====================================================================================
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        vault = getSharedPreferences("nb_vault", MODE_PRIVATE);
        try {
            st = new JSONObject(vault.getString("settings", "{}"));
        } catch (Exception e) {
            st = new JSONObject();
        }
        density = getResources().getDisplayMetrics().density;
        try {
            defaultUa = WebSettings.getDefaultUserAgent(this);
            Matcher m = Pattern.compile("Chrome/([0-9.]+)").matcher(defaultUa);
            if (m.find()) chromeVer = m.group(1);
        } catch (Exception ignored) {
        }
        blocker.load(getAssets());
        blocker.update(st);
        vpn = new Vpn(getApplicationContext(), (up, msg) -> ui.post(() -> {
            vpnUp = up;
            vpnMsg = msg != null ? msg : (up ? "Connected" : "Disconnected");
            pushVpn();
            postState();
        }));
        applyProxy();
        dl = new Dl(getApplicationContext(), new Dl.Host() {
            @Override
            public void changed() {
            }

            @Override
            public void finished(final Dl.Task t) {
                ui.post(() -> {
                    toast("Downloaded " + t.name);
                    js("window.NB&&NB.event('dl',false)");
                });
            }
        });
        applyDl();
        injectTpl = readAsset("www/data/inject.js");
        cineJs = readAsset("www/data/yt-cinema.js");
        pickerJs = readAsset("www/data/picker.js");
        mediaJs = readAsset("www/data/media.js");
        barBottom = "bottom".equals(st.optString("toolbarPos", "top"));
        locked = st.optBoolean("appLock", false);
        if (st.optBoolean("wipeExit", true)) wipeData();

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        String bg = vault.getString("bg", "#FFF7F0");
        int bgc = parseColor(bg, 0xFFFFF7F0);
        root = new FrameLayout(this);
        root.setBackgroundColor(bgc);
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 28) {
                android.view.DisplayCutout dc = ins.getDisplayCutout();
                cutL = dc == null ? 0 : dc.getSafeInsetLeft();
                cutT = dc == null ? 0 : dc.getSafeInsetTop();
                cutR = dc == null ? 0 : dc.getSafeInsetRight();
                cutB = dc == null ? 0 : dc.getSafeInsetBottom();
            }
            applyRootPadding();
            return ins;
        });

        paneLayout = new PaneLayout(this);
        paneLayout.listener = this::onRectsDragged;
        root.addView(paneLayout, new FrameLayout.LayoutParams(-1, -1));

        chrome = new WebView(this);
        chrome.setBackgroundColor(Color.TRANSPARENT);
        chrome.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = chrome.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        chrome.addJavascriptInterface(new Bridge(), "NBAndroid");
        chrome.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/")) {
                    WebResourceResponse res = loader.shouldInterceptRequest(u);
                    return res != null ? res : blockedResponse();
                }
                return blockedResponse(); // the interface never touches the network
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc)) openNew(u.toString(), false);
                return true;
            }
        });
        chrome.setWebChromeClient(new WebChromeClient());
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(chrome, clp);

        fab = new TextView(this);
        fab.setText("NB");
        fab.setTextColor(Color.WHITE);
        fab.setTextSize(12);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(accent);
        fab.setBackground(gd);
        fab.setVisibility(View.GONE);
        fab.setAlpha(0.6f);
        fab.setOnClickListener(v -> {
            setFullscreen(false);
            js("window.NB&&NB.event('fs',false)");
        });
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END);
        flp.setMargins(0, 0, dp(14), dp(70));
        pullView = new PullView(this);
        root.addView(pullView, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        root.addView(fab, flp);
        edgeHint = new TextView(this);
        edgeHint.setTextColor(Color.WHITE);
        edgeHint.setTextSize(26);
        edgeHint.setGravity(Gravity.CENTER);
        GradientDrawable eg = new GradientDrawable();
        eg.setShape(GradientDrawable.OVAL);
        eg.setColor(0xE6222222);
        edgeHint.setBackground(eg);
        edgeHint.setVisibility(View.GONE);
        root.addView(edgeHint, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER_VERTICAL | Gravity.START));
        closeHint = new TextView(this);
        closeHint.setTextColor(Color.WHITE);
        closeHint.setTextSize(14);
        closeHint.setTypeface(Typeface.DEFAULT_BOLD);
        closeHint.setGravity(Gravity.CENTER);
        closeHint.setPadding(dp(18), dp(10), dp(18), dp(10));
        GradientDrawable cg = new GradientDrawable();
        cg.setCornerRadius(dp(24));
        cg.setColor(0xF0222222);
        closeHint.setBackground(cg);
        closeHint.setElevation(dp(8));
        closeHint.setVisibility(View.GONE);
        FrameLayout.LayoutParams chp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        chp.setMargins(0, 0, 0, dp(40));
        root.addView(closeHint, chp);
        actPill = new TextView(this);
        actPill.setTextColor(Color.WHITE);
        actPill.setTextSize(15);
        actPill.setTypeface(Typeface.DEFAULT_BOLD);
        actPill.setGravity(Gravity.CENTER);
        actPill.setSingleLine(true);
        actPill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        actPill.setMaxWidth(dp(300));
        actPill.setPadding(dp(18), dp(11), dp(18), dp(11));
        GradientDrawable ag = new GradientDrawable();
        ag.setCornerRadius(dp(26));
        ag.setColor(0xF2202028);
        actPill.setBackground(ag);
        actPill.setElevation(dp(10));
        actPill.setVisibility(View.GONE);
        FrameLayout.LayoutParams app = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        root.addView(actPill, app);
        buildMediaFab();

        applyWindowFlags();
        applySystemUi(bgc, true);
        handleIntent(getIntent());
        chrome.loadUrl(BASE + "index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        String wsId = i.getStringExtra("nb_ws");
        if (wsId != null && !wsId.isEmpty()) {
            if (appMode) exitAppMode(false);
            if (ready) js("window.NB&&NB.openWorkspaceId(" + JSONObject.quote(wsId) + ")");
            else pendingWs = wsId;
            i.removeExtra("nb_ws");
            return;
        }
        String act = i.getAction();
        String text = null;
        boolean share = false;
        if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) text = i.getData().toString();
        else if (Intent.ACTION_SEND.equals(act)) {
            text = i.getStringExtra(Intent.EXTRA_TEXT);
            share = true;
        }
        if (text == null || text.trim().isEmpty()) return;
        boolean app = !share && i.getBooleanExtra("nb_webapp", false);
        if (!app && appMode) exitAppMode(false);
        if (app) {
            if (ready) openApp(text.trim());
            else {
                pendingOpen = text.trim();
                pendingApp = true;
            }
            return;
        }
        String fn = share ? "shared" : "open";
        if (ready) js("window.NB&&NB." + fn + "(" + JSONObject.quote(text.trim()) + ")");
        else {
            pendingOpen = text.trim();
            pendingShare = share;
        }
    }

    // =====================================================================================
    //  web apps: a bookmark / page pinned to the home screen opens full screen, like an app
    // =====================================================================================
    private void openApp(String url) {
        Tab found = null;
        try {
            String site = Blocker.site(Uri.parse(url).getHost());
            for (Tab t : tabs) if (!t.isHome() && Blocker.site(t.host()).equals(site)) { found = t; break; }
        } catch (Exception ignored) {
        }
        if (found != null) {
            showInPane(found, Math.max(0, activePane));
            focusTab(found);
        } else {
            openNew(url, false);
        }
        ui.postDelayed(() -> enterAppMode(), 250);
    }

    private void enterAppMode() {
        appMode = true;
        chromeFull = false;
        setFullscreen(true);
        fab.setVisibility(View.GONE); // no button in app mode; Back leaves it
        js("window.NB&&NB.event('fs',true)");
    }

    private void exitAppMode(boolean toBackground) {
        appMode = false;
        setFullscreen(false);
        js("window.NB&&NB.event('fs',false)");
        if (toBackground) moveTaskToBack(true);
    }

    private Bitmap appIcon(String title, String host) {
        int n = 288;
        Bitmap bm = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Bitmap fav = favicons.get(host);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (fav != null && fav.getWidth() >= 48) {
            c.drawColor(Color.WHITE);
            int w = Math.round(n * 0.56f);
            p.setFilterBitmap(true);
            c.drawBitmap(fav, null, new RectF((n - w) / 2f, (n - w) / 2f, (n + w) / 2f, (n + w) / 2f), p);
        } else {
            int[] cols = {0xFF1F8A70, 0xFFE4572E, 0xFF3A6EA5, 0xFF8E44AD, 0xFFD4A017, 0xFFC2185B, 0xFF00796B, 0xFF5D4037};
            c.drawColor(cols[Math.abs(host.hashCode()) % cols.length]);
            p.setColor(Color.WHITE);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(n * 0.42f);
            p.setTextAlign(Paint.Align.CENTER);
            String l = (title == null || title.trim().isEmpty() ? host : title.trim()).substring(0, 1).toUpperCase(Locale.ROOT);
            c.drawText(l, n / 2f, n / 2f - (p.descent() + p.ascent()) / 2f, p);
        }
        return bm;
    }

    private void pinApp(String title, String url) {
        try {
            if (Build.VERSION.SDK_INT < 26) {
                toast("Adding to the home screen needs Android 8 or newer");
                return;
            }
            Uri u = Uri.parse(url);
            if (u.getHost() == null || !("http".equals(u.getScheme()) || "https".equals(u.getScheme()))) {
                toast("Open a website first");
                return;
            }
            ShortcutManager sm = (ShortcutManager) getSystemService(Context.SHORTCUT_SERVICE);
            if (sm == null || !sm.isRequestPinShortcutSupported()) {
                toast("Your launcher cannot add shortcuts. Try the default launcher.");
                return;
            }
            String host = u.getHost();
            String label = (title == null || title.trim().isEmpty() ? host : title.trim());
            if (label.length() > 24) label = label.substring(0, 24);
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(Intent.ACTION_VIEW);
            i.setData(u);
            i.putExtra("nb_webapp", true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            ShortcutInfo info = new ShortcutInfo.Builder(this, "webapp-" + Integer.toHexString(url.hashCode()))
                    .setShortLabel(label).setLongLabel(label)
                    .setIcon(Icon.createWithAdaptiveBitmap(appIcon(label, host)))
                    .setIntent(i).build();
            sm.requestPinShortcut(info, null);
        } catch (Exception e) {
            toast("Could not add the shortcut");
        }
    }

    // =====================================================================================
    //  JavaScript bridge: only the local interface page (chrome) gets this
    // =====================================================================================
    class Bridge {
        @JavascriptInterface
        public String get(String k) {
            return vault.getString(k, "");
        }

        @JavascriptInterface
        public void set(String k, String v) {
            vault.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public void ready() {
            ui.post(() -> {
                if (ready) return;
                ready = true;
                ArrayList<String> urls = new ArrayList<>();
                if (st.optBoolean("restoreTabs", false)) {
                    try {
                        JSONArray a = new JSONArray(vault.getString("session", "[]"));
                        for (int i = 0; i < a.length() && i < 12; i++) urls.add(a.getString(i));
                    } catch (Exception ignored) {
                    }
                }
                if (urls.isEmpty()) urls.add(HOME);
                Tab first = null;
                for (String u : urls) {
                    Tab t = createTab(u);
                    if (first == null) first = t;
                }
                paneTabs = new int[]{first.id};
                rebuildPanes();
                if (st.optBoolean("vpnAuto", true)) ui.postDelayed(() -> {
                    if (!vpnUp) autoVpn();
                }, 700);
                if (pendingOpen != null && pendingApp) {
                    String p = pendingOpen;
                    pendingOpen = null;
                    pendingApp = false;
                    openApp(p);
                } else if (pendingOpen != null) {
                    String p = pendingOpen;
                    pendingOpen = null;
                    js("window.NB&&NB." + (pendingShare ? "shared" : "open") + "(" + JSONObject.quote(p) + ")");
                }
                if (pendingWs != null) {
                    final String w = pendingWs;
                    pendingWs = null;
                    ui.postDelayed(() -> js("window.NB&&NB.openWorkspaceId(" + JSONObject.quote(w) + ")"), 600);
                }
                postState();
            });
        }

        @JavascriptInterface
        public String state() {
            return stateJson();
        }

        @JavascriptInterface
        public String stats() {
            Tab t = activeTab();
            JSONObject o = new JSONObject();
            try {
                JSONObject hs = new JSONObject();
                if (t != null) for (Map.Entry<String, Integer> e : t.hostCounts.entrySet()) hs.put(e.getKey(), e.getValue());
                o.put("hosts", hs);
                o.put("page", t == null ? 0 : t.blocked);
                o.put("total", totalBlocked);
            o.put("vpn", vpnUp);
            o.put("hidden", barsHidden);
            } catch (JSONException ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void chrome(final String mode, final int h) {
            ui.post(() -> {
                boolean full = "full".equals(mode), sheet = "sheet".equals(mode);
                chromeFull = full || sheet;
                if (chromeFull && mediaFab != null) mediaFab.setVisibility(View.GONE);
                else if (mediaFab != null) checkMediaFab();
                if (h > 0) barPx = Math.round(h * density);
                updateMargins();
                if (chromeFull) chrome.requestFocus();
                for (Tab t : tabs) {
                    if (full) sleepTab(t);
                    else if (inPane(t.id) || !st.optBoolean("sleepTabs", true)) t.web.onResume();
                }
            });
        }

        @JavascriptInterface
        public void settings(final String json) {
            ui.post(() -> {
                boolean wasPc = st.optBoolean("pcMode", false);
                try {
                    st = new JSONObject(json);
                } catch (Exception e) {
                    return;
                }
                applyAll();
                boolean nowPc = st.optBoolean("pcMode", false);
                if (wasPc != nowPc) applyPcMode(nowPc);
            });
        }

        @JavascriptInterface
        public void bars(final String bg, final boolean dark, final String acc, final String line) {
            ui.post(() -> {
                boolean darkChanged = appDark != dark;
                appDark = dark;
                accent = parseColor(acc, accent);
                lineCol = parseColor(line, lineCol);
                int c = parseColor(bg, 0xFFFFFFFF);
                vault.edit().putString("bg", bg).apply();
                root.setBackgroundColor(c);
                applySystemUi(c, !dark);
                GradientDrawable gd = new GradientDrawable();
                gd.setShape(GradientDrawable.OVAL);
                gd.setColor(accent);
                fab.setBackground(gd);
                updateBorders();
                if (darkChanged) for (Tab t : tabs) refreshScript(t);
            });
        }

        @JavascriptInterface
        public void pinApp(final String title, final String url) {
            ui.post(() -> MainActivity.this.pinApp(title, url));
        }

        @JavascriptInterface
        public void newTab(final String url, final boolean background) {
            ui.post(() -> openNew(url == null || url.isEmpty() ? HOME : url, background));
        }

        @JavascriptInterface
        public void closeTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.closeTab(t);
            });
        }

        @JavascriptInterface
        public void closeAll() {
            ui.post(() -> replaceAllTabs());
        }

        @JavascriptInterface
        public void openWorkspace(final String tabsJson, final String panesJson) {
            ui.post(() -> MainActivity.this.openWorkspace(tabsJson, panesJson));
        }

        @JavascriptInterface
        public void pinWorkspace(final String id, final String name) {
            ui.post(() -> MainActivity.this.pinWorkspace(id, name));
        }

        @JavascriptInterface
        public void reopenTab() {
            ui.post(() -> {
                if (!reopenClosed(0)) toast("No closed tabs to reopen");
            });
        }

        @JavascriptInterface
        public void reopenAt(final int i) {
            ui.post(() -> reopenClosed(i));
        }

        @JavascriptInterface
        public void clearClosed() {
            closedTabs.clear();
        }

        @JavascriptInterface
        public String closedJson() {
            JSONArray a = new JSONArray();
            for (String[] x : closedTabs) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("url", x[0]);
                    o.put("title", x[1]);
                    a.put(o);
                } catch (JSONException ignored) {
                }
            }
            return a.toString();
        }

        @JavascriptInterface
        public void cycleTab(final int d) {
            ui.post(() -> {
                if (tabs.size() < 2) return;
                int i = tabs.indexOf(activeTab());
                i = (((i < 0 ? 0 : i) + d) % tabs.size() + tabs.size()) % tabs.size();
                showInPane(tabs.get(i), activePane);
                postState();
            });
        }

        @JavascriptInterface
        public void selectIndex(final int n) {
            ui.post(() -> {
                if (tabs.isEmpty()) return;
                int i = n >= 9 ? tabs.size() - 1 : n - 1;
                if (i < 0 || i >= tabs.size()) return;
                showInPane(tabs.get(i), activePane);
                postState();
            });
        }

        @JavascriptInterface
        public void focusChrome() {
            ui.post(() -> {
                if (chrome != null) chrome.requestFocus();
            });
        }

        @JavascriptInterface
        public void selectTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) {
                    showInPane(t, activePane);
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void assignPane(final int id, final int pane) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null && pane >= 0 && pane < paneTabs.length) {
                    showInPane(t, pane);
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void setPane(final int pane) {
            ui.post(() -> {
                if (pane >= 0 && pane < paneTabs.length) {
                    activePane = pane;
                    updateBorders();
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void layout(final String rectsJson, final String name) {
            ui.post(() -> {
                try {
                    JSONArray a = new JSONArray(rectsJson);
                    float[][] r = new float[a.length()][4];
                    for (int i = 0; i < a.length(); i++) {
                        JSONArray q = a.getJSONArray(i);
                        for (int k = 0; k < 4; k++) r[i][k] = (float) q.getDouble(k);
                    }
                    if (r.length == 0) return;
                    layoutName = name;
                    setLayoutRects(r);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void go(final String url) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) load(t, url);
            });
        }

        @JavascriptInterface
        public void back() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && t.web.canGoBack()) t.web.goBack();
            });
        }

        @JavascriptInterface
        public void forward() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && t.web.canGoForward()) t.web.goForward();
            });
        }

        @JavascriptInterface
        public void reload() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null) return;
                if (t.loading) t.web.stopLoading();
                else t.web.reload();
            });
        }

        @JavascriptInterface
        public void find(final String q) {
            ui.post(() -> {
                Tab t = activeTab();
                findOpen = true;
                if (t == null) return;
                if (q == null || q.isEmpty()) t.web.clearMatches();
                else t.web.findAllAsync(q);
            });
        }

        @JavascriptInterface
        public void findNext(final boolean fwd) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) t.web.findNext(fwd);
            });
        }

        @JavascriptInterface
        public void findClose() {
            ui.post(() -> {
                findOpen = false;
                Tab t = activeTab();
                if (t != null) t.web.clearMatches();
            });
        }

        @JavascriptInterface
        public void tabFlag(final int id, final String flag, final boolean v) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t == null) return;
                if ("desktop".equals(flag)) {
                    if (v && blocker.wantsMobile(t.host())) {
                        toast("Spotify plays on the phone layout, so it stays on it");
                        return;
                    }
                    t.desktop = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("js".equals(flag)) {
                    t.js = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("images".equals(flag)) {
                    t.images = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("dark".equals(flag)) {
                    t.dark = v;
                    refreshScript(t);
                    t.web.evaluateJavascript("window.__nbDark&&window.__nbDark(" + v + ")", null);
                }
                postState();
            });
        }

        @JavascriptInterface
        public void runScript(final String code) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) t.web.evaluateJavascript(code, null);
            });
        }

        @JavascriptInterface
        public void share() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && !t.isHome()) shareText(t.url);
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            ui.post(() -> MainActivity.this.shareText(text));
        }

        @JavascriptInterface
        public void copy(final String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("NerdyBrowser", text));
                toast("Copied");
            });
        }

        @JavascriptInterface
        public void copyLink() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && !t.isHome()) copy(t.url);
            });
        }

        @JavascriptInterface
        public void fullscreen(final boolean on) {
            ui.post(() -> setFullscreen(on));
        }

        @JavascriptInterface
        public void burn() {
            ui.post(() -> MainActivity.this.burn());
        }

        @JavascriptInterface
        public void clearData(final String what) {
            ui.post(() -> {
                if ("cookies".equals(what)) {
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                } else if ("cache".equals(what)) {
                    for (Tab t : tabs) t.web.clearCache(true);
                }
                toast("Cleared");
            });
        }

        @JavascriptInterface
        public void exit() {
            ui.post(() -> finishAndRemoveTask());
        }

        @JavascriptInterface
        public void toast(final String m) {
            ui.post(() -> MainActivity.this.toast(m));
        }

        @JavascriptInterface
        public void print() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null) return;
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    String name = t.title == null || t.title.isEmpty() ? "page" : t.title;
                    pm.print(name, t.web.createPrintDocumentAdapter(name), new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    toast("Can't print this page");
                }
            });
        }

        @JavascriptInterface
        public void swapPanes(final int a, final int b) {
            ui.post(() -> swapPaneTabs(a, b));
        }

        @JavascriptInterface
        public void rotatePanes() {
            ui.post(() -> MainActivity.this.rotatePanes());
        }

        @JavascriptInterface
        public void moveTab(final int id, final int dir) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.moveTab(t, dir);
            });
        }

        @JavascriptInterface
        public void dupTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) {
                    Tab nt = createTab(t.isHome() ? HOME : t.url);
                    nt.desktop = t.desktop;
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void tabRefresh(final int id, final int sec) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) setRefresh(t, sec);
            });
        }

        @JavascriptInterface
        public void orient(final String mode) {
            ui.post(() -> setOrient(mode));
        }

        @JavascriptInterface
        public String vpnInfo() {
            return vpnJson();
        }

        @JavascriptInterface
        public void vpnSave(final String text) {
            vault.edit().putString("vpncfg", text == null ? "" : text.trim()).apply();
            ui.post(() -> {
                vpnMsg = vpnConfig().isEmpty() ? "" : "Saved on this phone";
                pushVpn();
            });
        }

        @JavascriptInterface
        public void vpnClear() {
            vault.edit().remove("vpncfg").apply();
            ui.post(() -> {
                if (vpnUp) vpn.disconnect();
                vpnMsg = "";
                pushVpn();
            });
        }

        @JavascriptInterface
        public void vpnConnect() {
            ui.post(() -> startVpn());
        }

        @JavascriptInterface
        public void vpnAutoSetup() {
            ui.post(() -> autoVpn());
        }

        @JavascriptInterface
        public void pickElement() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null || t.isHome()) {
                    toast("Open a page first");
                    return;
                }
                t.picking = true;
                t.web.evaluateJavascript(pickerJs, null);
            });
        }

        @JavascriptInterface
        public void mediaPage() {
            ui.post(() -> openMediaList(true));
        }

        @JavascriptInterface
        public void mediaPageOld() {
            ui.post(() -> {
                final Tab t = activeTab();
                if (t == null || t.isHome()) {
                    toast("Open a page first");
                    return;
                }
                if (!st.optBoolean("dlMedia", true)) {
                    toast("Turn on Media downloader in Settings first");
                    return;
                }
                t.web.evaluateJavascript("(function(){if(window.__nbmPage){window.__nbmPage();return 1}return 0})()", value -> {
                    if (!"1".equals(value)) {
                        try {
                            JSONObject o = new JSONObject();
                            o.put("mode", "page");
                            o.put("page", t.url);
                            o.put("title", t.title == null ? "" : t.title);
                            o.put("items", new JSONArray());
                            mediaFromPage(t, o.toString());
                        } catch (JSONException ignored) {
                        }
                    }
                });
            });
        }

        @JavascriptInterface
        public void vpnWarpDraft() {
            new Thread(() -> {
                try {
                    final String cfg = Vpn.registerWarp();
                    ui.post(() -> js("window.NB&&NB.vpnDraft(" + JSONObject.quote(cfg) + "," + JSONObject.quote("Free config created. Check it, then tap Save and use.") + ")"));
                } catch (final Exception e) {
                    ui.post(() -> toast("Could not create it: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage())));
                }
            }).start();
        }

        @JavascriptInterface
        public String vpnOwnDraft(final String endpoint, final String serverKey, final String clientAddr) {
            try {
                return Vpn.makeOwn(endpoint, serverKey, clientAddr).toString();
            } catch (Exception e) {
                return "{\"error\":" + JSONObject.quote(e.getMessage() == null ? e.toString() : e.getMessage()) + "}";
            }
        }

        @JavascriptInterface
        public String vpnSaved() {
            return vpnConfig();
        }

        @JavascriptInterface
        public void downloadRetry(final long id) {
            ui.post(() -> retryDownload(id));
        }

        @JavascriptInterface
        public void vpnDisconnect() {
            ui.post(() -> {
                vpnMsg = "Disconnecting...";
                pushVpn();
                vpn.disconnect();
            });
        }

        @JavascriptInterface
        public void downloadPause(final long id) {
            ui.post(() -> {
                if (dl != null) dl.pause(id);
            });
        }

        @JavascriptInterface
        public void downloadResume(final long id) {
            ui.post(() -> {
                if (dl != null) dl.resume(id);
            });
        }

        /** kilobytes per second, 0 = no limit */
        @JavascriptInterface
        public void downloadLimit(final long id, final long kbps) {
            ui.post(() -> {
                if (dl != null) dl.setLimit(id, kbps * 1024L);
            });
        }

        @JavascriptInterface
        public void downloadsAll(final boolean pause) {
            ui.post(() -> {
                if (dl == null) return;
                if (pause) dl.pauseAll();
                else dl.resumeAll();
            });
        }

        @JavascriptInterface
        public String downloadsList() {
            return downloadsJson();
        }

        @JavascriptInterface
        public void downloadOpen(final long id) {
            ui.post(() -> openDownload(id));
        }

        @JavascriptInterface
        public void downloadRemove(final long id) {
            ui.post(() -> {
                if (dl != null && dl.owns(id)) {
                    dl.remove(id);
                    return;
                }
                if (id < 0) {
                    synchronized (jobs) {
                        Job j = jobs.remove(id);
                        if (j != null) j.cancel = true;
                    }
                    return;
                }
                try {
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).remove(id);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void openExternal() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null || !t.url.startsWith("http")) {
                    toast("Open a page first");
                    return;
                }
                try {
                    startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, Uri.parse(t.url)), "Open with"));
                } catch (Exception e) {
                    toast("No app can open this");
                }
            });
        }

        @JavascriptInterface
        public void pickImportFile() {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    toast("No file picker found");
                }
            });
        }

        @JavascriptInterface
        public void downloads() {
            ui.post(() -> {
                try {
                    startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
                } catch (Exception e) {
                    toast("No downloads app found");
                }
            });
        }
    }

    private String layoutName = "single";

    // =====================================================================================
    //  tabs and panes
    // =====================================================================================
    private Tab tabById(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    private Tab activeTab() {
        if (activePane < 0 || activePane >= paneTabs.length) return tabs.isEmpty() ? null : tabs.get(0);
        return tabById(paneTabs[activePane]);
    }

    private boolean inPane(int id) {
        for (int p : paneTabs) if (p == id) return true;
        return false;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private Tab createTab(String url) {
        return createTab(url, null);
    }

    private Tab createTab(String url, Boolean desk) {
        final Tab t = new Tab();
        t.id = nextId++;
        t.web = new WebView(this);
        t.web.setBackgroundColor(Color.WHITE);
        t.desktop = desk != null ? desk : (st.optBoolean("desktopDefault", false) || st.optBoolean("pcMode", false));
        t.js = st.optBoolean("js", true);
        t.images = st.optBoolean("images", true);
        applySettings(t);
        t.web.setWebViewClient(new TabClient(t));
        t.web.setWebChromeClient(new TabChrome(t));
        t.web.setDownloadListener((u, ua, cd, mime, len) -> askDownload(u, ua, cd, mime));
        t.web.setFindListener((idx, cnt, done) -> js("window.NB&&NB.found(" + idx + "," + cnt + ")"));
        t.web.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) focusTab(t);
            pullTouch(t, e);
            edgeTouch(t, e);
            closeTouch(t, e);
            return false;
        });
        t.web.setOnLongClickListener(v -> {
            WebView.HitTestResult r = ((WebView) v).getHitTestResult();
            int type = r.getType();
            final String ex = r.getExtra();
            if (ex == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                showLinkMenu(ex, null);
                return true;
            }
            if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                Message m = new Handler(Looper.getMainLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        String u = msg.getData().getString("url");
                        showLinkMenu(u == null ? ex : u, ex);
                    }
                }.obtainMessage();
                ((WebView) v).requestFocusNodeHref(m);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                showLinkMenu(null, ex);
                return true;
            }
            return false;
        });
        t.web.setOnScrollChangeListener((v, sx, sy, ox, oy) -> {
            if (!st.optBoolean("autoHide", true) || activeTab() != t) return;
            if (SystemClock.elapsedRealtime() - lastToggle < 450) return;
            int dy = sy - oy;
            if (sy < 40) setBarsHidden(false);
            else if (dy > 8) setBarsHidden(true);
            else if (dy < -8) setBarsHidden(false);
        });
        tabs.add(t);
        refreshScript(t);
        if (url != null && !url.isEmpty()) load(t, url);
        return t;
    }

    private void destroyTab(Tab t) {
        if (t.refreshTask != null) ui.removeCallbacks(t.refreshTask);
        try {
            if (t.script != null) t.script.remove();
        } catch (Exception ignored) {
        }
        ViewGroup p = (ViewGroup) t.web.getParent();
        if (p != null) p.removeView(t.web);
        t.web.stopLoading();
        t.web.setWebViewClient(new WebViewClient());
        t.web.setWebChromeClient(null);
        t.web.destroy();
    }

    private void openNew(String url, boolean background) {
        Tab nt = createTab(url);
        if (!background) showInPane(nt, activePane);
        else toast("Opened in background");
        postState();
    }

    // ---------- closed tabs (reopen), PC mode, keyboard shortcuts ----------
    private final java.util.concurrent.CopyOnWriteArrayList<String[]> closedTabs = new java.util.concurrent.CopyOnWriteArrayList<>();
    private final HashSet<Integer> swallowed = new HashSet<>();

    private boolean reopenClosed(int idx) {
        if (idx < 0 || idx >= closedTabs.size()) return false;
        String[] c = closedTabs.remove(idx);
        Tab nt = createTab(c[0]);
        if ("1".equals(c[2]) && !nt.desktop) {
            nt.desktop = true;
            applySettings(nt);
            nt.web.reload();
        }
        showInPane(nt, activePane);
        postState();
        return true;
    }

    private void applyPcMode(boolean on) {
        for (Tab t : tabs) {
            boolean before = t.desktop;
            if (on) {
                t.prevDesktop = t.desktop;
                if (!blocker.wantsMobile(t.host())) t.desktop = true;
            } else {
                t.desktop = t.prevDesktop;
            }
            if (t.desktop != before) {
                applySettings(t);
                if (!t.isHome()) t.web.reload();
            }
        }
        postState();
    }

    private String shortcutFor(KeyEvent e) {
        if (locked) return null;
        boolean ctrl = e.isCtrlPressed() || e.isMetaPressed(), shift = e.isShiftPressed(), alt = e.isAltPressed();
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_F5) return "reload";
        if (k == KeyEvent.KEYCODE_F11) return "fs";
        if (k == KeyEvent.KEYCODE_F3) return shift ? "findprev" : "findnext";
        if (k == KeyEvent.KEYCODE_F6) return "focus";
        if (alt && !ctrl) {
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) return "back";
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) return "fwd";
            if (k == KeyEvent.KEYCODE_MOVE_HOME) return "home";
            if (k == KeyEvent.KEYCODE_D) return "focus";
            return null;
        }
        if (!ctrl || alt) return null;
        if (k >= KeyEvent.KEYCODE_1 && k <= KeyEvent.KEYCODE_9) return "tab" + (k - KeyEvent.KEYCODE_0);
        switch (k) {
            case KeyEvent.KEYCODE_T: return shift ? "reopen" : "newtab";
            case KeyEvent.KEYCODE_N: return "newtab";
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_F4: return "closetab";
            case KeyEvent.KEYCODE_L:
                return shift ? "split" : "focus";
            case KeyEvent.KEYCODE_K:
            case KeyEvent.KEYCODE_E: return "focus";
            case KeyEvent.KEYCODE_R: return "reload";
            case KeyEvent.KEYCODE_F: return "find";
            case KeyEvent.KEYCODE_G: return shift ? "findprev" : "findnext";
            case KeyEvent.KEYCODE_D: return "bookmark";
            case KeyEvent.KEYCODE_H: return "history";
            case KeyEvent.KEYCODE_J: return "downloads";
            case KeyEvent.KEYCODE_O: return shift ? "bookmarks" : null;
            case KeyEvent.KEYCODE_TAB: return shift ? "prevtab" : "nexttab";
            case KeyEvent.KEYCODE_PAGE_DOWN: return "nexttab";
            case KeyEvent.KEYCODE_PAGE_UP: return "prevtab";
            case KeyEvent.KEYCODE_EQUALS:
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_NUMPAD_ADD: return "zoomin";
            case KeyEvent.KEYCODE_MINUS:
            case KeyEvent.KEYCODE_NUMPAD_SUBTRACT: return "zoomout";
            case KeyEvent.KEYCODE_0:
            case KeyEvent.KEYCODE_NUMPAD_0: return "zoomreset";
            case KeyEvent.KEYCODE_P: return shift ? "cmd" : "print";
            case KeyEvent.KEYCODE_A: return shift ? "tabs" : null;
            case KeyEvent.KEYCODE_COMMA: return "settings";
            case KeyEvent.KEYCODE_SLASH: return "keys";
            default: return null;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            String n = shortcutFor(e);
            if (n != null) {
                swallowed.add(e.getKeyCode());
                if (e.getRepeatCount() == 0 && chrome != null) {
                    if (n.equals("focus") || n.equals("find") || n.equals("newtab")) chrome.requestFocus();
                    js("window.NB&&NB.shortcut('" + n + "')");
                }
                return true;
            }
        } else if (e.getAction() == KeyEvent.ACTION_UP && swallowed.remove(e.getKeyCode())) {
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    private void closeTab(Tab t) {
        if (!t.isHome() && t.url != null && t.url.startsWith("http")) {
            closedTabs.add(0, new String[]{t.url, t.title == null ? "" : t.title, t.desktop ? "1" : "0"});
            while (closedTabs.size() > 25) closedTabs.remove(closedTabs.size() - 1);
        }
        int idx = tabs.indexOf(t);
        tabs.remove(t);
        for (int i = 0; i < paneTabs.length; i++) {
            if (paneTabs[i] != t.id) continue;
            Tab rep = null;
            if (!tabs.isEmpty()) {
                Tab near = tabs.get(Math.min(Math.max(idx, 0), tabs.size() - 1));
                if (!inPane(near.id)) rep = near;
            }
            if (rep == null) for (Tab x : tabs) if (!inPane(x.id)) { rep = x; break; }
            if (rep == null) rep = createTab(HOME);
            paneTabs[i] = rep.id;
        }
        destroyTab(t);
        rebuildPanes();
        postState();
    }

    /** open a saved workspace: replace every tab with the saved pages and put them in the saved panes */
    private void openWorkspace(String tabsJson, String panesJson) {
        try {
            JSONArray ta = new JSONArray(tabsJson), pa = new JSONArray(panesJson);
            ArrayList<Tab> old = new ArrayList<>(tabs);
            tabs.clear();
            ArrayList<Tab> nt = new ArrayList<>();
            for (int i = 0; i < ta.length() && i < 16; i++) {
                JSONObject o = ta.getJSONObject(i);
                String u = o.optString("u", "");
                nt.add(createTab(u.isEmpty() ? HOME : u, o.has("d") ? Boolean.valueOf(o.optBoolean("d")) : null));
            }
            HashSet<Integer> used = new HashSet<>();
            for (int i = 0; i < paneTabs.length; i++) {
                int idx = i < pa.length() ? pa.optInt(i, -1) : -1;
                Tab pick = (idx >= 0 && idx < nt.size() && !used.contains(nt.get(idx).id)) ? nt.get(idx) : null;
                if (pick == null) for (Tab x : nt) if (!used.contains(x.id)) { pick = x; break; }
                if (pick == null) pick = createTab(HOME);
                used.add(pick.id);
                paneTabs[i] = pick.id;
            }
            activePane = 0;
            for (Tab o : old) destroyTab(o);
            rebuildPanes();
            postState();
        } catch (Exception e) {
            toast("Could not open that workspace");
        }
    }

    private void pinWorkspace(String id, String name) {
        try {
            if (Build.VERSION.SDK_INT < 26) {
                toast("Adding to the home screen needs Android 8 or newer");
                return;
            }
            ShortcutManager sm = (ShortcutManager) getSystemService(Context.SHORTCUT_SERVICE);
            if (sm == null || !sm.isRequestPinShortcutSupported()) {
                toast("Your launcher cannot add shortcuts. Try the default launcher.");
                return;
            }
            String label = name == null || name.trim().isEmpty() ? "Workspace" : name.trim();
            if (label.length() > 24) label = label.substring(0, 24);
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(Intent.ACTION_VIEW);
            i.putExtra("nb_ws", id);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            ShortcutInfo info = new ShortcutInfo.Builder(this, "ws-" + id)
                    .setShortLabel(label).setLongLabel(label)
                    .setIcon(Icon.createWithAdaptiveBitmap(appIcon(label, "workspace-" + id)))
                    .setIntent(i).build();
            sm.requestPinShortcut(info, null);
        } catch (Exception e) {
            toast("Could not add the shortcut");
        }
    }

    private void replaceAllTabs() {
        ArrayList<Tab> old = new ArrayList<>(tabs);
        tabs.clear();
        for (int i = 0; i < paneTabs.length; i++) paneTabs[i] = createTab(HOME).id;
        for (Tab o : old) destroyTab(o);
        rebuildPanes();
        postState();
    }

    private void setLayoutRects(float[][] r) {
        rects = r;
        int n = r.length;
        int[] np = new int[n];
        ArrayList<Integer> used = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            np[i] = i < paneTabs.length ? paneTabs[i] : -1;
            if (np[i] >= 0) used.add(np[i]);
        }
        for (int i = 0; i < n; i++) {
            if (np[i] >= 0) continue;
            Tab free = null;
            for (Tab t : tabs) if (!used.contains(t.id)) { free = t; break; }
            if (free == null) free = createTab(HOME);
            np[i] = free.id;
            used.add(free.id);
        }
        paneTabs = np;
        if (activePane >= n) activePane = 0;
        rebuildPanes();
        postState();
    }

    private void showInPane(Tab t, int pane) {
        if (pane < 0 || pane >= paneTabs.length) pane = 0;
        int cur = -1;
        for (int i = 0; i < paneTabs.length; i++) if (paneTabs[i] == t.id) cur = i;
        if (cur == pane) return;
        boolean fast = paneWraps.size() == paneTabs.length && paneLayout.getChildCount() > 0;
        Tab old = tabById(paneTabs[pane]);
        if (cur >= 0) {
            int tmp = paneTabs[pane];
            paneTabs[pane] = t.id;
            paneTabs[cur] = tmp;
        } else {
            paneTabs[pane] = t.id;
        }
        if (fast) {
            if (cur >= 0 && old != null) attachTab(cur, old);
            attachTab(pane, t);
            if (cur < 0 && old != null && st.optBoolean("sleepTabs", true)) sleepTab(old);
            t.web.onResume();
        } else {
            rebuildPanes();
        }
    }

    private void attachTab(int pane, Tab t) {
        FrameLayout wrap = paneWraps.get(pane);
        ViewGroup oldParent = (ViewGroup) t.web.getParent();
        if (oldParent != null) oldParent.removeView(t.web);
        wrap.removeAllViews();
        wrap.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
    }

    private void rebuildPanes() {
        if (paneLayout == null) return;
        paneLayout.removeAllViews();
        paneWraps.clear();
        boolean multi = rects.length > 1;
        for (int i = 0; i < rects.length && i < paneTabs.length; i++) {
            Tab t = tabById(paneTabs[i]);
            if (t == null) continue;
            FrameLayout wrap = new FrameLayout(this);
            int b = multi ? dp(2) : 0;
            wrap.setPadding(b, b, b, b);
            ViewGroup old = (ViewGroup) t.web.getParent();
            if (old != null) old.removeView(t.web);
            wrap.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
            paneLayout.addView(wrap, new FrameLayout.LayoutParams(-1, -1));
            paneWraps.add(wrap);
        }
        paneLayout.rects = rects;
        paneLayout.gap = dp(st.optInt("gap", 4));
        paneLayout.rebuildDividers();
        paneLayout.requestLayout();
        updateBorders();
        for (Tab x : tabs) {
            if (inPane(x.id)) x.web.onResume();
            else if (st.optBoolean("sleepTabs", true)) sleepTab(x);
        }
    }

    private void updateBorders() {
        boolean multi = rects.length > 1;
        int pi = 0;
        for (int i = 0; i < paneLayout.getChildCount(); i++) {
            View w = paneLayout.getChildAt(i);
            if (w instanceof PaneLayout.Handle) continue;
            if (!multi) w.setBackgroundColor(Color.TRANSPARENT);
            else w.setBackgroundColor(pi == activePane ? accent : lineCol);
            pi++;
        }
        paneLayout.handleColor = accent;
        paneLayout.invalidateHandles();
    }

    private void focusTab(Tab t) {
        for (int i = 0; i < paneTabs.length; i++) {
            if (paneTabs[i] == t.id && i != activePane) {
                activePane = i;
                updateBorders();
                postState();
                return;
            }
        }
    }

    // =====================================================================================
    //  per-tab WebView settings and privacy
    // =====================================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private void applySettings(Tab t) {
        WebSettings s = t.web.getSettings();
        s.setJavaScriptEnabled(t.js);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);
        s.setSaveFormData(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(st.optBoolean("blockAutoplay", true));
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(Math.max(50, Math.min(250, st.optInt("textZoom", 100))));
        s.setLoadsImagesAutomatically(t.images);
        s.setCacheMode(st.optBoolean("noCache", false) ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(st.optBoolean("safeBrowsing", false));
        s.setUserAgentString(userAgent(t));
        if (st.optBoolean("chromeLook", true)) applyChromeLook(s, t);
        String ck = st.optString("cookies", "first");
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(!"none".equals(ck));
        cm.setAcceptThirdPartyCookies(t.web, "all".equals(ck));
        if (t.url != null && t.url.startsWith("http")) cookiePolicy(t, t.url);
    }

    private String userAgent(Tab t) {
        String custom = st.optString("customUA", "");
        if ("custom".equals(st.optString("ua", "default")) && !custom.isEmpty()) return custom;
        String major = chromeVer.contains(".") ? chromeVer.substring(0, chromeVer.indexOf('.')) : chromeVer;
        if (st.optBoolean("chromeLook", true)) {
            // the same "reduced" identity real Chrome uses: no phone model, no build number
            if (t.desktop) return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + major + ".0.0.0 Safari/537.36";
            return "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + major + ".0.0.0 Mobile Safari/537.36";
        }
        if (t.desktop) {
            return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + chromeVer + " Safari/537.36";
        }
        return defaultUa.replace("; wv", "").replace("Version/4.0 ", "");
    }

    /** makes the browser look like plain Chrome to websites (needed for Google sign-in) */
    private void applyChromeLook(WebSettings s, Tab t) {
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, new HashSet<String>());
            }
        } catch (Exception ignored) {
        }
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) return;
            String major = chromeVer.contains(".") ? chromeVer.substring(0, chromeVer.indexOf('.')) : chromeVer;
            ArrayList<UserAgentMetadata.BrandVersion> br = new ArrayList<>();
            br.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Chromium").setMajorVersion(major).setFullVersion(chromeVer).build());
            br.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Google Chrome").setMajorVersion(major).setFullVersion(chromeVer).build());
            br.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Not_A Brand").setMajorVersion("24").setFullVersion("24.0.0.0").build());
            UserAgentMetadata md = new UserAgentMetadata.Builder().setBrandVersionList(br).setFullVersion(chromeVer)
                    .setPlatform(t.desktop ? "Linux" : "Android").setMobile(!t.desktop).build();
            WebSettingsCompat.setUserAgentMetadata(s, md);
        } catch (Exception ignored) {
        }
    }

    /** sign-in pages get third-party cookies even when you block them everywhere else */
    private void cookiePolicy(Tab t, String url) {
        boolean si = false;
        try {
            si = st.optBoolean("signinCompat", true) && Blocker.isSignin(Uri.parse(url).getHost());
        } catch (Exception ignored) {
        }
        String host = "";
        try {
            host = Uri.parse(url).getHost();
        } catch (Exception ignored) {
        }
        boolean app = blocker.isCompat(host);
        // web apps (Spotify, Netflix...) need their own cross-site cookies to log in and play; ad domains are still blocked
        boolean none = "none".equals(st.optString("cookies", "first"));
        CookieManager.getInstance().setAcceptThirdPartyCookies(t.web, !none && (si || app || "all".equals(st.optString("cookies", "first"))));
        // next track / next episode must be able to start without a tap
        t.web.getSettings().setMediaPlaybackRequiresUserGesture(!app && st.optBoolean("blockAutoplay", true));
    }

    /** switches a tab to the desktop layout once for sites that only have their web player there (Spotify). */
    private boolean autoDesktop(Tab t, String url) {
        if (url == null) return false;
        if (t.desktop) {
            // Spotify only plays on the phone layout: switch such a tab back, whatever the desktop setting was
            try {
                if (blocker.wantsMobile(Uri.parse(url).getHost())) {
                    t.desktop = false;
                    applySettings(t);
                    refreshScript(t);
                    return true;
                }
            } catch (Exception ignored) {
            }
            return false;
        }
        if (t.autoDesk) return false;
        try {
            Uri u = Uri.parse(url);
            if (!blocker.wantsDesktop(u.getHost())) return false;
        } catch (Exception e) {
            return false;
        }
        t.autoDesk = true;
        t.desktop = true;
        applySettings(t);
        refreshScript(t);
        return true;
    }

    /** background-playing music/video tabs must not be paused */
    private void sleepTab(Tab t) {
        if (blocker.isCompat(t.host())) return;
        t.web.onPause();
    }

    private String scriptFor(Tab t) {
        JSONObject c = new JSONObject();
        try {
            c.put("spoof", st.optBoolean("spoof", true));
            c.put("rtc", st.optBoolean("noWebrtc", true));
            c.put("beacon", st.optBoolean("noBeacon", true));
            c.put("gpc", st.optBoolean("gpc", true));
            c.put("ref", st.optString("referrer", "origin"));
            c.put("cosmetic", st.optBoolean("cosmetic", true));
            c.put("consent", st.optBoolean("consent", true));
            c.put("forceZoom", st.optBoolean("forceZoom", true));
            c.put("yt", st.optBoolean("videoAds", true));
            c.put("signin", st.optBoolean("signinCompat", true));
            c.put("compat", blocker.compatArray());
            c.put("dw", t.desktop ? st.optInt("desktopWidth", 1280) : 0);
            String dp = st.optString("darkPages", "off");
            c.put("dark", t.dark || "on".equals(dp) || ("auto".equals(dp) && appDark));
            JSONArray al = st.optJSONArray("siteAllow");
            c.put("allow", al == null ? new JSONArray() : al);
            JSONArray hs = st.optJSONArray("hideSelectors");
            c.put("hide", hs == null ? new JSONArray() : hs);
        } catch (JSONException ignored) {
        }
        String media = "";
        if (st.optBoolean("dlMedia", true) && !mediaJs.isEmpty()) {
            media = "\n" + mediaJs.replace("__NBM_ON__", "1").replace("__NBM_BTN__", st.optBoolean("dlButtons", true) ? "1" : "0");
        }
        return injectTpl.replace("__NB_CFG__", c.toString()) + (st.optBoolean("ytCinema", true) ? "\n" + cineJs : "") + media;
    }

    private void refreshScript(Tab t) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
            if (t.script != null) t.script.remove();
            HashSet<String> rules = new HashSet<>();
            rules.add("*");
            t.script = WebViewCompat.addDocumentStartJavaScript(t.web, scriptFor(t), rules);
        } catch (Exception ignored) {
        }
    }

    private void applyZoom(Tab t) {
        if (t.web == null) return;
        int pct = st.optInt("pageZoom", 100);
        JSONObject sz = st.optJSONObject("siteZoom");
        String h = t.host();
        if (sz != null && !h.isEmpty() && sz.has(h)) pct = sz.optInt(h, pct);
        String v = pct == 100 ? "" : String.format(Locale.US, "%.2f", pct / 100f);
        t.web.evaluateJavascript("try{document.documentElement.style.zoom='" + v + "'}catch(e){}", null);
    }

    private void applyAll() {
        ui.removeCallbacks(applyTask);
        ui.postDelayed(applyTask, 220);
    }

    private String injectSig() {
        String[] keys = {"spoof", "noWebrtc", "noBeacon", "gpc", "referrer", "cosmetic", "consent", "forceZoom", "videoAds", "desktopWidth", "darkPages", "siteAllow", "hideSelectors", "appCompat", "compatSites", "ytCinema", "dlMedia", "dlButtons"};
        StringBuilder sb = new StringBuilder();
        for (String k : keys) sb.append(String.valueOf(st.opt(k))).append('|');
        return sb.toString();
    }

    private void applyAllNow() {
        blocker.update(st);
        barBottom = "bottom".equals(st.optString("toolbarPos", "top"));
        applyWindowFlags();
        applyProxy();
        applyDl();
        applySystemUi(lastBg, lastLight);
        if (paneLayout != null) {
            paneLayout.gap = dp(st.optInt("gap", 4));
            paneLayout.requestLayout();
        }
        String sig = injectSig();
        boolean scriptChanged = !sig.equals(injectSigLast);
        injectSigLast = sig;
        for (Tab t : tabs) {
            applySettings(t);
            if (scriptChanged) refreshScript(t);
            applyZoom(t);
        }
        if (!st.optBoolean("autoHide", true) && barsHidden) setBarsHidden(false);
        updateMargins();
        postState();
    }

    private void applyWindowFlags() {
        if (st.optBoolean("secure", false)) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if (root != null) root.setKeepScreenOn(st.optBoolean("keepScreen", false));
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi(int bg, boolean lightIcons) {
        lastBg = bg;
        lastLight = lightIcons;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        boolean imm = fullscreen || customView != null || st.optBoolean("alwaysFull", true);
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (lightIcons) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (imm) {
            f |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            int want = imm && st.optBoolean("cutout", true)
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            if (lp.layoutInDisplayCutoutMode != want) {
                lp.layoutInDisplayCutoutMode = want;
                getWindow().setAttributes(lp);
            }
        }
        if (root != null) {
            applyRootPadding();
            root.requestApplyInsets();
        }
    }

    private int lastBg = 0xFFFFFFFF;
    private boolean lastLight = true;

    private void setFullscreen(boolean on) {
        fullscreen = on;
        if (on) {
            barsHidden = false;
            chrome.setTranslationY(0f);
        }
        applySystemUi(lastBg, lastLight);
        fab.setVisibility(on ? View.VISIBLE : View.GONE);
        updateMargins();
    }

    private void updateMargins() {
        if (paneLayout == null || chrome == null) return;
        if (fullscreen) barsHidden = false;
        int bar = barsHidden ? 0 : barPx;
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) paneLayout.getLayoutParams();
        int top = fullscreen ? 0 : (barBottom ? 0 : bar), bottom = fullscreen ? 0 : (barBottom ? bar : 0);
        if (p.topMargin != top || p.bottomMargin != bottom) {
            p.topMargin = top;
            p.bottomMargin = bottom;
            paneLayout.setLayoutParams(p);
        }
        FrameLayout.LayoutParams c = (FrameLayout.LayoutParams) chrome.getLayoutParams();
        c.gravity = barBottom ? Gravity.BOTTOM : Gravity.TOP;
        c.height = chromeFull ? ViewGroup.LayoutParams.MATCH_PARENT : Math.max(barPx, dp(40));
        chrome.setLayoutParams(c);
        float ty = (chromeFull || fullscreen) ? 0f : (barsHidden ? (barBottom ? barPx : -barPx) : 0f);
        chrome.setTranslationY(ty);
        chrome.setVisibility(fullscreen && !chromeFull ? View.GONE : View.VISIBLE);
    }

    // =====================================================================================
    //  loading, blocking and error pages
    // =====================================================================================
    private boolean isLocal(String h) {
        if (h == null) return true;
        return h.equals("localhost") || h.startsWith("127.") || h.startsWith("10.") || h.startsWith("192.168.")
                || h.matches("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*") || h.endsWith(".local") || h.indexOf('.') < 0;
    }

    private String prep(Tab t, String url) {
        Uri u = Uri.parse(url);
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (!sc.equals("http") && !sc.equals("https")) return url;
        if (HOST.equals(u.getHost())) return url;
        if (st.optBoolean("stripParams", true)) url = Blocker.clean(url);
        if (sc.equals("http") && st.optBoolean("httpsOnly", true) && !httpOk.contains(u.getHost()) && !isLocal(u.getHost())) {
            t.pendingHttp = url;
            url = "https" + url.substring(4);
        }
        return url;
    }

    private void load(Tab t, String url) {
        if (vpnBlocking() && !url.startsWith(BASE)) {
            showError(t, url, "VPN is required but not connected. Connect it from the menu, or turn off the kill switch in Settings.");
            return;
        }
        autoDesktop(t, url);
        String u = prep(t, url);
        HashMap<String, String> h = new HashMap<>();
        if (st.optBoolean("gpc", true)) {
            h.put("Sec-GPC", "1");
            h.put("DNT", "1");
        }
        t.web.loadUrl(u, h);
    }

    private WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    private void countBlock(Tab t, String host) {
        t.blocked++;
        totalBlocked++;
        Integer n = t.hostCounts.get(host);
        t.hostCounts.put(host, n == null ? 1 : n + 1);
        postState();
    }

    private void showError(Tab t, String failUrl, String msg) {
        String safeUrl = TextUtils.htmlEncode(failUrl == null ? "" : failUrl);
        String http = "";
        if (t.pendingHttp != null && failUrl != null && failUrl.startsWith("https")) {
            http = "<a class=\"b2\" href=\"nb-allowhttp" + TextUtils.htmlEncode(t.pendingHttp.substring(4)) + "\">Open over insecure HTTP once</a>";
        }
        String html = "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\">"
                + "<style>body{font-family:sans-serif;background:#fafafa;color:#222;margin:0;padding:28px 22px}"
                + "h1{font-size:22px;margin:0 0 8px}p{color:#555;line-height:1.5}.u{word-break:break-all;font-size:13px;color:#888}"
                + "a{display:inline-block;margin:10px 8px 0 0;padding:11px 18px;border-radius:12px;background:#1f8a70;color:#fff;text-decoration:none;font-weight:600}"
                + "a.b2{background:#e9e9e9;color:#333}.i{font-size:42px}</style></head><body><div class=i>&#128737;</div>"
                + "<h1>This page didn't open</h1><p>" + TextUtils.htmlEncode(msg) + "</p><p class=u>" + safeUrl + "</p>"
                + "<a href=\"" + safeUrl + "\">Try again</a><a class=\"b2\" href=\"" + HOME + "\">New tab page</a>" + http
                + "<p style=\"margin-top:26px;font-size:13px\">NerdyBrowser blocked or could not finish this connection. Nothing was saved.</p></body></html>";
        t.web.loadDataWithBaseURL("https://nerdybrowser.invalid/error", html, "text/html", "utf-8", failUrl);
    }

    private boolean handleNavigation(Tab t, Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        String url = u.toString();
        if (sc.equals("http") || sc.equals("https")) {
            if (HOST.equals(u.getHost())) return false;
            if (autoDesktop(t, url)) {
                load(t, url);
                return true;
            }
            String p = prep(t, url);
            if (!p.equals(url)) {
                load(t, p);
                return true;
            }
            return false;
        }
        if (sc.equals("nb-allowhttp")) {
            String real = "http" + url.substring("nb-allowhttp".length());
            try {
                httpOk.add(Uri.parse(real).getHost());
            } catch (Exception ignored) {
            }
            load(t, real);
            return true;
        }
        if (sc.equals("about") || sc.equals("blob")) return false;
        if (sc.equals("mailto") || sc.equals("tel") || sc.equals("sms") || sc.equals("geo")) {
            confirmExternal(url);
            return true;
        }
        // javascript:, data:, intent:, market: and other app schemes
        if (!sc.equals("javascript") && !sc.equals("data") && !sc.equals("intent") && !st.optBoolean("blockExternal", true)) {
            confirmExternal(url);
            return true;
        }
        t.blocked++;
        totalBlocked++;
        toast("Blocked a link that tried to open another app");
        postState();
        return true;
    }

    private void confirmExternal(final String url) {
        new AlertDialog.Builder(this).setTitle("Open in another app?")
                .setMessage(shorten(url))
                .setPositiveButton("Open", (d, w) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        toast("No app can open this");
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    class TabClient extends WebViewClient {
        final Tab t;

        TabClient(Tab t) {
            this.t = t;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String host = u.getHost();
            if (!HOST.equals(host) && vpnBlocking()) return blockedResponse();
            if (HOST.equals(host)) {
                String path = u.getPath() == null ? "" : u.getPath();
                if (path.startsWith("/assets/www/pages/") || path.startsWith("/assets/www/css/") || path.startsWith("/assets/www/fonts/")) {
                    WebResourceResponse res = loader.shouldInterceptRequest(u);
                    if (res != null) return res;
                }
                return blockedResponse();
            }
            String sc = u.getScheme();
            if (!"http".equals(sc) && !"https".equals(sc)) return null;
            if (r.isForMainFrame()) return null;
            sniff(t, u, r);
            if (blocker.shouldBlock(u, t.host(), r.getRequestHeaders())) {
                countBlock(t, host);
                return blockedResponse();
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) return false;
            return handleNavigation(t, r.getUrl());
        }

        @Override
        public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
            t.url = url == null ? "" : url;
            if (url != null) cookiePolicy(t, url);
            if (activeTab() == t) setBarsHidden(false);
            t.loading = true;
            t.progress = 8;
            t.blocked = 0;
            t.alerts = 0;
            t.hostCounts.clear();
            synchronized (t.sniffed) {
                t.sniffed.clear();
            }
            v.evaluateJavascript(scriptFor(t), null);
            postState();
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.loading = false;
            t.progress = 100;
            if (url != null) t.url = url;
            t.canBack = v.canGoBack();
            t.canFwd = v.canGoForward();
            applyZoom(t);
            if (url != null && url.startsWith("http") && !HOST.equals(Uri.parse(url).getHost()) && st.optBoolean("saveHistory", false)) {
                js("window.NB&&NB.visit(" + JSONObject.quote(url) + "," + JSONObject.quote(t.title == null ? "" : t.title) + ")");
            }
            postState();
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
            if (url != null) t.url = url;
            t.canBack = v.canGoBack();
            t.canFwd = v.canGoForward();
            postState();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) return;
            String d = e.getDescription() == null ? "" : e.getDescription().toString();
            if (d.contains("UNKNOWN_URL_SCHEME") || d.contains("ERR_ABORTED")) return;
            showError(t, r.getUrl().toString(), d.isEmpty() ? "The connection failed." : d.replace("net::", ""));
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
            h.cancel();
            String eh = Uri.parse(e.getUrl()).getHost();
            if (eh != null && eh.equals(t.host())) {
                showError(t, e.getUrl(), "This site's security certificate can't be trusted, so NerdyBrowser stopped the connection to protect you.");
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            ui.post(() -> {
                toast("A tab crashed and was closed");
                if (tabs.contains(t)) closeTab(t);
            });
            return true;
        }
    }

    class TabChrome extends WebChromeClient {
        final Tab t;

        TabChrome(Tab t) {
            this.t = t;
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage cm) {
            String m = cm.message();
            if (m != null && m.startsWith("__NBMEDIA__")) {
                final String payload = m.substring(11);
                ui.post(() -> mediaFromPage(t, payload));
                return true;
            }
            if (t.picking && m != null && m.startsWith("__NBHIDE__")) {
                t.picking = false;
                String sel = m.substring(10);
                if (sel.length() > 0 && sel.length() < 300) {
                    js("window.NB&&NB.hideSel(" + JSONObject.quote(t.host()) + "," + JSONObject.quote(sel) + ")");
                }
                return true;
            }
            return super.onConsoleMessage(cm);
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            t.progress = p;
            t.loading = p < 100;
            postState();
        }

        @Override
        public void onReceivedIcon(WebView v, Bitmap icon) {
            String h = t.host();
            if (icon != null && !h.isEmpty()) {
                Bitmap old = favicons.get(h);
                if (old == null || icon.getWidth() >= old.getWidth()) {
                    favicons.put(h, icon);
                    try {
                        Bitmap sm = Bitmap.createScaledBitmap(icon, 32, 32, true);
                        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                        sm.compress(Bitmap.CompressFormat.PNG, 100, bo);
                        String b64 = android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP);
                        if (b64.length() < 6000) js("window.NB&&NB.favicon(" + JSONObject.quote(h) + ",'data:image/png;base64," + b64 + "')");
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title == null ? "" : title;
            postState();
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
            String pol = st.optString("popups", "gesture");
            if ("block".equals(pol) || (!gesture && !"allow".equals(pol))) {
                t.blocked++;
                totalBlocked++;
                toast("Popup blocked");
                postState();
                return false;
            }
            Tab nt = createTab(null);
            showInPane(nt, activePane);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
            tr.setWebView(nt.web);
            msg.sendToTarget();
            postState();
            return true;
        }

        @Override
        public void onCloseWindow(WebView w) {
            for (Tab x : new ArrayList<>(tabs)) if (x.web == w) closeTab(x);
        }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        private boolean mute() {
            return st.optBoolean("blockDialogs", false) || ++t.alerts > 3;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String message, final JsResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> r.confirm()).setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String message, final JsResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> r.confirm()).setNegativeButton("Cancel", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String message, String def, final JsPromptResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            final EditText in = new EditText(MainActivity.this);
            in.setInputType(InputType.TYPE_CLASS_TEXT);
            in.setText(def);
            new AlertDialog.Builder(MainActivity.this).setMessage(message).setView(in)
                    .setPositiveButton("OK", (d, w) -> r.confirm(in.getText().toString()))
                    .setNegativeButton("Cancel", (d, w) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            cb.invoke(origin, false, false); // location is never shared
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            // camera, microphone and the rest are never shared. Only DRM playback (Spotify, Netflix...) is allowed:
            // it does not expose any device or personal data, it just lets protected music/video play.
            boolean drm = false;
            for (String r : request.getResources()) if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) drm = true;
            if (drm) request.grant(new String[]{PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID});
            else request.deny();
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            applySystemUi(lastBg, lastLight);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi(lastBg, lastLight);
    }

    // =====================================================================================
    //  downloads, link menu, share
    // =====================================================================================
    private void askDownload(final String url, final String ua, final String cd, final String mime) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("This kind of download isn't supported yet");
            return;
        }
        new Thread(() -> {
            final String[] info = probeDownload(url, ua, cd, mime);
            ui.post(() -> {
                final String name = info[0], mt = info[1];
                long len = -1;
                try {
                    len = Long.parseLong(info[3]);
                } catch (Exception ignored) {
                }
                long free = freeBytes();
                String where = st.optBoolean("dlSort", true) ? "Saves to Downloads/NerdyBrowser/" + categoryOf(name, mt) : "Saves to Downloads";
                String msg = name + (info[2].isEmpty() ? "" : "\n" + info[2]) + "\n" + where;
                if (len > 0 && free > 0 && len > free) msg += "\n\nNot enough free space on this phone.";
                final Runnable go = () -> enqueueDownload(url, ua, name, mt);
                if (st.optBoolean("askDownload", true)) {
                    new AlertDialog.Builder(MainActivity.this).setTitle("Download file?").setMessage(msg)
                            .setPositiveButton("Download", (d, w) -> go.run()).setNegativeButton("Cancel", null).show();
                } else go.run();
            });
        }).start();
    }

    private void showLinkMenu(final String link, final String img) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null) {
            labels.add("Open in new tab");
            acts.add(() -> openNew(link, false));
            labels.add("Open in background");
            acts.add(() -> openNew(link, true));
            if (rects.length > 1) {
                labels.add("Open in other pane");
                acts.add(() -> {
                    int other = (activePane + 1) % rects.length;
                    Tab nt = createTab(link);
                    showInPane(nt, other);
                    postState();
                });
            }
            labels.add("Copy link");
            acts.add(() -> ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link", link)));
            labels.add("Share link");
            acts.add(() -> shareText(link));
        }
        if (img != null) {
            labels.add("Open image in new tab");
            acts.add(() -> openNew(img, false));
            labels.add("Copy image address");
            acts.add(() -> ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("image", img)));
            labels.add("Save image (choose size)");
            acts.add(() -> {
                final Tab at = activeTab();
                if (at == null || !st.optBoolean("dlMedia", true)) {
                    askDownload(img, userAgent(at), null, null);
                    return;
                }
                at.web.evaluateJavascript("(function(){try{return window.__nbmImg?window.__nbmImg(" + JSONObject.quote(img) + "):0}catch(e){return 0}})()", v -> {
                    if (!"1".equals(v)) askDownload(img, userAgent(at), null, null);
                });
            });
            labels.add("Download image (original file)");
            acts.add(() -> askDownload(img, userAgent(activeTab()), null, null));
        }
        new AlertDialog.Builder(this).setTitle(shorten(link != null ? link : img))
                .setItems(labels.toArray(new String[0]), (d, i) -> acts.get(i).run()).show();
    }

    private void shareText(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, "Share"));
    }

    // =====================================================================================
    //  burn, wipe, state
    // =====================================================================================
    private void wipeData() {
        wipeData(false);
    }

    private void wipeData(boolean force) {
        try {
            if (!force && st.optBoolean("keepLogins", true)) return; // keep sign-ins across restarts
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
        } catch (Exception ignored) {
        }
    }

    private void burn() {
        wipeData(true);
        for (Tab t : tabs) {
            t.web.clearCache(true);
            t.web.clearHistory();
            t.web.clearFormData();
        }
        try {
            WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword();
        } catch (Exception ignored) {
        }
        httpOk.clear();
        vault.edit().remove("history").remove("session").apply();
        replaceAllTabs();
        totalBlocked = 0;
        ui.postDelayed(() -> js("window.NB&&NB.afterBurn()"), 350);
    }

    private String stateJson() {
        try {
            JSONObject o = new JSONObject();
            JSONArray ta = new JSONArray();
            for (Tab t : tabs) {
                JSONObject j = new JSONObject();
                j.put("id", t.id);
                j.put("title", t.isHome() ? "New tab" : t.title);
                j.put("url", t.isHome() ? "" : t.url);
                j.put("loading", t.loading);
                j.put("progress", t.progress);
                j.put("blocked", t.blocked);
                j.put("back", t.canBack);
                j.put("fwd", t.canFwd);
                j.put("desktop", t.desktop);
                j.put("js", t.js);
                j.put("images", t.images);
                j.put("dark", t.dark);
                j.put("shield", !blocker.isAllowed(t.host()));
                j.put("refresh", t.refreshSec);
                ta.put(j);
            }
            o.put("tabs", ta);
            JSONArray pa = new JSONArray();
            for (int p : paneTabs) pa.put(p);
            o.put("panes", pa);
            o.put("active", activePane);
            o.put("layout", layoutName);
            o.put("total", totalBlocked);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    private void postState() {
        if (statePosted || chrome == null || !ready) return;
        statePosted = true;
        ui.postDelayed(() -> {
            statePosted = false;
            js("window.NB&&NB.state(" + stateJson() + ")");
        }, 120);
    }

    private void js(String code) {
        if (chrome != null) chrome.evaluateJavascript(code, null);
    }

    // =====================================================================================
    //  lifecycle
    // =====================================================================================
    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (appMode) {
            Tab at = activeTab();
            if (at != null && at.web.canGoBack()) {
                at.web.goBack();
                return;
            }
            exitAppMode(true);
            return;
        }
        if (fullscreen) {
            setFullscreen(false);
            js("window.NB&&NB.event('fs',false)");
            return;
        }
        if (chromeFull) {
            js("window.NB&&NB.back()");
            return;
        }
        if (findOpen) {
            js("window.NB&&NB.closeFind()");
            return;
        }
        Tab t = activeTab();
        if (t != null && t.web.canGoBack()) {
            t.web.goBack();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - backAt < 2000) {
            finishAndRemoveTask();
        } else {
            backAt = now;
            toast("Press back again to exit");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else if (req == REQ_PICK) {
            if (res == RESULT_OK && data != null && data.getData() != null) readImportFile(data.getData());
        } else if (req == REQ_VPN) {
            if (res == RESULT_OK) startVpn();
            else {
                vpnMsg = "VPN permission was not given";
                pushVpn();
            }
        } else if (req == REQ_LOCK) {
            if (res == RESULT_OK) unlock();
            else finishAndRemoveTask();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (Tab t : tabs) if (inPane(t.id)) t.web.onResume();
        chrome.onResume();
        scheduleMediaPoll();
        if (st.optBoolean("appLock", false)) {
            if (!locked && stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > 30000) locked = true;
            if (locked) showLock();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(mediaPoll);
        mediaPolling = false;
        for (Tab t : tabs) sleepTab(t);
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stoppedAt = SystemClock.elapsedRealtime();
        if (st.optBoolean("restoreTabs", false)) {
            JSONArray a = new JSONArray();
            for (Tab t : tabs) {
                if (t.isHome() || t.url.isEmpty()) continue;
                if (t.url.startsWith("http")) a.put(t.url);
            }
            vault.edit().putString("session", a.toString()).apply();
        } else {
            vault.edit().remove("session").apply();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && st.optBoolean("wipeExit", true)) wipeData();
        for (Tab t : new ArrayList<>(tabs)) {
            try {
                destroyTab(t);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private void showLock() {
        if (lockCover == null) {
            TextView tv = new TextView(this);
            tv.setText("NerdyBrowser is locked");
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(0xFF1F2A44);
            tv.setTextSize(18);
            tv.setClickable(true);
            lockCover = tv;
            root.addView(lockCover, new FrameLayout.LayoutParams(-1, -1));
        }
        lockCover.setVisibility(View.VISIBLE);
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km != null && km.isDeviceSecure()) {
            Intent i = km.createConfirmDeviceCredentialIntent("NerdyBrowser", "Unlock to continue");
            if (i != null) {
                try {
                    startActivityForResult(i, REQ_LOCK);
                    return;
                } catch (Exception ignored) {
                }
            }
        }
        unlock(); // phone has no screen lock set, nothing to ask for
    }

    private void unlock() {
        locked = false;
        stoppedAt = 0;
        if (lockCover != null) lockCover.setVisibility(View.GONE);
    }

    // =====================================================================================
    //  small helpers
    // =====================================================================================
    // =====================================================================================
    //  v2: dragging panes, auto-hide bars, VPN, proxy, downloads, refresh, rotation
    // =====================================================================================
    private int cutL, cutT, cutR, cutB;

    private void onRectsDragged(float[][] r) {
        layoutName = "custom";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < r.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(String.format(Locale.US, "[%.4f,%.4f,%.4f,%.4f]", r[i][0], r[i][1], r[i][2], r[i][3]));
        }
        sb.append(']');
        js("window.NB&&NB.rects(" + sb + ")");
    }

    private void setBarsHidden(boolean h) {
        if (chrome == null) return;
        if (h && (!st.optBoolean("autoHide", true) || chromeFull || fullscreen)) return;
        if (h == barsHidden) return;
        barsHidden = h;
        lastToggle = SystemClock.elapsedRealtime();
        updateMargins();
        chrome.animate().translationY(h ? (barBottom ? barPx : -barPx) : 0f).setDuration(170).start();
    }

    private void applyRootPadding() {
        if (root == null) return;
        boolean imm = fullscreen || customView != null || st.optBoolean("alwaysFull", true);
        boolean ext = (fullscreen || customView != null) && st.optBoolean("cutout", true);
        if (!imm || ext) root.setPadding(0, 0, 0, 0);
        else root.setPadding(cutL, cutT, cutR, cutB);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && root != null) applySystemUi(lastBg, lastLight);
    }

    private void applyDl() {
        if (dl == null) return;
        dl.setGlobalLimit(st.optLong("dlGlobal", 0) * 1024L);
        dl.setParallel(st.optInt("dlParallel", 3));
        dl.setWifiOnly(st.optBoolean("dlWifiOnly", false));
        dl.setProxy(curProxy);
    }

    private void applyProxy() {
        String p = st.optString("proxy", "").trim();
        if (p.equals(curProxy)) return;
        curProxy = p;
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                if (!p.isEmpty()) toast("This phone's WebView can't use a proxy");
                return;
            }
            Executor ex = Runnable::run;
            if (p.isEmpty()) {
                ProxyController.getInstance().clearProxyOverride(ex, () -> {
                });
            } else {
                ProxyController.getInstance().setProxyOverride(new ProxyConfig.Builder().addProxyRule(p).build(), ex, () -> {
                });
            }
        } catch (Exception e) {
            toast("That proxy address is not valid");
        }
    }

    // ---------- VPN ----------
    private String vpnConfig() {
        return vault.getString("vpncfg", "");
    }

    private boolean vpnBlocking() {
        return st.optBoolean("vpnKill", false) && vpnConfig().length() > 0 && !vpnUp;
    }

    private void pushVpn() {
        js("window.NB&&NB.vpn(" + vpnJson() + ")");
    }

    private String vpnJson() {
        try {
            JSONObject o = new JSONObject();
            String cfg = vpnConfig();
            o.put("has", cfg.length() > 0);
            o.put("up", vpnUp);
            o.put("msg", vpnMsg);
            String[] inf = Vpn.info(cfg);
            o.put("endpoint", inf[0]);
            o.put("address", inf[1]);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    private void startVpn() {
        String cfg = vpnConfig();
        if (cfg.isEmpty()) {
            vpnMsg = "Paste a WireGuard config first";
            pushVpn();
            return;
        }
        Intent i = android.net.VpnService.prepare(this);
        if (i != null) {
            try {
                startActivityForResult(i, REQ_VPN);
            } catch (Exception e) {
                toast("The VPN permission screen is not available");
            }
            return;
        }
        vpnMsg = "Connecting...";
        pushVpn();
        vpn.connect(cfg);
    }

    private void readImportFile(final Uri uri) {
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n, total = 0;
                while (in != null && (n = in.read(buf)) > 0) {
                    total += n;
                    if (total > 5 * 1024 * 1024) break;
                    bo.write(buf, 0, n);
                }
                if (in != null) in.close();
                final String text = bo.toString("UTF-8");
                ui.post(() -> js("window.NB&&NB.importFile(" + JSONObject.quote(text) + ")"));
            } catch (Exception e) {
                ui.post(() -> toast("Could not read that file"));
            }
        }).start();
    }

    // ---------- pull down to refresh ----------
    private float pullBase() {
        return barBottom ? 0f : ((barsHidden || fullscreen) ? 0f : (float) barPx);
    }

    private void pullCancel() {
        pullActive = false;
        pullView.hideNow();
    }

    private void pullTouch(Tab t, MotionEvent e) {
        if (!st.optBoolean("pullRefresh", true) || t != activeTab() || pullView == null) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                pullArmed = false;
                pullStartY = e.getRawY();
                pullActive = false;
                final int seq = ++pullSeq;
                if (!t.web.canScrollVertically(-1)) {
                    // many sites scroll inside a box instead of the page: ask the page itself whether it and
                    // whatever is under the finger are really at the very top
                    String fx = String.valueOf(e.getX() / Math.max(1, t.web.getWidth()));
                    String fy = String.valueOf(e.getY() / Math.max(1, t.web.getHeight()));
                    String code = "(function(a,b){try{var o=document.getElementById('nbt');if(o&&o.classList.contains('on'))return o.scrollTop<=0;"
                            + "var s=document.scrollingElement||document.documentElement;if((window.scrollY||s.scrollTop)>0)return false;"
                            + "var e=document.elementFromPoint(a*innerWidth,b*innerHeight);"
                            + "while(e&&e!==document.body&&e!==document.documentElement){var c=getComputedStyle(e).overflowY;"
                            + "if((c==='auto'||c==='scroll'||c==='overlay')&&e.scrollHeight>e.clientHeight+1&&e.scrollTop>0)return false;e=e.parentElement}"
                            + "return true}catch(x){return true}})(" + fx + "," + fy + ")";
                    t.web.evaluateJavascript(code, val -> {
                        if (seq == pullSeq && "true".equals(val)) pullArmed = true;
                    });
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (e.getPointerCount() > 1) {
                    pullCancel();
                    pullArmed = false;
                    break;
                }
                if (!pullArmed) break;
                float dy = e.getRawY() - pullStartY, dead = dp(16);
                if (dy > dead) {
                    pullActive = true;
                    float pr = Math.min(1f, (dy - dead) / dp(120));
                    pullView.color = accent;
                    pullView.setTranslationY(pullBase() + pr * dp(60) - dp(20));
                    pullView.show(pr);
                } else if (pullActive) {
                    pullCancel();
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pullSeq++;
                if (pullActive && pullView.progress >= 1f && e.getActionMasked() == MotionEvent.ACTION_UP) {
                    pullView.spin();
                    flashAction("\u21bb  Refreshing");
                    if (t.loading) t.web.stopLoading();
                    t.web.reload();
                    ui.postDelayed(() -> pullView.hideNow(), 950);
                } else if (pullActive) {
                    pullCancel();
                }
                pullActive = false;
                pullArmed = false;
                break;
            default:
                break;
        }
    }

    private void openMediaList(boolean all) {
        final Tab t = activeTab();
        if (t == null || t.isHome()) {
            toast("Open a page first");
            return;
        }
        if (!st.optBoolean("dlMedia", true)) {
            toast("Turn on Media downloader in Settings first");
            return;
        }
        t.web.evaluateJavascript("(function(){if(window.__nbmPage){window.__nbmPage(" + (all ? "true" : "false") + ");return 1}return 0})()", value -> {
            if (!"1".equals(value)) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("mode", "page");
                    o.put("page", t.url);
                    o.put("title", t.title == null ? "" : t.title);
                    o.put("items", new JSONArray());
                    mediaFromPage(t, o.toString());
                } catch (JSONException ignored) {
                }
            }
        });
    }

    // ---------- Save button: one round button drawn by the app (never inside a page), shown when the page has a video or big picture ----------
    private void buildMediaFab() {
        mediaFab = new TextView(this);
        mediaFab.setText("\u2193");
        mediaFab.setTextColor(Color.WHITE);
        mediaFab.setTextSize(22);
        mediaFab.setTypeface(Typeface.DEFAULT_BOLD);
        mediaFab.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xEE1C1C24);
        g.setStroke(dp(2), accent);
        mediaFab.setBackground(g);
        mediaFab.setElevation(dp(6));
        mediaFab.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.START);
        root.addView(mediaFab, lp);
        mediaFab.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mfX0 = e.getRawX();
                    mfY0 = e.getRawY();
                    mfDx = v.getX() - mfX0;
                    mfDy = v.getY() - mfY0;
                    mfMoved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!mfMoved && Math.abs(e.getRawX() - mfX0) + Math.abs(e.getRawY() - mfY0) < dp(10)) return true;
                    mfMoved = true;
                    float nx = Math.max(0, Math.min(root.getWidth() - v.getWidth(), e.getRawX() + mfDx));
                    float ny = Math.max(0, Math.min(root.getHeight() - v.getHeight(), e.getRawY() + mfDy));
                    v.setX(nx);
                    v.setY(ny);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (mfMoved) {
                        vault.edit().putFloat("mfx", v.getX() / Math.max(1, root.getWidth())).putFloat("mfy", v.getY() / Math.max(1, root.getHeight())).apply();
                    } else {
                        openMediaList(false);
                    }
                    return true;
                default:
                    return true;
            }
        });
    }

    private void placeMediaFab() {
        if (mediaFab == null || root.getWidth() == 0) return;
        float fx = vault.getFloat("mfx", -1f), fy = vault.getFloat("mfy", -1f);
        if (fx < 0) {
            fx = 1f - (float) dp(60) / root.getWidth();
            fy = 0.62f;
        }
        mediaFab.setX(Math.max(0, Math.min(root.getWidth() - dp(46), fx * root.getWidth())));
        mediaFab.setY(Math.max(0, Math.min(root.getHeight() - dp(46), fy * root.getHeight())));
    }

    private final Runnable mediaPoll = new Runnable() {
        @Override
        public void run() {
            mediaPolling = false;
            checkMediaFab();
            scheduleMediaPoll();
        }
    };

    private void scheduleMediaPoll() {
        if (mediaPolling) return;
        mediaPolling = true;
        ui.postDelayed(mediaPoll, 2200);
    }

    private void checkMediaFab() {
        if (mediaFab == null) return;
        final Tab t = activeTab();
        boolean want = st.optBoolean("dlMedia", true) && st.optBoolean("dlButtons", true) && t != null && !t.isHome() && !locked && panelOpenGuard();
        if (!want) {
            mediaFab.setVisibility(View.GONE);
            return;
        }
        t.web.evaluateJavascript("(function(){try{return window.__nbmHas?window.__nbmHas():0}catch(e){return 0}})()", v -> {
            if (t != activeTab()) return;
            boolean has = "1".equals(v);
            if (has) {
                mfMiss = 0;
                if (mediaFab.getVisibility() != View.VISIBLE) {
                    placeMediaFab();
                    mediaFab.setVisibility(View.VISIBLE);
                }
            } else if (++mfMiss >= 3) {
                mediaFab.setVisibility(View.GONE);
            }
        });
    }

    private boolean panelOpenGuard() {
        return !fullscreen && !chromeFull;
    }

    // ---------- pull up from the very bottom of a page to close the tab ----------
    private void closeCancel() {
        closeActive = false;
        if (closeHint != null) closeHint.setVisibility(View.GONE);
    }

    private void closeTouch(final Tab t, MotionEvent e) {
        if (!st.optBoolean("pullClose", true) || t != activeTab() || closeHint == null) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                closeArmed = false;
                closeActive = false;
                closeStartY = e.getRawY();
                final int seq = ++closeSeq;
                // only when the finger starts in the lower part of the screen and the page is truly at its end
                if (e.getY() >= t.web.getHeight() * 0.6f && !t.web.canScrollVertically(1)) {
                    String fx = String.valueOf(e.getX() / Math.max(1, t.web.getWidth()));
                    String fy = String.valueOf(e.getY() / Math.max(1, t.web.getHeight()));
                    String code = "(function(a,b){try{var s=document.scrollingElement||document.documentElement;"
                            + "if((window.scrollY||s.scrollTop)+innerHeight<s.scrollHeight-3)return false;"
                            + "var e=document.elementFromPoint(a*innerWidth,b*innerHeight);"
                            + "while(e&&e!==document.body&&e!==document.documentElement){var c=getComputedStyle(e).overflowY;"
                            + "if((c==='auto'||c==='scroll'||c==='overlay')&&e.scrollHeight>e.clientHeight+1&&e.scrollTop+e.clientHeight<e.scrollHeight-3)return false;e=e.parentElement}"
                            + "return true}catch(x){return false}})(" + fx + "," + fy + ")";
                    t.web.evaluateJavascript(code, val -> {
                        if (seq == closeSeq && "true".equals(val)) closeArmed = true;
                    });
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (e.getPointerCount() > 1) {
                    closeArmed = false;
                    closeCancel();
                    break;
                }
                if (!closeArmed) break;
                float dy = closeStartY - e.getRawY(), dead = dp(24);
                if (dy > dead) {
                    closeActive = true;
                    float pr = Math.min(1f, (dy - dead) / dp(110));
                    closeHint.setText(pr >= 1f ? "Release to close tab" : "\u2715  Pull up to close tab");
                    closeHint.setVisibility(View.VISIBLE);
                    closeHint.setAlpha(0.35f + 0.65f * pr);
                    closeHint.setScaleX(0.85f + 0.15f * pr);
                    closeHint.setScaleY(0.85f + 0.15f * pr);
                    closeHint.setTag(pr >= 1f);
                } else if (closeActive) {
                    closeCancel();
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                closeSeq++;
                boolean go = closeActive && Boolean.TRUE.equals(closeHint.getTag()) && e.getActionMasked() == MotionEvent.ACTION_UP;
                closeArmed = false;
                closeCancel();
                if (go) {
                    toast("Tab closed. Undo: Menu > Closed tabs");
                    closeTab(t);
                }
                break;
            }
            default:
                break;
        }
    }

    // ---------- edge swipes: from the left edge = back, from the right edge = forward ----------
    /** brief label in the middle of the screen so you can see what a gesture just did */
    private void flashAction(String text) {
        if (actPill == null) return;
        actPill.animate().cancel();
        actPill.setText(text);
        actPill.setAlpha(0f);
        actPill.setScaleX(0.85f);
        actPill.setScaleY(0.85f);
        actPill.setVisibility(View.VISIBLE);
        actPill.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).withEndAction(() ->
                actPill.animate().alpha(0f).setStartDelay(750).setDuration(260).withEndAction(() -> actPill.setVisibility(View.GONE)).start()).start();
    }

    private String histTitle(Tab t, int delta) {
        try {
            android.webkit.WebBackForwardList l = t.web.copyBackForwardList();
            int i = l.getCurrentIndex() + delta;
            if (i < 0 || i >= l.getSize()) return "";
            android.webkit.WebHistoryItem h = l.getItemAtIndex(i);
            String ti = h.getTitle();
            if (ti == null || ti.isEmpty()) ti = Uri.parse(h.getUrl()).getHost();
            return ti == null ? "" : ti;
        } catch (Exception e) {
            return "";
        }
    }

    private void edgeCancel() {
        edgeOn = false;
        if (edgeHint != null) edgeHint.setVisibility(View.GONE);
    }

    private void edgeShow(float pr, boolean left) {
        if (edgeHint == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) edgeHint.getLayoutParams();
        int g = Gravity.CENTER_VERTICAL | (left ? Gravity.START : Gravity.END);
        if (lp.gravity != g) {
            lp.gravity = g;
            edgeHint.setLayoutParams(lp);
        }
        edgeHint.setText(pr >= 1f ? (left ? "\u2190" : "\u2192") : (left ? "\u2039" : "\u203A"));
        edgeHint.setVisibility(View.VISIBLE);
        edgeHint.setAlpha(Math.min(1f, pr * 1.4f));
        edgeHint.setScaleX(0.6f + 0.4f * pr);
        edgeHint.setScaleY(0.6f + 0.4f * pr);
        edgeHint.setTranslationX((left ? 1f : -1f) * (pr * dp(26) - dp(8)));
    }

    private void edgeTouch(Tab t, MotionEvent e) {
        if (!st.optBoolean("edgeSwipe", true) || t != activeTab() || root == null) return;
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            float edge = dp(Math.max(12, Math.min(48, st.optInt("edgeSize", 24))));
            float w = t.web.getWidth();
            edgeSide = e.getX() <= edge ? -1 : (e.getX() >= w - edge ? 1 : 0);
            edgeOn = edgeSide != 0;
            edgeX0 = e.getX();
            edgeY0 = e.getY();
            edgeDx = 0f;
            return;
        }
        if (!edgeOn) return;
        if (a == MotionEvent.ACTION_MOVE) {
            if (e.getPointerCount() > 1) {
                edgeCancel();
                return;
            }
            float dx = (e.getX() - edgeX0) * (edgeSide == -1 ? 1f : -1f);
            float dy = Math.abs(e.getY() - edgeY0);
            if (dy > dp(30) && dy > dx * 1.2f) {
                edgeCancel();
                return;
            }
            edgeDx = dx;
            edgeShow(Math.max(0f, Math.min(1f, dx / dp(110))), edgeSide == -1);
        } else if (a == MotionEvent.ACTION_UP) {
            boolean go = edgeDx >= dp(110);
            boolean left = edgeSide == -1;
            edgeCancel();
            if (!go) return;
            if (left) {
                if (t.web.canGoBack()) {
                    String ti = histTitle(t, -1);
                    flashAction("\u2190  Back" + (ti.isEmpty() ? "" : "  \u00b7  " + ti));
                    t.web.goBack();
                } else flashAction("Nothing to go back to");
            } else if (t.web.canGoForward()) {
                String ti = histTitle(t, 1);
                flashAction("Forward  \u2192" + (ti.isEmpty() ? "" : "  \u00b7  " + ti));
                t.web.goForward();
            } else {
                flashAction("Nothing to go forward to");
            }
        } else if (a == MotionEvent.ACTION_CANCEL) {
            edgeCancel();
        }
    }

    // ---------- one-tap VPN (sets itself up, then connects) ----------
    private void autoVpn() {
        if (vpnConfig().length() > 0) {
            startVpn();
            return;
        }
        vpnMsg = "Setting up your private tunnel...";
        pushVpn();
        new Thread(() -> {
            try {
                final String cfg = Vpn.registerWarp();
                ui.post(() -> {
                    vault.edit().putString("vpncfg", cfg).apply();
                    vpnMsg = "Tunnel ready";
                    pushVpn();
                    startVpn();
                });
            } catch (final Exception e) {
                ui.post(() -> {
                    String m = e.getMessage();
                    vpnMsg = "Could not set up by itself (" + (m == null ? e.getClass().getSimpleName() : m) + "). Check your internet, or paste your own WireGuard config under Advanced.";
                    pushVpn();
                });
            }
        }).start();
    }

    // ---------- tabs ----------
    private void swapPaneTabs(int a, int b) {
        if (a < 0 || b < 0 || a >= paneTabs.length || b >= paneTabs.length || a == b) return;
        int t = paneTabs[a];
        paneTabs[a] = paneTabs[b];
        paneTabs[b] = t;
        rebuildPanes();
        postState();
    }

    private void rotatePanes() {
        if (paneTabs.length < 2) return;
        int last = paneTabs[paneTabs.length - 1];
        for (int i = paneTabs.length - 1; i > 0; i--) paneTabs[i] = paneTabs[i - 1];
        paneTabs[0] = last;
        rebuildPanes();
        postState();
    }

    private void moveTab(Tab t, int dir) {
        int i = tabs.indexOf(t), j = i + dir;
        if (i < 0 || j < 0 || j >= tabs.size()) return;
        tabs.remove(i);
        tabs.add(j, t);
        postState();
    }

    private void setRefresh(final Tab t, int sec) {
        t.refreshSec = sec;
        if (t.refreshTask != null) ui.removeCallbacks(t.refreshTask);
        t.refreshTask = null;
        if (sec > 0) {
            t.refreshTask = new Runnable() {
                @Override
                public void run() {
                    if (!tabs.contains(t)) return;
                    if (!t.loading && !t.isHome()) t.web.reload();
                    ui.postDelayed(this, Math.max(2, t.refreshSec) * 1000L);
                }
            };
            ui.postDelayed(t.refreshTask, sec * 1000L);
        }
        postState();
    }

    private void setOrient(String m) {
        int o = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        if ("landscape".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        else if ("portrait".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
        else if ("sensor".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR;
        setRequestedOrientation(o);
    }

    // =====================================================================================
    //  media downloader: Save button on pictures and videos -> quality and size list -> download
    // =====================================================================================
    static class Job {
        long id;
        String title = "", mime = "";
        int status = 2;
        volatile long got, total = -1;
        volatile boolean cancel;
        long ts = System.currentTimeMillis();
        Uri uri;
        Runnable redo;
    }

    static class Res {
        File file;
        String name, mime;

        Res(File f, String n, String m) {
            file = f;
            name = n;
            mime = m;
        }
    }

    interface JobBody {
        Res run(Job j, File dir, MediaGrab.Prog p) throws Exception;
    }

    static class MaxScroll extends ScrollView {
        final int maxH;

        MaxScroll(Context c, int m) {
            super(c);
            maxH = m;
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST));
        }
    }

    private final Map<Long, Job> jobs = new LinkedHashMap<>();
    private long jobSeq = 0;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private static final Pattern MEDIA_EXT = Pattern.compile("\\.(mp4|m4v|webm|mov|m3u8|mp3|m4a|aac|ogg|opus|flac|wav)$");

    /** notes down video / audio links a page asks for, so embedded players can be downloaded too */
    private void sniff(Tab t, Uri u, WebResourceRequest r) {
        try {
            String p = u.getPath();
            if (p == null) return;
            String lp = p.toLowerCase(Locale.ROOT);
            if (!MEDIA_EXT.matcher(lp).find() || lp.contains("videoplayback")) return;
            String s = u.toString();
            String q = u.getQuery();
            if (q != null && (q.contains("bytestart=") || q.contains("byteend="))) {
                Uri.Builder b = u.buildUpon().clearQuery();
                for (String n : u.getQueryParameterNames()) {
                    if (n.equals("bytestart") || n.equals("byteend")) continue;
                    for (String v : u.getQueryParameters(n)) b.appendQueryParameter(n, v);
                }
                s = b.build().toString();
            }
            String ref = r.getRequestHeaders().get("Referer");
            synchronized (t.sniffed) {
                t.sniffed.remove(s);
                t.sniffed.put(s, new String[]{ref == null ? "" : ref});
                while (t.sniffed.size() > 40) {
                    Iterator<String> it = t.sniffed.keySet().iterator();
                    it.next();
                    it.remove();
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void mediaFromPage(Tab t, String json) {
        try {
            JSONObject o = new JSONObject(json);
            String page = o.optString("page", t.url);
            String title = o.optString("title", "");
            String mode = o.optString("mode", "page");
            ArrayList<String> notes = new ArrayList<>();
            JSONArray na = o.optJSONArray("notes");
            if (na != null) for (int i = 0; i < na.length(); i++) notes.add(na.optString(i));
            ArrayList<MediaGrab.Item> list = new ArrayList<>();
            HashSet<String> seen = new HashSet<>();
            JSONArray arr = o.optJSONArray("items");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject x = arr.optJSONObject(i);
                    if (x == null) continue;
                    String url = x.optString("url", "");
                    if (url.isEmpty() || !seen.add(url)) continue;
                    MediaGrab.Item it = new MediaGrab.Item();
                    it.kind = x.optString("k", "v");
                    it.url = url;
                    it.ref = page;
                    it.w = x.optInt("w", 0);
                    it.h = x.optInt("h", 0);
                    it.br = x.optInt("br", 0);
                    it.bytes = x.optLong("sz", 0) > 0 ? x.optLong("sz") : -1;
                    it.label = x.optString("l", "");
                    it.mime = x.optString("m", "");
                    it.group = x.optString("g", "");
                    it.vo = x.optBoolean("vo", false);
                    it.ao = x.optBoolean("ao", false);
                    it.seq = x.optLong("t", 0);
                    list.add(it);
                }
            }
            // keep only the newest few groups of links the page's data handed over, so a busy feed does not flood the list
            HashMap<String, Long> newest = new HashMap<>();
            for (MediaGrab.Item it : list) {
                if (it.group.matches("g\\d+")) {
                    Long cur = newest.get(it.group);
                    if (cur == null || it.seq > cur) newest.put(it.group, it.seq);
                }
            }
            if (newest.size() > 3 && !o.optBoolean("exact", false)) {
                ArrayList<Long> seqs = new ArrayList<>(newest.values());
                java.util.Collections.sort(seqs);
                long cut = seqs.get(seqs.size() - 3);
                for (int i = list.size() - 1; i >= 0; i--) {
                    MediaGrab.Item it = list.get(i);
                    if (it.group.matches("g\\d+") && newest.get(it.group) < cut) list.remove(i);
                }
            }
            while (list.size() > 40) list.remove(list.size() - 1);
            if (!mode.equals("image") && !o.optBoolean("exact", false)) {
                ArrayList<String[]> sn = new ArrayList<>();
                synchronized (t.sniffed) {
                    for (Map.Entry<String, String[]> e : t.sniffed.entrySet()) sn.add(new String[]{e.getKey(), e.getValue()[0]});
                }
                int from = Math.max(0, sn.size() - 8);
                for (int i = sn.size() - 1; i >= from; i--) {
                    String url = sn.get(i)[0];
                    if (!seen.add(url)) continue;
                    MediaGrab.Item it = new MediaGrab.Item();
                    String lp = url.toLowerCase(Locale.ROOT);
                    it.kind = lp.matches(".*\\.(mp3|m4a|aac|ogg|opus|flac|wav)(\\?.*)?$") ? "a" : "v";
                    it.url = url;
                    it.ref = sn.get(i)[1].isEmpty() ? page : sn.get(i)[1];
                    it.group = "net";
                    list.add(it);
                }
            }
            showMediaSheet(t, page, title, mode, list, notes);
        } catch (Exception e) {
            toast("Could not read the media on this page");
        }
    }

    private void showMediaSheet(Tab t, String page, String title, String mode, ArrayList<MediaGrab.Item> list, ArrayList<String> notes) {
        MediaSheet s = new MediaSheet(t, page, title, mode, notes);
        s.show();
        s.addAll(list);
    }

    private static String sizeText(long b) {
        return b > 0 ? formatSize(b) : "";
    }

    /** the bottom sheet that lists every quality and size */
    class MediaSheet {
        final Tab tab;
        final String page, title, mode;
        final ArrayList<String> notes;
        final ArrayList<MediaGrab.Item> items = new ArrayList<>();
        final HashSet<String> keys = new HashSet<>();
        final String ua;
        Dialog dlg;
        LinearLayout box;
        TextView status;
        int pending = 0;
        boolean dark = appDark;
        int ink, mute, bg, acc;

        MediaSheet(Tab t, String p, String ti, String m, ArrayList<String> n) {
            tab = t;
            page = p;
            title = ti;
            mode = m;
            notes = n;
            ua = userAgent(t);
            ink = dark ? 0xFFF2F2F5 : 0xFF1A1A20;
            mute = dark ? 0xFFA0A0AC : 0xFF6A6A76;
            bg = dark ? 0xFF1E1E26 : 0xFFFFFFFF;
            acc = parseColor(st.optString("accent", ""), 0xFFF0642F);
        }

        TextView tv(String s, int sp, int color, boolean bold) {
            TextView v = new TextView(MainActivity.this);
            v.setText(s);
            v.setTextSize(sp);
            v.setTextColor(color);
            if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
            return v;
        }

        void show() {
            dlg = new Dialog(MainActivity.this);
            dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
            LinearLayout root = new LinearLayout(MainActivity.this);
            root.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(bg);
            float r = dp(22);
            gd.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            root.setBackground(gd);
            root.setPadding(dp(18), dp(14), dp(18), dp(14));
            String host = "";
            try {
                host = Uri.parse(page).getHost();
            } catch (Exception ignored) {
            }
            root.addView(tv(mode.equals("image") ? "Download picture" : mode.equals("video") ? "Download video" : "Media on this page", 19, ink, true));
            root.addView(tv(host == null ? "" : host, 12, mute, false));
            status = tv("Checking sizes...", 12, mute, false);
            status.setPadding(0, dp(4), 0, dp(6));
            root.addView(status);
            MaxScroll sv = new MaxScroll(MainActivity.this, (int) (getResources().getDisplayMetrics().heightPixels * 0.62f));
            box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            sv.addView(box);
            root.addView(sv);
            for (String n : notes) {
                TextView x = tv(n, 12, mute, false);
                x.setPadding(0, dp(8), 0, 0);
                root.addView(x);
            }
            TextView fine = tv("Only save what you are allowed to keep. Protected (DRM) streams are skipped.", 11, mute, false);
            fine.setPadding(0, dp(8), 0, 0);
            root.addView(fine);
            dlg.setContentView(root);
            dlg.setCanceledOnTouchOutside(true);
            android.view.Window w = dlg.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
                w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                w.setGravity(Gravity.BOTTOM);
            }
            dlg.show();
        }

        void addAll(ArrayList<MediaGrab.Item> list) {
            for (MediaGrab.Item it : list) addOne(it);
            if (mode.equals("image")) addResizeOptions();
            check();
        }

        void addResizeOptions() {
            MediaGrab.Item base = null;
            for (MediaGrab.Item it : items) {
                if (it.kind.equals("i") && it.how.equals("direct") && (base == null || Math.max(it.w, it.h) > Math.max(base.w, base.h))) {
                    if (base == null || it.w > 0) base = it;
                }
                if (it.kind.equals("i") && "cur".equals(it.group)) {
                    base = it;
                    break;
                }
            }
            if (base == null) return;
            int big = Math.max(base.w, base.h);
            int[] dims = {1600, 1024, 640};
            for (int d : dims) {
                if (big > 0 && d >= big) continue;
                MediaGrab.Item r = MediaGrab.copy(base);
                r.how = "resize";
                r.maxDim = d;
                r.label = "Smaller copy";
                r.group = "resize";
                addOne(r);
            }
        }

        void addOne(MediaGrab.Item it) {
            if (!keys.add(it.key())) return;
            if (it.how.equals("direct") && it.kind.equals("v") && MediaGrab.looksLikePlaylist(it.url, it.mime)) {
                pending++;
                final MediaGrab.Item src = it;
                if (!curProxy.isEmpty()) {
                    pending--;
                    return;
                }
                pool.execute(() -> {
                    MediaGrab.expandHls(src, ua, found -> ui.post(() -> {
                        if (keys.add(found.key())) {
                            items.add(found);
                            render();
                        }
                    }));
                    ui.post(() -> {
                        pending--;
                        render();
                    });
                });
                return;
            }
            items.add(it);
            if (!it.checked && curProxy.isEmpty()) {
                pending++;
                final MediaGrab.Item f = it;
                pool.execute(() -> {
                    boolean ok = MediaGrab.probe(f, ua);
                    f.checked = true;
                    ui.post(() -> {
                        pending--;
                        if (!ok) items.remove(f);
                        else if (f.kind.equals("v") && f.mime.startsWith("audio/")) f.kind = "a";
                        else if (f.kind.equals("v") && f.mime.startsWith("image/")) f.kind = "i";
                        render();
                    });
                });
            }
        }

        void check() {
            render();
        }

        String ext(MediaGrab.Item it) {
            if (it.how.equals("hls") || it.how.equals("merge")) return "MP4";
            if (it.how.equals("resize")) return "JPG";
            return MediaGrab.extFor(it.mime, it.url, it.kind.equals("i") ? "jpg" : it.kind.equals("a") ? "m4a" : "mp4").toUpperCase(Locale.ROOT);
        }

        ArrayList<MediaGrab.Item> merged() {
            ArrayList<MediaGrab.Item> out = new ArrayList<>();
            for (MediaGrab.Item v : items) {
                if (!v.vo) continue;
                MediaGrab.Item best = null;
                for (MediaGrab.Item a : items) {
                    if (!a.ao || !a.group.equals(v.group)) continue;
                    boolean vm = v.mime.contains("mp4"), am = a.mime.contains("mp4");
                    if (vm != am) continue;
                    if (best == null || a.br > best.br) best = a;
                }
                if (best == null) continue;
                MediaGrab.Item m = MediaGrab.copy(v);
                m.how = "merge";
                m.vo = false;
                m.url2 = best.url;
                m.bytes2 = best.bytes;
                m.bytes = v.bytes > 0 && best.bytes > 0 ? v.bytes + best.bytes : -1;
                out.add(m);
            }
            return out;
        }

        long estimate(MediaGrab.Item it) {
            if (it.how.equals("resize")) {
                for (MediaGrab.Item b : items) {
                    if (b.kind.equals("i") && b.how.equals("direct") && b.url.equals(it.url) && b.bytes > 0) {
                        int big = Math.max(b.w, b.h);
                        if (big <= 0) return -1;
                        double f = Math.min(1.0, (double) it.maxDim / big);
                        return (long) (b.bytes * f * f * 0.85);
                    }
                }
                return -1;
            }
            return it.bytes;
        }

        void row(MediaGrab.Item it, int lastH) {
            String head, det;
            String x = ext(it);
            if (it.kind.equals("i")) {
                if (it.how.equals("resize")) {
                    head = "Smaller copy · " + it.maxDim + " px";
                    det = "Shrunk on your phone, saved as " + x;
                } else {
                    String dim = it.w > 0 && it.h > 0 ? it.w + " × " + it.h : it.w > 0 ? it.w + " px wide" : "";
                    head = (it.label.isEmpty() ? (dim.isEmpty() ? "Picture" : dim) : it.label + (dim.isEmpty() ? "" : " · " + dim)) + " · " + x;
                    det = "Original file, nothing changed";
                }
            } else if (it.kind.equals("a")) {
                head = "Audio only · " + x + (it.br > 0 ? " · " + (it.br / 1000) + " kbps" : "");
                det = "Sound without video";
            } else {
                String q = it.h > 0 ? it.h + "p" : (it.w > 0 ? it.w + " px" : (it.label.isEmpty() ? "Video" : it.label));
                head = q + " · " + x;
                if (it.protectedStream) det = "Protected, cannot be saved";
                else if (it.how.equals("merge")) det = "Video and sound joined on your phone";
                else if (it.how.equals("hls")) det = "Stream pieces joined into one file" + (it.dur > 0 ? " · " + (int) (it.dur / 60) + ":" + String.format(Locale.US, "%02d", (int) (it.dur % 60)) : "");
                else if (it.vo) det = "Video only, no sound";
                else det = it.label.isEmpty() ? "Video file" : it.label;
                if (it.br > 0 && !it.how.equals("merge")) det += " · " + Math.round(it.br / 1000f) + " kbps";
            }
            long sz = estimate(it);
            String right = sz > 0 ? ((it.how.equals("hls") || it.how.equals("resize") ? "≈ " : "") + formatSize(sz)) : (it.checked || !curProxy.isEmpty() ? "size ?" : "...");
            LinearLayout rw = new LinearLayout(MainActivity.this);
            rw.setOrientation(LinearLayout.HORIZONTAL);
            rw.setGravity(Gravity.CENTER_VERTICAL);
            rw.setPadding(dp(4), dp(10), dp(4), dp(10));
            android.util.TypedValue tvv = new android.util.TypedValue();
            if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tvv, true)) rw.setBackgroundResource(tvv.resourceId);
            LinearLayout left = new LinearLayout(MainActivity.this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(tv(head, 15, it.protectedStream ? mute : ink, true));
            left.addView(tv(det, 12, mute, false));
            rw.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView rt = tv(right, 13, acc, true);
            rw.addView(rt);
            if (!it.protectedStream) {
                final MediaGrab.Item pick = it;
                rw.setOnClickListener(v -> {
                    dlg.dismiss();
                    startMedia(pick, tab, title, page);
                });
            }
            box.addView(rw);
        }

        void section(String s) {
            TextView h = tv(s.toUpperCase(Locale.ROOT), 11, mute, true);
            h.setPadding(dp(4), dp(12), 0, dp(2));
            box.addView(h);
        }

        void render() {
            if (dlg == null || !dlg.isShowing()) return;
            box.removeAllViews();
            ArrayList<MediaGrab.Item> vids = new ArrayList<>(), auds = new ArrayList<>(), imgs = new ArrayList<>(), only = new ArrayList<>();
            ArrayList<MediaGrab.Item> mg = merged();
            for (MediaGrab.Item it : mg) vids.add(it);
            for (MediaGrab.Item it : items) {
                if (it.kind.equals("i")) imgs.add(it);
                else if (it.ao || it.kind.equals("a")) auds.add(it);
                else if (it.vo) only.add(it);
                else vids.add(it);
            }
            final java.util.Comparator<MediaGrab.Item> byQ = (a, b) -> {
                int c = Integer.compare(b.h > 0 ? b.h : b.w, a.h > 0 ? a.h : a.w);
                if (c != 0) return c;
                return Long.compare(b.bytes, a.bytes);
            };
            java.util.Collections.sort(vids, byQ);
            java.util.Collections.sort(only, byQ);
            java.util.Collections.sort(imgs, (a, b) -> {
                int ra = a.how.equals("resize") ? 1 : 0, rb = b.how.equals("resize") ? 1 : 0;
                if (ra != rb) return ra - rb;
                if (ra == 1) return Integer.compare(b.maxDim, a.maxDim);
                return Integer.compare(Math.max(b.w, b.h), Math.max(a.w, a.h));
            });
            if (!vids.isEmpty()) {
                section("Video");
                for (MediaGrab.Item it : vids) row(it, 0);
            }
            if (!auds.isEmpty()) {
                section("Audio only");
                for (MediaGrab.Item it : auds) row(it, 0);
            }
            if (!imgs.isEmpty()) {
                section("Pictures");
                for (MediaGrab.Item it : imgs) row(it, 0);
            }
            if (!only.isEmpty()) {
                section("Video without sound");
                for (MediaGrab.Item it : only) row(it, 0);
            }
            boolean any = !vids.isEmpty() || !auds.isEmpty() || !imgs.isEmpty() || !only.isEmpty();
            if (!any) {
                TextView e = tv(pending > 0 ? "Looking..." : "Nothing downloadable was found here. If a video is playing, let it start for a moment and try again, or use Menu > Media on page.", 14, mute, false);
                e.setPadding(dp(4), dp(12), dp(4), dp(12));
                box.addView(e);
            }
            status.setText(pending > 0 ? "Checking sizes..." : "Tap one to download");
        }
    }

    private static String cleanName(String s, String fallback) {
        String n = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", " ").replaceAll("\\s+", " ").trim();
        if (n.length() > 70) n = n.substring(0, 70).trim();
        return n.isEmpty() ? fallback : n;
    }

    private void startMedia(final MediaGrab.Item it, final Tab t, final String pageTitle, final String page) {
        final String ua = userAgent(t);
        final String ref = it.ref == null || it.ref.isEmpty() ? page : it.ref;
        final String q = it.h > 0 && !it.kind.equals("i") ? " " + it.h + "p" : "";
        String urlBase = "";
        try {
            String seg = Uri.parse(it.url).getLastPathSegment();
            if (seg != null) urlBase = seg.replaceAll("\\.[A-Za-z0-9]{2,5}$", "");
        } catch (Exception ignored) {
        }
        final String base;
        if (it.kind.equals("i")) base = cleanName(urlBase, "image");
        else base = cleanName(pageTitle, "video") + q;
        final boolean viaApp = vpnUp || !curProxy.isEmpty();

        if (it.how.equals("direct")) {
            String ext = MediaGrab.extFor(it.mime, it.url, it.kind.equals("i") ? "jpg" : it.kind.equals("a") ? "m4a" : "mp4");
            final String name = (it.kind.equals("i") ? base : base + (it.vo ? " (no sound)" : "")) + "." + ext;
            final String mime = MediaGrab.mimeForExt(ext, it.kind.equals("i") ? "image/jpeg" : it.kind.equals("a") ? "audio/mp4" : "video/mp4");
            if (!viaApp) {
                enqueueDownload(it.url, ua, name, mime, ref);
                return;
            }
            runJob(name, mime, (j, dir, p) -> {
                File f = new File(dir, "j" + j.id + ".part");
                MediaGrab.fetchTo(it.url, f, ua, ref, p);
                return new Res(f, name, mime);
            });
        } else if (it.how.equals("resize")) {
            final String nameBase = base + "-" + it.maxDim + "px";
            runJob(nameBase + ".jpg", "image/jpeg", (j, dir, p) -> {
                File f = new File(dir, "j" + j.id + ".part");
                MediaGrab.fetchTo(it.url, f, ua, ref, p);
                File o = new File(dir, "j" + j.id + ".out");
                String ext = MediaGrab.resize(f, o, it.maxDim);
                return new Res(o, nameBase + "." + ext, ext.equals("png") ? "image/png" : "image/jpeg");
            });
        } else if (it.how.equals("merge")) {
            runJob(base + ".mp4", "video/mp4", (j, dir, p) -> {
                File fv = new File(dir, "j" + j.id + "v.part"), fa = new File(dir, "j" + j.id + "a.part");
                MediaGrab.fetchTo(it.url, fv, ua, ref, p);
                MediaGrab.fetchTo(it.url2, fa, ua, ref, p);
                boolean web = MediaGrab.wantsWebm(fv);
                File o = new File(dir, "j" + j.id + (web ? ".webm" : ".mp4"));
                if (MediaGrab.mux(new File[]{fv, fa}, o, web)) return new Res(o, base + (web ? ".webm" : ".mp4"), web ? "video/webm" : "video/mp4");
                String ve = MediaGrab.extFor(it.mime, it.url, "mp4");
                return new Res(fv, base + " (no sound)." + ve, MediaGrab.mimeForExt(ve, "video/mp4"));
            });
        } else { // hls
            if (it.bytes > 0) toastLong("Joining the stream pieces. Long videos take a while.");
            runJob(base + ".mp4", "video/mp4", (j, dir, p) -> {
                if (it.bytes > 0) j.total = it.bytes;
                File fv = new File(dir, "j" + j.id + "v.part");
                MediaGrab.hlsDownload(it.url, fv, ua, ref, p);
                File fa = null;
                if (it.url2 != null) {
                    fa = new File(dir, "j" + j.id + "a.part");
                    MediaGrab.hlsDownload(it.url2, fa, ua, ref, p);
                }
                File o = new File(dir, "j" + j.id + ".mp4");
                File[] ins = fa == null ? new File[]{fv} : new File[]{fv, fa};
                if (MediaGrab.mux(ins, o, false)) return new Res(o, base + ".mp4", "video/mp4");
                return new Res(fv, base + ".ts", "video/mp2t");
            });
        }
    }

    private void toastLong(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    private void runJob(final String title, final String mimeGuess, final JobBody body) {
        final Job j = new Job();
        synchronized (jobs) {
            j.id = -(++jobSeq);
            jobs.put(j.id, j);
        }
        j.title = title;
        j.mime = mimeGuess;
        j.redo = () -> {
            synchronized (jobs) {
                jobs.remove(j.id);
            }
            runJob(title, mimeGuess, body);
        };
        toast("Downloading " + title);
        js("window.NB&&NB.event('dl',true)");
        pool.execute(() -> {
            File dir = new File(getCacheDir(), "nbdl");
            dir.mkdirs();
            MediaGrab.Prog p = new MediaGrab.Prog() {
                @Override
                public void add(long n) {
                    j.got += n;
                    if (j.total >= 0 && j.got > j.total) j.total = j.got;
                }

                @Override
                public void total(long t) {
                    j.total = Math.max(j.total, 0) + t;
                }

                @Override
                public boolean stop() {
                    return j.cancel;
                }
            };
            try {
                Res r = body.run(j, dir, p);
                Uri u = MediaGrab.publish(MainActivity.this, r.file, r.name, r.mime,
                        st.optBoolean("dlSort", true) ? categoryOf(r.name, r.mime) : "");
                j.uri = u;
                j.title = r.name;
                j.mime = r.mime;
                j.ts = System.currentTimeMillis();
                j.status = 8;
                final String nm = r.name;
                ui.post(() -> toast("Saved " + nm));
            } catch (final Exception e) {
                j.status = 16;
                j.ts = System.currentTimeMillis();
                final String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                ui.post(() -> toastLong("Download failed: " + m));
            } finally {
                File[] left = dir.listFiles();
                if (left != null) {
                    for (File f : left) {
                        if (f.getName().startsWith("j" + j.id + ".") || f.getName().startsWith("j" + j.id + "v.") || f.getName().startsWith("j" + j.id + "a.")) f.delete();
                    }
                }
            }
        });
    }

    // ---------- downloads ----------
    private static String formatSize(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(Locale.US, "%.0f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    /** finds the real file name and type (so videos end in .mp4 and not .bin). Runs off the main thread. */
    private String[] probeDownload(String url, String ua, String cd, String mime) {
        String type = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        String disp = cd;
        String size = "";
        long lenBytes = -1;
        boolean generic = type.isEmpty() || type.equals("application/octet-stream") || type.equals("binary/octet-stream")
                || type.equals("application/force-download") || type.equals("application/download");
        try {
            String qm = Uri.parse(url).getQueryParameter("mime");
            if (generic && qm != null && qm.contains("/")) {
                type = qm.toLowerCase(Locale.ROOT);
                generic = false;
            }
        } catch (Exception ignored) {
        }
        if ((generic || disp == null || disp.isEmpty()) && curProxy.isEmpty() && url.startsWith("http")) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("HEAD");
                c.setConnectTimeout(6000);
                c.setReadTimeout(6000);
                c.setInstanceFollowRedirects(true);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) c.setRequestProperty("Cookie", ck);
                if (c.getResponseCode() < 400) {
                    String ct = c.getContentType();
                    if (ct != null) {
                        ct = ct.split(";")[0].trim().toLowerCase(Locale.ROOT);
                        if (!ct.isEmpty() && !ct.equals("application/octet-stream") && !ct.equals("binary/octet-stream")) {
                            type = ct;
                            generic = false;
                        }
                    }
                    String h = c.getHeaderField("Content-Disposition");
                    if (h != null && !h.isEmpty()) disp = h;
                    long len = c.getContentLengthLong();
                    if (len > 0) {
                        size = formatSize(len);
                        lenBytes = len;
                    }
                }
                c.disconnect();
            } catch (Exception ignored) {
            }
        }
        String name = URLUtil.guessFileName(url, disp, generic ? null : type);
        if (!generic) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(type);
            if (ext != null && (name.endsWith(".bin") || name.indexOf('.') < 0)) {
                int dot = name.lastIndexOf('.');
                name = (dot > 0 ? name.substring(0, dot) : name) + "." + ext;
            }
        }
        if (name.endsWith(".bin")) {
            String seg = Uri.parse(url).getLastPathSegment();
            if (seg != null && seg.matches(".*\\.[A-Za-z0-9]{2,5}$")) name = seg;
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return new String[]{name, generic ? "application/octet-stream" : type, size, String.valueOf(lenBytes)};
    }

    private static String categoryOf(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT), m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("video/") || n.matches(".*\\.(mp4|mkv|webm|avi|mov|3gp|m4v|flv)$")) return "Videos";
        if (m.startsWith("audio/") || n.matches(".*\\.(mp3|m4a|aac|wav|flac|ogg|opus|wma)$")) return "Audio";
        if (m.startsWith("image/") || n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|svg|heic|avif)$")) return "Images";
        if (n.endsWith(".apk") || m.contains("android.package")) return "Apps";
        if (n.matches(".*\\.(zip|rar|7z|tar|gz|bz2|xz)$") || m.contains("zip") || m.contains("compressed")) return "Archives";
        if (n.matches(".*\\.(pdf|doc|docx|xls|xlsx|csv|ppt|pptx|txt|epub|md|json|rtf)$") || m.startsWith("text/") || m.contains("pdf") || m.contains("document") || m.contains("sheet")) return "Documents";
        return "Other";
    }

    private long freeBytes() {
        try {
            StatFs sf = new StatFs(Environment.getExternalStorageDirectory().getPath());
            return sf.getAvailableBytes();
        } catch (Exception e) {
            return -1;
        }
    }

    private void enqueueDownload(String url, String ua, String name, String mime) {
        enqueueDownload(url, ua, name, mime, null);
    }

    private void enqueueDownload(String url, String ua, String name, String mime, String referer) {
        if (dl != null && st.optBoolean("dlSmart", true) && url.startsWith("http")) {
            String ck = CookieManager.getInstance().getCookie(url);
            dl.add(url, ua, referer, ck, name, mime, categoryOf(name, mime), st.optBoolean("dlSort", true), st.optLong("dlEachLimit", 0) * 1024L);
            toast("Downloading " + name + " (pause or limit speed in Downloads)");
            js("window.NB&&NB.event('dl',true)");
            return;
        }
        try {
            DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) rq.setMimeType(mime);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) rq.addRequestHeader("cookie", ck);
            if (ua != null) rq.addRequestHeader("User-Agent", ua);
            if (referer != null && !referer.isEmpty()) rq.addRequestHeader("Referer", referer);
            rq.setTitle(name);
            rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (st.optBoolean("dlWifiOnly", false)) rq.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            String dest = st.optBoolean("dlSort", true) ? "NerdyBrowser/" + categoryOf(name, mime) + "/" + name : name;
            rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, dest);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(rq);
            toast("Downloading " + name);
            js("window.NB&&NB.event('dl',true)");
        } catch (Exception e) {
            toast("Download failed");
        }
    }

    private void retryDownload(long id) {
        if (dl != null && dl.owns(id)) {
            dl.resume(id);
            return;
        }
        if (id < 0) {
            Job j;
            synchronized (jobs) {
                j = jobs.get(id);
            }
            if (j != null && j.redo != null) j.redo.run();
            return;
        }
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()) {
                String uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_URI));
                String title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                String mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                dm.remove(id);
                if (uri != null) enqueueDownload(uri, defaultUa.replace("; wv", "").replace("Version/4.0 ", ""), title == null ? "download" : title, mime);
            }
        } catch (Exception e) {
            toast("Could not retry");
        } finally {
            if (c != null) c.close();
        }
    }

    private String downloadsJson() {
        JSONArray arr = new JSONArray();
        synchronized (jobs) {
            for (Job j : jobs.values()) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", j.id);
                    o.put("title", j.title);
                    o.put("status", j.status);
                    o.put("total", j.total);
                    o.put("got", j.got);
                    o.put("mime", j.mime);
                    o.put("ts", j.ts);
                    o.put("reason", j.status == 16 ? 1000 : 0);
                    arr.put(o);
                } catch (JSONException ignored) {
                }
            }
        }
        if (dl != null) {
            JSONArray sm = dl.toJson();
            for (int i = 0; i < sm.length(); i++) arr.put(sm.opt(i));
        }
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query());
            while (c != null && c.moveToNext() && arr.length() < 100) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                o.put("title", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)));
                o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                o.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                o.put("got", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                o.put("mime", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)));
                o.put("ts", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                o.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                arr.put(o);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    private void openDownload(long id) {
        if (dl != null && dl.owns(id)) {
            Dl.Task t = dl.get(id);
            if (t == null || t.state != Dl.DONE || t.uri.isEmpty()) {
                toast(t != null && t.state != Dl.DONE ? "Still downloading" : "That file is not ready");
                return;
            }
            Uri tu = Uri.parse(t.uri);
            if ("file".equals(tu.getScheme())) {
                toast("Saved in " + tu.getPath());
                return;
            }
            Intent vi = new Intent(Intent.ACTION_VIEW);
            vi.setDataAndType(tu, t.mime.isEmpty() ? "*/*" : t.mime);
            vi.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(vi);
            } catch (Exception e) {
                toast("No app can open this file");
            }
            return;
        }
        if (id < 0) {
            Job j;
            synchronized (jobs) {
                j = jobs.get(id);
            }
            if (j == null || j.uri == null) {
                toast("That file is not ready");
                return;
            }
            if ("file".equals(j.uri.getScheme())) {
                toast("Saved in " + j.uri.getPath());
                return;
            }
            Intent vi = new Intent(Intent.ACTION_VIEW);
            vi.setDataAndType(j.uri, j.mime == null || j.mime.isEmpty() ? "*/*" : j.mime);
            vi.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(vi);
            } catch (Exception e) {
                toast("No app can open this file");
            }
            return;
        }
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Uri u = dm.getUriForDownloadedFile(id);
        String mt = dm.getMimeTypeForDownloadedFile(id);
        if (u == null) {
            toast("That file is not ready");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(u, mt == null ? "*/*" : mt);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("No app can open this file");
        }
    }

    private int dp(int v) {
        return Math.round(v * density);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private static String shorten(String s) {
        if (s == null) return "";
        return s.length() > 90 ? s.substring(0, 88) + "…" : s;
    }

    private static int parseColor(String c, int def) {
        try {
            return Color.parseColor(c);
        } catch (Exception e) {
            return def;
        }
    }

    private String readAsset(String path) {
        try {
            InputStream in = getAssets().open(path);
            byte[] buf = new byte[in.available()];
            int n = 0;
            while (n < buf.length) {
                int r = in.read(buf, n, buf.length - n);
                if (r < 0) break;
                n += r;
            }
            in.close();
            return new String(buf, 0, n, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
