package com.nerdyintruder.nerdybrowser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.net.http.SslError;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * NerdyBrowser shell.
 * - the toolbar, menus, settings, bookmarks and About page are a local web app (assets/www/index.html)
 *   shown in one small WebView called "chrome". Only that WebView can talk to this class.
 * - every tab is its own WebView. Pages from the internet never get any bridge to the app.
 * - PaneLayout puts several tabs on screen at once (split layouts).
 * - Blocker + assets/www/data/inject.js do the ad, tracker, popup and fingerprint blocking.
 */
public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String BASE = "https://" + HOST + "/assets/www/";
    static final String HOME = BASE + "pages/newtab.html";
    static final int REQ_FILE = 5501, REQ_LOCK = 5502, REQ_VPN = 5503;

    // ---------- tiny layout that places panes by fractions, with draggable dividers ----------
    static class PaneLayout extends FrameLayout {
        interface OnChange {
            void changed(float[][] rects);
        }

        static class Div {
            boolean vert;
            float pos, a, b, start;
            View view;
        }

        static final float EPS = 0.004f, MIN = 0.14f;
        float[][] rects = {{0, 0, 1, 1}};
        int gap = 0, handleColor = 0xFF888888;
        float density = 3f;
        OnChange listener;
        final ArrayList<Div> divs = new ArrayList<>();

        class Handle extends View {
            final Div d;
            final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            final RectF rf = new RectF();
            float startRaw;
            float[][] snap;

            Handle(Context c, Div d) {
                super(c);
                this.d = d;
            }

            @Override
            protected void onDraw(Canvas cv) {
                paint.setColor(handleColor);
                paint.setAlpha(210);
                float w = getWidth(), h = getHeight();
                float t = 4 * density, len = 46 * density;
                if (d.vert) {
                    float l = Math.min(h, len);
                    rf.set((w - t) / 2f, (h - l) / 2f, (w + t) / 2f, (h + l) / 2f);
                } else {
                    float l = Math.min(w, len);
                    rf.set((w - l) / 2f, (h - t) / 2f, (w + l) / 2f, (h + t) / 2f);
                }
                cv.drawRoundRect(rf, t, t, paint);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRaw = d.vert ? e.getRawX() : e.getRawY();
                        d.start = d.pos;
                        snap = new float[rects.length][];
                        for (int i = 0; i < rects.length; i++) snap[i] = rects[i].clone();
                        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float cur = d.vert ? e.getRawX() : e.getRawY();
                        float total = d.vert ? PaneLayout.this.getWidth() : PaneLayout.this.getHeight();
                        if (total > 0) drag(d, snap, (cur - startRaw) / total);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (listener != null) {
                            float[][] copy = new float[rects.length][];
                            for (int i = 0; i < rects.length; i++) copy[i] = rects[i].clone();
                            listener.changed(copy);
                        }
                        return true;
                    default:
                        return true;
                }
            }
        }

        PaneLayout(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
        }

        void drag(Div d, float[][] snap, float delta) {
            int ia = d.vert ? 0 : 1, ib = d.vert ? 2 : 3;
            float lo = -1f, hi = 1f;
            for (float[] r : snap) {
                if (Math.abs(r[ia] + r[ib] - d.start) < EPS) lo = Math.max(lo, MIN - r[ib]);
                if (Math.abs(r[ia] - d.start) < EPS) hi = Math.min(hi, r[ib] - MIN);
            }
            delta = Math.max(lo, Math.min(hi, delta));
            if (Math.abs(d.start + delta - 0.5f) < 0.02f && 0.5f - d.start >= lo && 0.5f - d.start <= hi) delta = 0.5f - d.start;
            for (int i = 0; i < snap.length && i < rects.length; i++) {
                float[] r = snap[i];
                if (Math.abs(r[ia] + r[ib] - d.start) < EPS) rects[i][ib] = r[ib] + delta;
                if (Math.abs(r[ia] - d.start) < EPS) {
                    rects[i][ia] = r[ia] + delta;
                    rects[i][ib] = r[ib] - delta;
                }
            }
            d.pos = d.start + delta;
            requestLayout();
        }

        void rebuildDividers() {
            for (Div d : divs) removeView(d.view);
            divs.clear();
            int n = 0;
            for (int i = 0; i < getChildCount(); i++) if (!(getChildAt(i) instanceof Handle)) n++;
            n = Math.min(n, rects.length);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j) continue;
                    float[] p = rects[i], q = rects[j];
                    if (Math.abs(p[0] + p[2] - q[0]) < EPS) {
                        float a = Math.max(p[1], q[1]), b = Math.min(p[1] + p[3], q[1] + q[3]);
                        if (b - a > EPS) addDiv(true, q[0], a, b);
                    }
                    if (Math.abs(p[1] + p[3] - q[1]) < EPS) {
                        float a = Math.max(p[0], q[0]), b = Math.min(p[0] + p[2], q[0] + q[2]);
                        if (b - a > EPS) addDiv(false, q[1], a, b);
                    }
                }
            }
            for (Div d : divs) {
                d.view = new Handle(getContext(), d);
                addView(d.view, new FrameLayout.LayoutParams(-2, -2));
            }
        }

        private void addDiv(boolean vert, float pos, float a, float b) {
            for (Div d : divs) {
                if (d.vert == vert && Math.abs(d.pos - pos) < EPS) {
                    d.a = Math.min(d.a, a);
                    d.b = Math.max(d.b, b);
                    return;
                }
            }
            Div d = new Div();
            d.vert = vert;
            d.pos = pos;
            d.a = a;
            d.b = b;
            divs.add(d);
        }

        void invalidateHandles() {
            for (int i = 0; i < getChildCount(); i++) if (getChildAt(i) instanceof Handle) getChildAt(i).invalidate();
        }

        @Override
        protected void onMeasure(int wms, int hms) {
            int w = MeasureSpec.getSize(wms), h = MeasureSpec.getSize(hms);
            setMeasuredDimension(w, h);
            int hit = Math.round(30 * density);
            int pi = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Handle) {
                    Div d = ((Handle) c).d;
                    int cw = d.vert ? hit : Math.round((d.b - d.a) * w);
                    int ch = d.vert ? Math.round((d.b - d.a) * h) : hit;
                    c.measure(MeasureSpec.makeMeasureSpec(Math.max(0, cw), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(Math.max(0, ch), MeasureSpec.EXACTLY));
                } else {
                    float[] r = rects[Math.min(pi, rects.length - 1)];
                    pi++;
                    int cw = Math.max(0, Math.round(r[2] * w) - gap);
                    int ch = Math.max(0, Math.round(r[3] * h) - gap);
                    c.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
                }
            }
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, h = b - t;
            int pi = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Handle) {
                    Div d = ((Handle) c).d;
                    int x = d.vert ? Math.round(d.pos * w) - c.getMeasuredWidth() / 2 : Math.round(d.a * w);
                    int y = d.vert ? Math.round(d.a * h) : Math.round(d.pos * h) - c.getMeasuredHeight() / 2;
                    c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
                } else {
                    float[] rc = rects[Math.min(pi, rects.length - 1)];
                    pi++;
                    int x = Math.round(rc[0] * w) + gap / 2;
                    int y = Math.round(rc[1] * h) + gap / 2;
                    c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
                }
            }
        }
    }

    // ---------- a browser tab ----------
    class Tab {
        int id;
        WebView web;
        String title = "New tab", url = "";
        int progress = 100, blocked, alerts;
        boolean loading, desktop, js = true, images = true, dark, canBack, canFwd;
        String pendingHttp;
        int refreshSec;
        Runnable refreshTask;
        ScriptHandler script;
        final HashMap<String, Integer> hostCounts = new HashMap<>();

        boolean isHome() {
            return url.startsWith(BASE + "pages/");
        }

        String host() {
            try {
                String h = Uri.parse(url).getHost();
                return h == null ? "" : h;
            } catch (Exception e) {
                return "";
            }
        }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private final HashSet<String> httpOk = new HashSet<>();
    private SharedPreferences vault;
    private JSONObject st = new JSONObject();
    private FrameLayout root;
    private PaneLayout paneLayout;
    private WebView chrome;
    private TextView fab;
    private View lockCover, customView;
    private WebChromeClient.CustomViewCallback customCb;
    private WebViewAssetLoader loader;
    private final Blocker blocker = new Blocker();
    private String injectTpl = "";
    private String defaultUa = "", chromeVer = "120.0.0.0";
    private float density = 3f;
    private int nextId = 1, activePane = 0, barPx, totalBlocked;
    private int[] paneTabs = new int[]{0};
    private float[][] rects = {{0, 0, 1, 1}};
    private int accent = 0xFFF0642F, lineCol = 0xFFE6E6E6;
    private boolean chromeFull = true, barBottom, fullscreen, appDark, ready, statePosted, findOpen, locked;
    private long backAt, stoppedAt;
    private String pendingOpen;
    private ValueCallback<Uri[]> fileCb;
    private Vpn vpn;
    private boolean vpnUp, barsHidden;
    private String vpnMsg = "", curProxy = "";
    private long lastToggle;

    // =====================================================================================
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        vault = getSharedPreferences("nb_vault", MODE_PRIVATE);
        try {
            st = new JSONObject(vault.getString("settings", "{}"));
        } catch (Exception e) {
            st = new JSONObject();
        }
        density = getResources().getDisplayMetrics().density;
        try {
            defaultUa = WebSettings.getDefaultUserAgent(this);
            Matcher m = Pattern.compile("Chrome/([0-9.]+)").matcher(defaultUa);
            if (m.find()) chromeVer = m.group(1);
        } catch (Exception ignored) {
        }
        blocker.load(getAssets());
        blocker.update(st);
        vpn = new Vpn(getApplicationContext(), (up, msg) -> ui.post(() -> {
            vpnUp = up;
            vpnMsg = msg != null ? msg : (up ? "Connected" : "Disconnected");
            pushVpn();
            postState();
        }));
        applyProxy();
        injectTpl = readAsset("www/data/inject.js");
        barBottom = "bottom".equals(st.optString("toolbarPos", "top"));
        locked = st.optBoolean("appLock", false);
        if (st.optBoolean("wipeExit", true)) wipeData();

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        String bg = vault.getString("bg", "#FFF7F0");
        int bgc = parseColor(bg, 0xFFFFF7F0);
        root = new FrameLayout(this);
        root.setBackgroundColor(bgc);
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 28) {
                android.view.DisplayCutout dc = ins.getDisplayCutout();
                cutL = dc == null ? 0 : dc.getSafeInsetLeft();
                cutT = dc == null ? 0 : dc.getSafeInsetTop();
                cutR = dc == null ? 0 : dc.getSafeInsetRight();
                cutB = dc == null ? 0 : dc.getSafeInsetBottom();
            }
            applyRootPadding();
            return ins;
        });

        paneLayout = new PaneLayout(this);
        paneLayout.listener = this::onRectsDragged;
        root.addView(paneLayout, new FrameLayout.LayoutParams(-1, -1));

        chrome = new WebView(this);
        chrome.setBackgroundColor(Color.TRANSPARENT);
        chrome.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = chrome.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        chrome.addJavascriptInterface(new Bridge(), "NBAndroid");
        chrome.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/")) {
                    WebResourceResponse res = loader.shouldInterceptRequest(u);
                    return res != null ? res : blockedResponse();
                }
                return blockedResponse(); // the interface never touches the network
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc)) openNew(u.toString(), false);
                return true;
            }
        });
        chrome.setWebChromeClient(new WebChromeClient());
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(chrome, clp);

        fab = new TextView(this);
        fab.setText("NB");
        fab.setTextColor(Color.WHITE);
        fab.setTextSize(12);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(accent);
        fab.setBackground(gd);
        fab.setVisibility(View.GONE);
        fab.setAlpha(0.6f);
        fab.setOnClickListener(v -> {
            setFullscreen(false);
            js("window.NB&&NB.event('fs',false)");
        });
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END);
        flp.setMargins(0, 0, dp(14), dp(70));
        root.addView(fab, flp);

        applyWindowFlags();
        applySystemUi(bgc, true);
        handleIntent(getIntent());
        chrome.loadUrl(BASE + "index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        String act = i.getAction();
        String text = null;
        if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) text = i.getData().toString();
        else if (Intent.ACTION_SEND.equals(act)) text = i.getStringExtra(Intent.EXTRA_TEXT);
        if (text == null || text.trim().isEmpty()) return;
        if (ready) js("window.NB&&NB.open(" + JSONObject.quote(text.trim()) + ")");
        else pendingOpen = text.trim();
    }

    // =====================================================================================
    //  JavaScript bridge: only the local interface page (chrome) gets this
    // =====================================================================================
    class Bridge {
        @JavascriptInterface
        public String get(String k) {
            return vault.getString(k, "");
        }

        @JavascriptInterface
        public void set(String k, String v) {
            vault.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public void ready() {
            ui.post(() -> {
                if (ready) return;
                ready = true;
                ArrayList<String> urls = new ArrayList<>();
                if (st.optBoolean("restoreTabs", false)) {
                    try {
                        JSONArray a = new JSONArray(vault.getString("session", "[]"));
                        for (int i = 0; i < a.length() && i < 12; i++) urls.add(a.getString(i));
                    } catch (Exception ignored) {
                    }
                }
                if (urls.isEmpty()) urls.add(HOME);
                Tab first = null;
                for (String u : urls) {
                    Tab t = createTab(u);
                    if (first == null) first = t;
                }
                paneTabs = new int[]{first.id};
                rebuildPanes();
                if (st.optBoolean("vpnAuto", false) && vpnConfig().length() > 0 && android.net.VpnService.prepare(MainActivity.this) == null) startVpn();
                if (pendingOpen != null) {
                    String p = pendingOpen;
                    pendingOpen = null;
                    js("window.NB&&NB.open(" + JSONObject.quote(p) + ")");
                }
                postState();
            });
        }

        @JavascriptInterface
        public String state() {
            return stateJson();
        }

        @JavascriptInterface
        public String stats() {
            Tab t = activeTab();
            JSONObject o = new JSONObject();
            try {
                JSONObject hs = new JSONObject();
                if (t != null) for (Map.Entry<String, Integer> e : t.hostCounts.entrySet()) hs.put(e.getKey(), e.getValue());
                o.put("hosts", hs);
                o.put("page", t == null ? 0 : t.blocked);
                o.put("total", totalBlocked);
            o.put("vpn", vpnUp);
            o.put("hidden", barsHidden);
            } catch (JSONException ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void chrome(final String mode, final int h) {
            ui.post(() -> {
                chromeFull = "full".equals(mode);
                if (h > 0) barPx = Math.round(h * density);
                updateMargins();
                if (chromeFull) chrome.requestFocus();
            });
        }

        @JavascriptInterface
        public void settings(final String json) {
            ui.post(() -> {
                try {
                    st = new JSONObject(json);
                } catch (Exception e) {
                    return;
                }
                applyAll();
            });
        }

        @JavascriptInterface
        public void bars(final String bg, final boolean dark, final String acc, final String line) {
            ui.post(() -> {
                appDark = dark;
                accent = parseColor(acc, accent);
                lineCol = parseColor(line, lineCol);
                int c = parseColor(bg, 0xFFFFFFFF);
                vault.edit().putString("bg", bg).apply();
                root.setBackgroundColor(c);
                applySystemUi(c, !dark);
                GradientDrawable gd = new GradientDrawable();
                gd.setShape(GradientDrawable.OVAL);
                gd.setColor(accent);
                fab.setBackground(gd);
                updateBorders();
                for (Tab t : tabs) refreshScript(t);
            });
        }

        @JavascriptInterface
        public void newTab(final String url, final boolean background) {
            ui.post(() -> openNew(url == null || url.isEmpty() ? HOME : url, background));
        }

        @JavascriptInterface
        public void closeTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.closeTab(t);
            });
        }

        @JavascriptInterface
        public void closeAll() {
            ui.post(() -> replaceAllTabs());
        }

        @JavascriptInterface
        public void selectTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) {
                    showInPane(t, activePane);
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void assignPane(final int id, final int pane) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null && pane >= 0 && pane < paneTabs.length) {
                    showInPane(t, pane);
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void setPane(final int pane) {
            ui.post(() -> {
                if (pane >= 0 && pane < paneTabs.length) {
                    activePane = pane;
                    updateBorders();
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void layout(final String rectsJson, final String name) {
            ui.post(() -> {
                try {
                    JSONArray a = new JSONArray(rectsJson);
                    float[][] r = new float[a.length()][4];
                    for (int i = 0; i < a.length(); i++) {
                        JSONArray q = a.getJSONArray(i);
                        for (int k = 0; k < 4; k++) r[i][k] = (float) q.getDouble(k);
                    }
                    if (r.length == 0) return;
                    layoutName = name;
                    setLayoutRects(r);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void go(final String url) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) load(t, url);
            });
        }

        @JavascriptInterface
        public void back() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && t.web.canGoBack()) t.web.goBack();
            });
        }

        @JavascriptInterface
        public void forward() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && t.web.canGoForward()) t.web.goForward();
            });
        }

        @JavascriptInterface
        public void reload() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null) return;
                if (t.loading) t.web.stopLoading();
                else t.web.reload();
            });
        }

        @JavascriptInterface
        public void find(final String q) {
            ui.post(() -> {
                Tab t = activeTab();
                findOpen = true;
                if (t == null) return;
                if (q == null || q.isEmpty()) t.web.clearMatches();
                else t.web.findAllAsync(q);
            });
        }

        @JavascriptInterface
        public void findNext(final boolean fwd) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) t.web.findNext(fwd);
            });
        }

        @JavascriptInterface
        public void findClose() {
            ui.post(() -> {
                findOpen = false;
                Tab t = activeTab();
                if (t != null) t.web.clearMatches();
            });
        }

        @JavascriptInterface
        public void tabFlag(final int id, final String flag, final boolean v) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t == null) return;
                if ("desktop".equals(flag)) {
                    t.desktop = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("js".equals(flag)) {
                    t.js = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("images".equals(flag)) {
                    t.images = v;
                    applySettings(t);
                    t.web.reload();
                } else if ("dark".equals(flag)) {
                    t.dark = v;
                    refreshScript(t);
                    t.web.evaluateJavascript("window.__nbDark&&window.__nbDark(" + v + ")", null);
                }
                postState();
            });
        }

        @JavascriptInterface
        public void runScript(final String code) {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null) t.web.evaluateJavascript(code, null);
            });
        }

        @JavascriptInterface
        public void share() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && !t.isHome()) shareText(t.url);
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            ui.post(() -> MainActivity.this.shareText(text));
        }

        @JavascriptInterface
        public void copy(final String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("NerdyBrowser", text));
                toast("Copied");
            });
        }

        @JavascriptInterface
        public void copyLink() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t != null && !t.isHome()) copy(t.url);
            });
        }

        @JavascriptInterface
        public void fullscreen(final boolean on) {
            ui.post(() -> setFullscreen(on));
        }

        @JavascriptInterface
        public void burn() {
            ui.post(() -> MainActivity.this.burn());
        }

        @JavascriptInterface
        public void clearData(final String what) {
            ui.post(() -> {
                if ("cookies".equals(what)) {
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                } else if ("cache".equals(what)) {
                    for (Tab t : tabs) t.web.clearCache(true);
                }
                toast("Cleared");
            });
        }

        @JavascriptInterface
        public void exit() {
            ui.post(() -> finishAndRemoveTask());
        }

        @JavascriptInterface
        public void toast(final String m) {
            ui.post(() -> MainActivity.this.toast(m));
        }

        @JavascriptInterface
        public void print() {
            ui.post(() -> {
                Tab t = activeTab();
                if (t == null) return;
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    String name = t.title == null || t.title.isEmpty() ? "page" : t.title;
                    pm.print(name, t.web.createPrintDocumentAdapter(name), new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    toast("Can't print this page");
                }
            });
        }

        @JavascriptInterface
        public void swapPanes(final int a, final int b) {
            ui.post(() -> swapPaneTabs(a, b));
        }

        @JavascriptInterface
        public void rotatePanes() {
            ui.post(() -> MainActivity.this.rotatePanes());
        }

        @JavascriptInterface
        public void moveTab(final int id, final int dir) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.moveTab(t, dir);
            });
        }

        @JavascriptInterface
        public void dupTab(final int id) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) {
                    Tab nt = createTab(t.isHome() ? HOME : t.url);
                    nt.desktop = t.desktop;
                    postState();
                }
            });
        }

        @JavascriptInterface
        public void tabRefresh(final int id, final int sec) {
            ui.post(() -> {
                Tab t = tabById(id);
                if (t != null) setRefresh(t, sec);
            });
        }

        @JavascriptInterface
        public void orient(final String mode) {
            ui.post(() -> setOrient(mode));
        }

        @JavascriptInterface
        public String vpnInfo() {
            return vpnJson();
        }

        @JavascriptInterface
        public void vpnSave(final String text) {
            vault.edit().putString("vpncfg", text == null ? "" : text.trim()).apply();
            ui.post(() -> {
                vpnMsg = vpnConfig().isEmpty() ? "" : "Saved on this phone";
                pushVpn();
            });
        }

        @JavascriptInterface
        public void vpnClear() {
            vault.edit().remove("vpncfg").apply();
            ui.post(() -> {
                if (vpnUp) vpn.disconnect();
                vpnMsg = "";
                pushVpn();
            });
        }

        @JavascriptInterface
        public void vpnConnect() {
            ui.post(() -> startVpn());
        }

        @JavascriptInterface
        public void vpnDisconnect() {
            ui.post(() -> {
                vpnMsg = "Disconnecting...";
                pushVpn();
                vpn.disconnect();
            });
        }

        @JavascriptInterface
        public String downloadsList() {
            return downloadsJson();
        }

        @JavascriptInterface
        public void downloadOpen(final long id) {
            ui.post(() -> openDownload(id));
        }

        @JavascriptInterface
        public void downloadRemove(final long id) {
            ui.post(() -> {
                try {
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).remove(id);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void downloads() {
            ui.post(() -> {
                try {
                    startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
                } catch (Exception e) {
                    toast("No downloads app found");
                }
            });
        }
    }

    private String layoutName = "single";

    // =====================================================================================
    //  tabs and panes
    // =====================================================================================
    private Tab tabById(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    private Tab activeTab() {
        if (activePane < 0 || activePane >= paneTabs.length) return tabs.isEmpty() ? null : tabs.get(0);
        return tabById(paneTabs[activePane]);
    }

    private boolean inPane(int id) {
        for (int p : paneTabs) if (p == id) return true;
        return false;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private Tab createTab(String url) {
        final Tab t = new Tab();
        t.id = nextId++;
        t.web = new WebView(this);
        t.web.setBackgroundColor(Color.WHITE);
        t.desktop = st.optBoolean("desktopDefault", false);
        t.js = st.optBoolean("js", true);
        t.images = st.optBoolean("images", true);
        applySettings(t);
        t.web.setWebViewClient(new TabClient(t));
        t.web.setWebChromeClient(new TabChrome(t));
        t.web.setDownloadListener((u, ua, cd, mime, len) -> askDownload(u, ua, cd, mime));
        t.web.setFindListener((idx, cnt, done) -> js("window.NB&&NB.found(" + idx + "," + cnt + ")"));
        t.web.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) focusTab(t);
            return false;
        });
        t.web.setOnLongClickListener(v -> {
            WebView.HitTestResult r = ((WebView) v).getHitTestResult();
            int type = r.getType();
            final String ex = r.getExtra();
            if (ex == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                showLinkMenu(ex, null);
                return true;
            }
            if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                Message m = new Handler(Looper.getMainLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        String u = msg.getData().getString("url");
                        showLinkMenu(u == null ? ex : u, ex);
                    }
                }.obtainMessage();
                ((WebView) v).requestFocusNodeHref(m);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                showLinkMenu(null, ex);
                return true;
            }
            return false;
        });
        t.web.setOnScrollChangeListener((v, sx, sy, ox, oy) -> {
            if (!st.optBoolean("autoHide", true) || activeTab() != t) return;
            if (SystemClock.elapsedRealtime() - lastToggle < 450) return;
            int dy = sy - oy;
            if (sy < 40) setBarsHidden(false);
            else if (dy > 8) setBarsHidden(true);
            else if (dy < -8) setBarsHidden(false);
        });
        tabs.add(t);
        refreshScript(t);
        if (url != null && !url.isEmpty()) load(t, url);
        return t;
    }

    private void destroyTab(Tab t) {
        if (t.refreshTask != null) ui.removeCallbacks(t.refreshTask);
        try {
            if (t.script != null) t.script.remove();
        } catch (Exception ignored) {
        }
        ViewGroup p = (ViewGroup) t.web.getParent();
        if (p != null) p.removeView(t.web);
        t.web.stopLoading();
        t.web.setWebViewClient(new WebViewClient());
        t.web.setWebChromeClient(null);
        t.web.destroy();
    }

    private void openNew(String url, boolean background) {
        Tab nt = createTab(url);
        if (!background) showInPane(nt, activePane);
        else toast("Opened in background");
        postState();
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        tabs.remove(t);
        for (int i = 0; i < paneTabs.length; i++) {
            if (paneTabs[i] != t.id) continue;
            Tab rep = null;
            if (!tabs.isEmpty()) {
                Tab near = tabs.get(Math.min(Math.max(idx, 0), tabs.size() - 1));
                if (!inPane(near.id)) rep = near;
            }
            if (rep == null) for (Tab x : tabs) if (!inPane(x.id)) { rep = x; break; }
            if (rep == null) rep = createTab(HOME);
            paneTabs[i] = rep.id;
        }
        destroyTab(t);
        rebuildPanes();
        postState();
    }

    private void replaceAllTabs() {
        ArrayList<Tab> old = new ArrayList<>(tabs);
        tabs.clear();
        for (int i = 0; i < paneTabs.length; i++) paneTabs[i] = createTab(HOME).id;
        for (Tab o : old) destroyTab(o);
        rebuildPanes();
        postState();
    }

    private void setLayoutRects(float[][] r) {
        rects = r;
        int n = r.length;
        int[] np = new int[n];
        ArrayList<Integer> used = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            np[i] = i < paneTabs.length ? paneTabs[i] : -1;
            if (np[i] >= 0) used.add(np[i]);
        }
        for (int i = 0; i < n; i++) {
            if (np[i] >= 0) continue;
            Tab free = null;
            for (Tab t : tabs) if (!used.contains(t.id)) { free = t; break; }
            if (free == null) free = createTab(HOME);
            np[i] = free.id;
            used.add(free.id);
        }
        paneTabs = np;
        if (activePane >= n) activePane = 0;
        rebuildPanes();
        postState();
    }

    private void showInPane(Tab t, int pane) {
        if (pane < 0 || pane >= paneTabs.length) pane = 0;
        int cur = -1;
        for (int i = 0; i < paneTabs.length; i++) if (paneTabs[i] == t.id) cur = i;
        if (cur == pane) return;
        if (cur >= 0) {
            int tmp = paneTabs[pane];
            paneTabs[pane] = t.id;
            paneTabs[cur] = tmp;
        } else {
            paneTabs[pane] = t.id;
        }
        rebuildPanes();
    }

    private void rebuildPanes() {
        if (paneLayout == null) return;
        paneLayout.removeAllViews();
        boolean multi = rects.length > 1;
        for (int i = 0; i < rects.length && i < paneTabs.length; i++) {
            Tab t = tabById(paneTabs[i]);
            if (t == null) continue;
            FrameLayout wrap = new FrameLayout(this);
            int b = multi ? dp(2) : 0;
            wrap.setPadding(b, b, b, b);
            ViewGroup old = (ViewGroup) t.web.getParent();
            if (old != null) old.removeView(t.web);
            wrap.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
            paneLayout.addView(wrap, new FrameLayout.LayoutParams(-1, -1));
        }
        paneLayout.rects = rects;
        paneLayout.gap = dp(st.optInt("gap", 4));
        paneLayout.rebuildDividers();
        paneLayout.requestLayout();
        updateBorders();
        for (Tab x : tabs) {
            if (inPane(x.id)) x.web.onResume();
            else if (st.optBoolean("sleepTabs", false)) x.web.onPause();
        }
    }

    private void updateBorders() {
        boolean multi = rects.length > 1;
        int pi = 0;
        for (int i = 0; i < paneLayout.getChildCount(); i++) {
            View w = paneLayout.getChildAt(i);
            if (w instanceof PaneLayout.Handle) continue;
            if (!multi) w.setBackgroundColor(Color.TRANSPARENT);
            else w.setBackgroundColor(pi == activePane ? accent : lineCol);
            pi++;
        }
        paneLayout.handleColor = accent;
        paneLayout.invalidateHandles();
    }

    private void focusTab(Tab t) {
        for (int i = 0; i < paneTabs.length; i++) {
            if (paneTabs[i] == t.id && i != activePane) {
                activePane = i;
                updateBorders();
                postState();
                return;
            }
        }
    }

    // =====================================================================================
    //  per-tab WebView settings and privacy
    // =====================================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private void applySettings(Tab t) {
        WebSettings s = t.web.getSettings();
        s.setJavaScriptEnabled(t.js);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);
        s.setSaveFormData(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(st.optBoolean("blockAutoplay", true));
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(Math.max(50, Math.min(250, st.optInt("textZoom", 100))));
        s.setLoadsImagesAutomatically(t.images);
        s.setCacheMode(st.optBoolean("noCache", false) ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(st.optBoolean("safeBrowsing", false));
        s.setUserAgentString(userAgent(t));
        String ck = st.optString("cookies", "first");
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(!"none".equals(ck));
        cm.setAcceptThirdPartyCookies(t.web, "all".equals(ck));
    }

    private String userAgent(Tab t) {
        String custom = st.optString("customUA", "");
        if ("custom".equals(st.optString("ua", "default")) && !custom.isEmpty()) return custom;
        if (t.desktop) {
            return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + chromeVer + " Safari/537.36";
        }
        return defaultUa.replace("; wv", "").replace("Version/4.0 ", "");
    }

    private String scriptFor(Tab t) {
        JSONObject c = new JSONObject();
        try {
            c.put("spoof", st.optBoolean("spoof", true));
            c.put("rtc", st.optBoolean("noWebrtc", true));
            c.put("beacon", st.optBoolean("noBeacon", true));
            c.put("gpc", st.optBoolean("gpc", true));
            c.put("ref", st.optString("referrer", "origin"));
            c.put("cosmetic", st.optBoolean("cosmetic", true));
            c.put("consent", st.optBoolean("consent", true));
            c.put("forceZoom", st.optBoolean("forceZoom", true));
            c.put("yt", st.optBoolean("videoAds", true));
            c.put("dw", t.desktop ? st.optInt("desktopWidth", 1280) : 0);
            String dp = st.optString("darkPages", "off");
            c.put("dark", t.dark || "on".equals(dp) || ("auto".equals(dp) && appDark));
            JSONArray al = st.optJSONArray("siteAllow");
            c.put("allow", al == null ? new JSONArray() : al);
            JSONArray hs = st.optJSONArray("hideSelectors");
            c.put("hide", hs == null ? new JSONArray() : hs);
        } catch (JSONException ignored) {
        }
        return injectTpl.replace("__NB_CFG__", c.toString());
    }

    private void refreshScript(Tab t) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
            if (t.script != null) t.script.remove();
            HashSet<String> rules = new HashSet<>();
            rules.add("*");
            t.script = WebViewCompat.addDocumentStartJavaScript(t.web, scriptFor(t), rules);
        } catch (Exception ignored) {
        }
    }

    private void applyZoom(Tab t) {
        if (t.web == null) return;
        int pct = st.optInt("pageZoom", 100);
        JSONObject sz = st.optJSONObject("siteZoom");
        String h = t.host();
        if (sz != null && !h.isEmpty() && sz.has(h)) pct = sz.optInt(h, pct);
        String v = pct == 100 ? "" : String.format(Locale.US, "%.2f", pct / 100f);
        t.web.evaluateJavascript("try{document.documentElement.style.zoom='" + v + "'}catch(e){}", null);
    }

    private void applyAll() {
        blocker.update(st);
        barBottom = "bottom".equals(st.optString("toolbarPos", "top"));
        applyWindowFlags();
        applyProxy();
        applySystemUi(lastBg, lastLight);
        if (paneLayout != null) {
            paneLayout.gap = dp(st.optInt("gap", 4));
            paneLayout.requestLayout();
        }
        for (Tab t : tabs) {
            applySettings(t);
            refreshScript(t);
            applyZoom(t);
        }
        if (!st.optBoolean("autoHide", true) && barsHidden) setBarsHidden(false);
        updateMargins();
        postState();
    }

    private void applyWindowFlags() {
        if (st.optBoolean("secure", false)) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if (root != null) root.setKeepScreenOn(st.optBoolean("keepScreen", false));
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi(int bg, boolean lightIcons) {
        lastBg = bg;
        lastLight = lightIcons;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        boolean imm = fullscreen || customView != null || st.optBoolean("alwaysFull", true);
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (lightIcons) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (imm) {
            f |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            int want = imm && st.optBoolean("cutout", true)
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            if (lp.layoutInDisplayCutoutMode != want) {
                lp.layoutInDisplayCutoutMode = want;
                getWindow().setAttributes(lp);
            }
        }
        if (root != null) {
            applyRootPadding();
            root.requestApplyInsets();
        }
    }

    private int lastBg = 0xFFFFFFFF;
    private boolean lastLight = true;

    private void setFullscreen(boolean on) {
        fullscreen = on;
        if (on) {
            barsHidden = false;
            chrome.setTranslationY(0f);
        }
        applySystemUi(lastBg, lastLight);
        fab.setVisibility(on ? View.VISIBLE : View.GONE);
        updateMargins();
    }

    private void updateMargins() {
        if (paneLayout == null || chrome == null) return;
        if (chromeFull || fullscreen) {
            barsHidden = false;
            chrome.setTranslationY(0f);
        }
        int bar = (chromeFull || barsHidden) ? 0 : barPx;
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) paneLayout.getLayoutParams();
        if (fullscreen) {
            p.topMargin = 0;
            p.bottomMargin = 0;
        } else if (barBottom) {
            p.topMargin = 0;
            p.bottomMargin = bar;
        } else {
            p.topMargin = bar;
            p.bottomMargin = 0;
        }
        paneLayout.setLayoutParams(p);
        FrameLayout.LayoutParams c = (FrameLayout.LayoutParams) chrome.getLayoutParams();
        c.gravity = barBottom ? Gravity.BOTTOM : Gravity.TOP;
        c.height = chromeFull ? ViewGroup.LayoutParams.MATCH_PARENT : Math.max(barPx, dp(40));
        chrome.setLayoutParams(c);
        chrome.setVisibility(fullscreen && !chromeFull ? View.GONE : View.VISIBLE);
    }

    // =====================================================================================
    //  loading, blocking and error pages
    // =====================================================================================
    private boolean isLocal(String h) {
        if (h == null) return true;
        return h.equals("localhost") || h.startsWith("127.") || h.startsWith("10.") || h.startsWith("192.168.")
                || h.matches("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*") || h.endsWith(".local") || h.indexOf('.') < 0;
    }

    private String prep(Tab t, String url) {
        Uri u = Uri.parse(url);
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (!sc.equals("http") && !sc.equals("https")) return url;
        if (HOST.equals(u.getHost())) return url;
        if (st.optBoolean("stripParams", true)) url = Blocker.clean(url);
        if (sc.equals("http") && st.optBoolean("httpsOnly", true) && !httpOk.contains(u.getHost()) && !isLocal(u.getHost())) {
            t.pendingHttp = url;
            url = "https" + url.substring(4);
        }
        return url;
    }

    private void load(Tab t, String url) {
        if (vpnBlocking() && !url.startsWith(BASE)) {
            showError(t, url, "VPN is required but not connected. Connect it from the menu, or turn off the kill switch in Settings.");
            return;
        }
        String u = prep(t, url);
        HashMap<String, String> h = new HashMap<>();
        if (st.optBoolean("gpc", true)) {
            h.put("Sec-GPC", "1");
            h.put("DNT", "1");
        }
        t.web.loadUrl(u, h);
    }

    private WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    private void countBlock(Tab t, String host) {
        t.blocked++;
        totalBlocked++;
        Integer n = t.hostCounts.get(host);
        t.hostCounts.put(host, n == null ? 1 : n + 1);
        postState();
    }

    private void showError(Tab t, String failUrl, String msg) {
        String safeUrl = TextUtils.htmlEncode(failUrl == null ? "" : failUrl);
        String http = "";
        if (t.pendingHttp != null && failUrl != null && failUrl.startsWith("https")) {
            http = "<a class=\"b2\" href=\"nb-allowhttp" + TextUtils.htmlEncode(t.pendingHttp.substring(4)) + "\">Open over insecure HTTP once</a>";
        }
        String html = "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\">"
                + "<style>body{font-family:sans-serif;background:#fafafa;color:#222;margin:0;padding:28px 22px}"
                + "h1{font-size:22px;margin:0 0 8px}p{color:#555;line-height:1.5}.u{word-break:break-all;font-size:13px;color:#888}"
                + "a{display:inline-block;margin:10px 8px 0 0;padding:11px 18px;border-radius:12px;background:#1f8a70;color:#fff;text-decoration:none;font-weight:600}"
                + "a.b2{background:#e9e9e9;color:#333}.i{font-size:42px}</style></head><body><div class=i>&#128737;</div>"
                + "<h1>This page didn't open</h1><p>" + TextUtils.htmlEncode(msg) + "</p><p class=u>" + safeUrl + "</p>"
                + "<a href=\"" + safeUrl + "\">Try again</a><a class=\"b2\" href=\"" + HOME + "\">New tab page</a>" + http
                + "<p style=\"margin-top:26px;font-size:13px\">NerdyBrowser blocked or could not finish this connection. Nothing was saved.</p></body></html>";
        t.web.loadDataWithBaseURL("https://nerdybrowser.invalid/error", html, "text/html", "utf-8", failUrl);
    }

    private boolean handleNavigation(Tab t, Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        String url = u.toString();
        if (sc.equals("http") || sc.equals("https")) {
            if (HOST.equals(u.getHost())) return false;
            String p = prep(t, url);
            if (!p.equals(url)) {
                load(t, p);
                return true;
            }
            return false;
        }
        if (sc.equals("nb-allowhttp")) {
            String real = "http" + url.substring("nb-allowhttp".length());
            try {
                httpOk.add(Uri.parse(real).getHost());
            } catch (Exception ignored) {
            }
            load(t, real);
            return true;
        }
        if (sc.equals("about") || sc.equals("blob")) return false;
        if (sc.equals("mailto") || sc.equals("tel") || sc.equals("sms") || sc.equals("geo")) {
            confirmExternal(url);
            return true;
        }
        // javascript:, data:, intent:, market: and other app schemes
        if (!sc.equals("javascript") && !sc.equals("data") && !sc.equals("intent") && !st.optBoolean("blockExternal", true)) {
            confirmExternal(url);
            return true;
        }
        t.blocked++;
        totalBlocked++;
        toast("Blocked a link that tried to open another app");
        postState();
        return true;
    }

    private void confirmExternal(final String url) {
        new AlertDialog.Builder(this).setTitle("Open in another app?")
                .setMessage(shorten(url))
                .setPositiveButton("Open", (d, w) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        toast("No app can open this");
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    class TabClient extends WebViewClient {
        final Tab t;

        TabClient(Tab t) {
            this.t = t;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String host = u.getHost();
            if (!HOST.equals(host) && vpnBlocking()) return blockedResponse();
            if (HOST.equals(host)) {
                String path = u.getPath() == null ? "" : u.getPath();
                if (path.startsWith("/assets/www/pages/") || path.startsWith("/assets/www/css/") || path.startsWith("/assets/www/fonts/")) {
                    WebResourceResponse res = loader.shouldInterceptRequest(u);
                    if (res != null) return res;
                }
                return blockedResponse();
            }
            String sc = u.getScheme();
            if (!"http".equals(sc) && !"https".equals(sc)) return null;
            if (r.isForMainFrame()) return null;
            if (blocker.shouldBlock(u, t.host(), r.getRequestHeaders())) {
                countBlock(t, host);
                return blockedResponse();
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) return false;
            return handleNavigation(t, r.getUrl());
        }

        @Override
        public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
            t.url = url == null ? "" : url;
            if (activeTab() == t) setBarsHidden(false);
            t.loading = true;
            t.progress = 8;
            t.blocked = 0;
            t.alerts = 0;
            t.hostCounts.clear();
            v.evaluateJavascript(scriptFor(t), null);
            postState();
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.loading = false;
            t.progress = 100;
            if (url != null) t.url = url;
            t.canBack = v.canGoBack();
            t.canFwd = v.canGoForward();
            applyZoom(t);
            if (url != null && url.startsWith("http") && !HOST.equals(Uri.parse(url).getHost()) && st.optBoolean("saveHistory", false)) {
                js("window.NB&&NB.visit(" + JSONObject.quote(url) + "," + JSONObject.quote(t.title == null ? "" : t.title) + ")");
            }
            postState();
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
            if (url != null) t.url = url;
            t.canBack = v.canGoBack();
            t.canFwd = v.canGoForward();
            postState();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) return;
            String d = e.getDescription() == null ? "" : e.getDescription().toString();
            if (d.contains("UNKNOWN_URL_SCHEME") || d.contains("ERR_ABORTED")) return;
            showError(t, r.getUrl().toString(), d.isEmpty() ? "The connection failed." : d.replace("net::", ""));
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
            h.cancel();
            String eh = Uri.parse(e.getUrl()).getHost();
            if (eh != null && eh.equals(t.host())) {
                showError(t, e.getUrl(), "This site's security certificate can't be trusted, so NerdyBrowser stopped the connection to protect you.");
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            ui.post(() -> {
                toast("A tab crashed and was closed");
                if (tabs.contains(t)) closeTab(t);
            });
            return true;
        }
    }

    class TabChrome extends WebChromeClient {
        final Tab t;

        TabChrome(Tab t) {
            this.t = t;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            t.progress = p;
            t.loading = p < 100;
            postState();
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title == null ? "" : title;
            postState();
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
            String pol = st.optString("popups", "gesture");
            if ("block".equals(pol) || (!gesture && !"allow".equals(pol))) {
                t.blocked++;
                totalBlocked++;
                toast("Popup blocked");
                postState();
                return false;
            }
            Tab nt = createTab(null);
            showInPane(nt, activePane);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
            tr.setWebView(nt.web);
            msg.sendToTarget();
            postState();
            return true;
        }

        @Override
        public void onCloseWindow(WebView w) {
            for (Tab x : new ArrayList<>(tabs)) if (x.web == w) closeTab(x);
        }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        private boolean mute() {
            return st.optBoolean("blockDialogs", false) || ++t.alerts > 3;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String message, final JsResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> r.confirm()).setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String message, final JsResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> r.confirm()).setNegativeButton("Cancel", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String message, String def, final JsPromptResult r) {
            if (mute()) {
                r.cancel();
                return true;
            }
            final EditText in = new EditText(MainActivity.this);
            in.setInputType(InputType.TYPE_CLASS_TEXT);
            in.setText(def);
            new AlertDialog.Builder(MainActivity.this).setMessage(message).setView(in)
                    .setPositiveButton("OK", (d, w) -> r.confirm(in.getText().toString()))
                    .setNegativeButton("Cancel", (d, w) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            cb.invoke(origin, false, false); // location is never shared
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            request.deny(); // camera, microphone and the rest are never shared
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            applySystemUi(lastBg, lastLight);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi(lastBg, lastLight);
    }

    // =====================================================================================
    //  downloads, link menu, share
    // =====================================================================================
    private void askDownload(final String url, final String ua, final String cd, final String mime) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("This kind of download isn't supported yet");
            return;
        }
        new Thread(() -> {
            final String[] info = probeDownload(url, ua, cd, mime);
            ui.post(() -> {
                final String name = info[0], mt = info[1];
                final Runnable go = () -> enqueueDownload(url, ua, name, mt);
                if (st.optBoolean("askDownload", true)) {
                    new AlertDialog.Builder(MainActivity.this).setTitle("Download file?")
                            .setMessage(name + (info[2].isEmpty() ? "" : "\n" + info[2]))
                            .setPositiveButton("Download", (d, w) -> go.run()).setNegativeButton("Cancel", null).show();
                } else go.run();
            });
        }).start();
    }

    private void showLinkMenu(final String link, final String img) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null) {
            labels.add("Open in new tab");
            acts.add(() -> openNew(link, false));
            labels.add("Open in background");
            acts.add(() -> openNew(link, true));
            if (rects.length > 1) {
                labels.add("Open in other pane");
                acts.add(() -> {
                    int other = (activePane + 1) % rects.length;
                    Tab nt = createTab(link);
                    showInPane(nt, other);
                    postState();
                });
            }
            labels.add("Copy link");
            acts.add(() -> ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link", link)));
            labels.add("Share link");
            acts.add(() -> shareText(link));
        }
        if (img != null) {
            labels.add("Open image in new tab");
            acts.add(() -> openNew(img, false));
            labels.add("Copy image address");
            acts.add(() -> ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("image", img)));
            labels.add("Download image");
            acts.add(() -> askDownload(img, userAgent(activeTab()), null, null));
        }
        new AlertDialog.Builder(this).setTitle(shorten(link != null ? link : img))
                .setItems(labels.toArray(new String[0]), (d, i) -> acts.get(i).run()).show();
    }

    private void shareText(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, "Share"));
    }

    // =====================================================================================
    //  burn, wipe, state
    // =====================================================================================
    private void wipeData() {
        try {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
        } catch (Exception ignored) {
        }
    }

    private void burn() {
        wipeData();
        for (Tab t : tabs) {
            t.web.clearCache(true);
            t.web.clearHistory();
            t.web.clearFormData();
        }
        try {
            WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword();
        } catch (Exception ignored) {
        }
        httpOk.clear();
        vault.edit().remove("history").remove("session").apply();
        replaceAllTabs();
        totalBlocked = 0;
        ui.postDelayed(() -> js("window.NB&&NB.afterBurn()"), 350);
    }

    private String stateJson() {
        try {
            JSONObject o = new JSONObject();
            JSONArray ta = new JSONArray();
            for (Tab t : tabs) {
                JSONObject j = new JSONObject();
                j.put("id", t.id);
                j.put("title", t.isHome() ? "New tab" : t.title);
                j.put("url", t.isHome() ? "" : t.url);
                j.put("loading", t.loading);
                j.put("progress", t.progress);
                j.put("blocked", t.blocked);
                j.put("back", t.canBack);
                j.put("fwd", t.canFwd);
                j.put("desktop", t.desktop);
                j.put("js", t.js);
                j.put("images", t.images);
                j.put("dark", t.dark);
                j.put("shield", !blocker.isAllowed(t.host()));
                j.put("refresh", t.refreshSec);
                ta.put(j);
            }
            o.put("tabs", ta);
            JSONArray pa = new JSONArray();
            for (int p : paneTabs) pa.put(p);
            o.put("panes", pa);
            o.put("active", activePane);
            o.put("layout", layoutName);
            o.put("total", totalBlocked);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    private void postState() {
        if (statePosted || chrome == null || !ready) return;
        statePosted = true;
        ui.postDelayed(() -> {
            statePosted = false;
            js("window.NB&&NB.state(" + stateJson() + ")");
        }, 70);
    }

    private void js(String code) {
        if (chrome != null) chrome.evaluateJavascript(code, null);
    }

    // =====================================================================================
    //  lifecycle
    // =====================================================================================
    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (fullscreen) {
            setFullscreen(false);
            js("window.NB&&NB.event('fs',false)");
            return;
        }
        if (chromeFull) {
            js("window.NB&&NB.back()");
            return;
        }
        if (findOpen) {
            js("window.NB&&NB.closeFind()");
            return;
        }
        Tab t = activeTab();
        if (t != null && t.web.canGoBack()) {
            t.web.goBack();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - backAt < 2000) {
            finishAndRemoveTask();
        } else {
            backAt = now;
            toast("Press back again to exit");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else if (req == REQ_VPN) {
            if (res == RESULT_OK) startVpn();
            else {
                vpnMsg = "VPN permission was not given";
                pushVpn();
            }
        } else if (req == REQ_LOCK) {
            if (res == RESULT_OK) unlock();
            else finishAndRemoveTask();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (Tab t : tabs) if (inPane(t.id)) t.web.onResume();
        chrome.onResume();
        if (st.optBoolean("appLock", false)) {
            if (!locked && stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > 30000) locked = true;
            if (locked) showLock();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        for (Tab t : tabs) t.web.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stoppedAt = SystemClock.elapsedRealtime();
        if (st.optBoolean("restoreTabs", false)) {
            JSONArray a = new JSONArray();
            for (Tab t : tabs) {
                if (t.isHome() || t.url.isEmpty()) continue;
                if (t.url.startsWith("http")) a.put(t.url);
            }
            vault.edit().putString("session", a.toString()).apply();
        } else {
            vault.edit().remove("session").apply();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && st.optBoolean("wipeExit", true)) wipeData();
        for (Tab t : new ArrayList<>(tabs)) {
            try {
                destroyTab(t);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private void showLock() {
        if (lockCover == null) {
            TextView tv = new TextView(this);
            tv.setText("NerdyBrowser is locked");
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(0xFF1F2A44);
            tv.setTextSize(18);
            tv.setClickable(true);
            lockCover = tv;
            root.addView(lockCover, new FrameLayout.LayoutParams(-1, -1));
        }
        lockCover.setVisibility(View.VISIBLE);
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km != null && km.isDeviceSecure()) {
            Intent i = km.createConfirmDeviceCredentialIntent("NerdyBrowser", "Unlock to continue");
            if (i != null) {
                try {
                    startActivityForResult(i, REQ_LOCK);
                    return;
                } catch (Exception ignored) {
                }
            }
        }
        unlock(); // phone has no screen lock set, nothing to ask for
    }

    private void unlock() {
        locked = false;
        stoppedAt = 0;
        if (lockCover != null) lockCover.setVisibility(View.GONE);
    }

    // =====================================================================================
    //  small helpers
    // =====================================================================================
    // =====================================================================================
    //  v2: dragging panes, auto-hide bars, VPN, proxy, downloads, refresh, rotation
    // =====================================================================================
    private int cutL, cutT, cutR, cutB;

    private void onRectsDragged(float[][] r) {
        layoutName = "custom";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < r.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(String.format(Locale.US, "[%.4f,%.4f,%.4f,%.4f]", r[i][0], r[i][1], r[i][2], r[i][3]));
        }
        sb.append(']');
        js("window.NB&&NB.rects(" + sb + ")");
    }

    private void setBarsHidden(boolean h) {
        if (chrome == null) return;
        if (h && (!st.optBoolean("autoHide", true) || chromeFull || fullscreen)) return;
        if (h == barsHidden) return;
        barsHidden = h;
        lastToggle = SystemClock.elapsedRealtime();
        updateMargins();
        chrome.animate().translationY(h ? (barBottom ? barPx : -barPx) : 0f).setDuration(170).start();
    }

    private void applyRootPadding() {
        if (root == null) return;
        boolean imm = fullscreen || customView != null || st.optBoolean("alwaysFull", true);
        boolean ext = (fullscreen || customView != null) && st.optBoolean("cutout", true);
        if (!imm || ext) root.setPadding(0, 0, 0, 0);
        else root.setPadding(cutL, cutT, cutR, cutB);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && root != null) applySystemUi(lastBg, lastLight);
    }

    private void applyProxy() {
        String p = st.optString("proxy", "").trim();
        if (p.equals(curProxy)) return;
        curProxy = p;
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                if (!p.isEmpty()) toast("This phone's WebView can't use a proxy");
                return;
            }
            Executor ex = Runnable::run;
            if (p.isEmpty()) {
                ProxyController.getInstance().clearProxyOverride(ex, () -> {
                });
            } else {
                ProxyController.getInstance().setProxyOverride(new ProxyConfig.Builder().addProxyRule(p).build(), ex, () -> {
                });
            }
        } catch (Exception e) {
            toast("That proxy address is not valid");
        }
    }

    // ---------- VPN ----------
    private String vpnConfig() {
        return vault.getString("vpncfg", "");
    }

    private boolean vpnBlocking() {
        return st.optBoolean("vpnKill", false) && vpnConfig().length() > 0 && !vpnUp;
    }

    private void pushVpn() {
        js("window.NB&&NB.vpn(" + vpnJson() + ")");
    }

    private String vpnJson() {
        try {
            JSONObject o = new JSONObject();
            String cfg = vpnConfig();
            o.put("has", cfg.length() > 0);
            o.put("up", vpnUp);
            o.put("msg", vpnMsg);
            String[] inf = Vpn.info(cfg);
            o.put("endpoint", inf[0]);
            o.put("address", inf[1]);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    private void startVpn() {
        String cfg = vpnConfig();
        if (cfg.isEmpty()) {
            vpnMsg = "Paste a WireGuard config first";
            pushVpn();
            return;
        }
        Intent i = android.net.VpnService.prepare(this);
        if (i != null) {
            try {
                startActivityForResult(i, REQ_VPN);
            } catch (Exception e) {
                toast("The VPN permission screen is not available");
            }
            return;
        }
        vpnMsg = "Connecting...";
        pushVpn();
        vpn.connect(cfg);
    }

    // ---------- tabs ----------
    private void swapPaneTabs(int a, int b) {
        if (a < 0 || b < 0 || a >= paneTabs.length || b >= paneTabs.length || a == b) return;
        int t = paneTabs[a];
        paneTabs[a] = paneTabs[b];
        paneTabs[b] = t;
        rebuildPanes();
        postState();
    }

    private void rotatePanes() {
        if (paneTabs.length < 2) return;
        int last = paneTabs[paneTabs.length - 1];
        for (int i = paneTabs.length - 1; i > 0; i--) paneTabs[i] = paneTabs[i - 1];
        paneTabs[0] = last;
        rebuildPanes();
        postState();
    }

    private void moveTab(Tab t, int dir) {
        int i = tabs.indexOf(t), j = i + dir;
        if (i < 0 || j < 0 || j >= tabs.size()) return;
        tabs.remove(i);
        tabs.add(j, t);
        postState();
    }

    private void setRefresh(final Tab t, int sec) {
        t.refreshSec = sec;
        if (t.refreshTask != null) ui.removeCallbacks(t.refreshTask);
        t.refreshTask = null;
        if (sec > 0) {
            t.refreshTask = new Runnable() {
                @Override
                public void run() {
                    if (!tabs.contains(t)) return;
                    if (!t.loading && !t.isHome()) t.web.reload();
                    ui.postDelayed(this, Math.max(2, t.refreshSec) * 1000L);
                }
            };
            ui.postDelayed(t.refreshTask, sec * 1000L);
        }
        postState();
    }

    private void setOrient(String m) {
        int o = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        if ("landscape".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        else if ("portrait".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
        setRequestedOrientation(o);
    }

    // ---------- downloads ----------
    private static String formatSize(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(Locale.US, "%.0f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    /** finds the real file name and type (so videos end in .mp4 and not .bin). Runs off the main thread. */
    private String[] probeDownload(String url, String ua, String cd, String mime) {
        String type = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        String disp = cd;
        String size = "";
        boolean generic = type.isEmpty() || type.equals("application/octet-stream") || type.equals("binary/octet-stream")
                || type.equals("application/force-download") || type.equals("application/download");
        try {
            String qm = Uri.parse(url).getQueryParameter("mime");
            if (generic && qm != null && qm.contains("/")) {
                type = qm.toLowerCase(Locale.ROOT);
                generic = false;
            }
        } catch (Exception ignored) {
        }
        if ((generic || disp == null || disp.isEmpty()) && curProxy.isEmpty() && url.startsWith("http")) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("HEAD");
                c.setConnectTimeout(6000);
                c.setReadTimeout(6000);
                c.setInstanceFollowRedirects(true);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) c.setRequestProperty("Cookie", ck);
                if (c.getResponseCode() < 400) {
                    String ct = c.getContentType();
                    if (ct != null) {
                        ct = ct.split(";")[0].trim().toLowerCase(Locale.ROOT);
                        if (!ct.isEmpty() && !ct.equals("application/octet-stream") && !ct.equals("binary/octet-stream")) {
                            type = ct;
                            generic = false;
                        }
                    }
                    String h = c.getHeaderField("Content-Disposition");
                    if (h != null && !h.isEmpty()) disp = h;
                    long len = c.getContentLengthLong();
                    if (len > 0) size = formatSize(len);
                }
                c.disconnect();
            } catch (Exception ignored) {
            }
        }
        String name = URLUtil.guessFileName(url, disp, generic ? null : type);
        if (!generic) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(type);
            if (ext != null && (name.endsWith(".bin") || name.indexOf('.') < 0)) {
                int dot = name.lastIndexOf('.');
                name = (dot > 0 ? name.substring(0, dot) : name) + "." + ext;
            }
        }
        if (name.endsWith(".bin")) {
            String seg = Uri.parse(url).getLastPathSegment();
            if (seg != null && seg.matches(".*\\.[A-Za-z0-9]{2,5}$")) name = seg;
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return new String[]{name, generic ? "application/octet-stream" : type, size};
    }

    private void enqueueDownload(String url, String ua, String name, String mime) {
        try {
            DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) rq.setMimeType(mime);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) rq.addRequestHeader("cookie", ck);
            if (ua != null) rq.addRequestHeader("User-Agent", ua);
            rq.setTitle(name);
            rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(rq);
            toast("Downloading " + name);
            js("window.NB&&NB.event('dl',true)");
        } catch (Exception e) {
            toast("Download failed");
        }
    }

    private String downloadsJson() {
        JSONArray arr = new JSONArray();
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query());
            while (c != null && c.moveToNext() && arr.length() < 100) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                o.put("title", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)));
                o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                o.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                o.put("got", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                o.put("mime", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)));
                o.put("ts", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                o.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                arr.put(o);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    private void openDownload(long id) {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Uri u = dm.getUriForDownloadedFile(id);
        String mt = dm.getMimeTypeForDownloadedFile(id);
        if (u == null) {
            toast("That file is not ready");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(u, mt == null ? "*/*" : mt);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("No app can open this file");
        }
    }

    private int dp(int v) {
        return Math.round(v * density);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private static String shorten(String s) {
        if (s == null) return "";
        return s.length() > 90 ? s.substring(0, 88) + "…" : s;
    }

    private static int parseColor(String c, int def) {
        try {
            return Color.parseColor(c);
        } catch (Exception e) {
            return def;
        }
    }

    private String readAsset(String path) {
        try {
            InputStream in = getAssets().open(path);
            byte[] buf = new byte[in.available()];
            int n = 0;
            while (n < buf.length) {
                int r = in.read(buf, n, buf.length - n);
                if (r < 0) break;
                n += r;
            }
            in.close();
            return new String(buf, 0, n, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
