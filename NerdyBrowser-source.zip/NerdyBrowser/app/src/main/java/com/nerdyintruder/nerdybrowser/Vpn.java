package com.nerdyintruder.nerdybrowser;

import android.content.Context;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.crypto.KeyPair;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Browser-only VPN using the WireGuard tunnel library.
 * Only NerdyBrowser's own traffic goes through the tunnel (IncludedApplications is set to this app),
 * so the rest of the phone is untouched.
 */
class Vpn {
    interface Listener {
        void onState(boolean up, String message);
    }

    private final Context ctx;
    private final Listener listener;
    private GoBackend backend;
    private volatile boolean up;

    private final Tunnel tunnel = new Tunnel() {
        @Override
        public String getName() {
            return "nerdybrowser";
        }

        @Override
        public void onStateChange(Tunnel.State newState) {
            up = newState == Tunnel.State.UP;
            listener.onState(up, null);
        }
    };

    Vpn(Context c, Listener l) {
        ctx = c;
        listener = l;
    }

    boolean isUp() {
        return up;
    }

    /** makes sure the config only covers this app */
    static String prepare(String text, String pkg) {
        StringBuilder sb = new StringBuilder();
        boolean done = false;
        for (String line : text.split("\\r?\\n")) {
            String t = line.trim().toLowerCase(Locale.ROOT);
            if (t.startsWith("includedapplications") || t.startsWith("excludedapplications")) continue;
            sb.append(line).append('\n');
            if (!done && t.equals("[interface]")) {
                sb.append("IncludedApplications = ").append(pkg).append('\n');
                done = true;
            }
        }
        return sb.toString();
    }

    /** short, key-free summary for the screen: {endpoint, address} */
    static String[] info(String text) {
        String ep = "", ad = "";
        Matcher m = Pattern.compile("(?im)^\\s*Endpoint\\s*=\\s*(.+?)\\s*$").matcher(text);
        if (m.find()) ep = m.group(1);
        m = Pattern.compile("(?im)^\\s*Address\\s*=\\s*(.+?)\\s*$").matcher(text);
        if (m.find()) ad = m.group(1);
        return new String[]{ep, ad};
    }

    void connect(final String text) {
        new Thread(() -> {
            try {
                if (backend == null) backend = new GoBackend(ctx);
                Config cfg = Config.parse(new ByteArrayInputStream(prepare(text, ctx.getPackageName()).getBytes("UTF-8")));
                backend.setState(tunnel, Tunnel.State.UP, cfg);
            } catch (Exception e) {
                up = false;
                String m = e.getMessage();
                listener.onState(false, "Could not connect: " + (m == null ? e.toString() : m));
            }
        }).start();
    }

    void disconnect() {
        new Thread(() -> {
            try {
                if (backend == null) backend = new GoBackend(ctx);
                backend.setState(tunnel, Tunnel.State.DOWN, null);
            } catch (Exception e) {
                String m = e.getMessage();
                listener.onState(up, "Could not disconnect: " + (m == null ? e.toString() : m));
            }
        }).start();
    }


    /**
     * Builds a ready client config for the person's OWN WireGuard server. The key pair is made on this phone.
     * Returns {cfg, pub, addr, needsKey, peer}: "peer" is the block to add on the server.
     */
    static JSONObject makeOwn(String endpoint, String serverKey, String clientAddr) throws Exception {
        endpoint = endpoint == null ? "" : endpoint.trim();
        if (endpoint.isEmpty()) throw new Exception("Type the server address first, like 203.0.113.5:51820");
        if (!endpoint.contains(":")) endpoint = endpoint + ":51820";
        String addr = clientAddr == null || clientAddr.trim().isEmpty() ? "10.66.66.2/32" : clientAddr.trim();
        if (!addr.matches("^[0-9a-fA-F:.]+/[0-9]{1,3}$")) throw new Exception("The phone address should look like 10.66.66.2/32");
        String sk = serverKey == null ? "" : serverKey.trim();
        boolean needs = sk.isEmpty();
        if (!needs && !sk.matches("^[A-Za-z0-9+/]{43}=$")) throw new Exception("That server public key does not look right (44 characters ending in =)");
        KeyPair kp = new KeyPair();
        String priv = kp.getPrivateKey().toBase64();
        String pub = kp.getPublicKey().toBase64();
        StringBuilder sb = new StringBuilder();
        sb.append("[Interface]\nPrivateKey = ").append(priv).append('\n');
        sb.append("Address = ").append(addr).append("\nDNS = 1.1.1.1, 1.0.0.1\nMTU = 1380\n\n");
        sb.append("[Peer]\nPublicKey = ").append(needs ? "PASTE_SERVER_PUBLIC_KEY_HERE" : sk).append("\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = ").append(endpoint).append("\nPersistentKeepalive = 25\n");
        JSONObject o = new JSONObject();
        o.put("cfg", sb.toString());
        o.put("pub", pub);
        o.put("addr", addr);
        o.put("needsKey", needs);
        o.put("peer", "[Peer]\nPublicKey = " + pub + "\nAllowedIPs = " + addr.replaceAll("/[0-9]+$", "/32") + "\n");
        return o;
    }

    /**
     * Free, no-account tunnel: registers this phone with Cloudflare WARP (the same free service as the 1.1.1.1 app)
     * and returns a ready WireGuard config. Needs internet once. May stop working if Cloudflare changes the service.
     */
    static String registerWarp() throws Exception {
        KeyPair kp = new KeyPair();
        String priv = kp.getPrivateKey().toBase64();
        String pub = kp.getPublicKey().toBase64();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        JSONObject body = new JSONObject();
        body.put("key", pub);
        body.put("install_id", "");
        body.put("fcm_token", "");
        body.put("tos", f.format(new Date()));
        body.put("model", "Android");
        body.put("type", "Android");
        body.put("locale", "en_US");
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.cloudflareclient.com/v0a2158/reg").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", "okhttp/3.12.1");
        c.setRequestProperty("CF-Client-Version", "a-6.3-2223");
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        if (code >= 300) throw new Exception("Cloudflare answered " + code);
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        c.disconnect();
        JSONObject cfg = new JSONObject(bo.toString("UTF-8")).getJSONObject("config");
        JSONObject peer = cfg.getJSONArray("peers").getJSONObject(0);
        String peerKey = peer.getString("public_key");
        String host = peer.getJSONObject("endpoint").optString("host", "engage.cloudflareclient.com:2408");
        JSONObject addr = cfg.getJSONObject("interface").getJSONObject("addresses");
        String v4 = addr.getString("v4");
        String v6 = addr.optString("v6", "");
        StringBuilder sb = new StringBuilder();
        sb.append("[Interface]\nPrivateKey = ").append(priv).append('\n');
        sb.append("Address = ").append(v4).append("/32");
        if (!v6.isEmpty()) sb.append(", ").append(v6).append("/128");
        sb.append("\nDNS = 1.1.1.1, 1.0.0.1\nMTU = 1280\n\n");
        sb.append("[Peer]\nPublicKey = ").append(peerKey).append("\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = ").append(host).append('\n');
        return sb.toString();
    }
}
