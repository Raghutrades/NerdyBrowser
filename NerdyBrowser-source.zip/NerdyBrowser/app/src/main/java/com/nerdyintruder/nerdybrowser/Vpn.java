package com.nerdyintruder.nerdybrowser;

import android.content.Context;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Browser-only VPN using the WireGuard tunnel library.
 * Only NerdyBrowser's own traffic goes through the tunnel (IncludedApplications is set to this app),
 * so the rest of the phone is untouched.
 */
class Vpn {
    interface Listener {
        void onState(boolean up, String message);
    }

    private final Context ctx;
    private final Listener listener;
    private GoBackend backend;
    private volatile boolean up;

    private final Tunnel tunnel = new Tunnel() {
        @Override
        public String getName() {
            return "nerdybrowser";
        }

        @Override
        public void onStateChange(Tunnel.State newState) {
            up = newState == Tunnel.State.UP;
            listener.onState(up, null);
        }
    };

    Vpn(Context c, Listener l) {
        ctx = c;
        listener = l;
    }

    boolean isUp() {
        return up;
    }

    /** makes sure the config only covers this app */
    static String prepare(String text, String pkg) {
        StringBuilder sb = new StringBuilder();
        boolean done = false;
        for (String line : text.split("\\r?\\n")) {
            String t = line.trim().toLowerCase(Locale.ROOT);
            if (t.startsWith("includedapplications") || t.startsWith("excludedapplications")) continue;
            sb.append(line).append('\n');
            if (!done && t.equals("[interface]")) {
                sb.append("IncludedApplications = ").append(pkg).append('\n');
                done = true;
            }
        }
        return sb.toString();
    }

    /** short, key-free summary for the screen: {endpoint, address} */
    static String[] info(String text) {
        String ep = "", ad = "";
        Matcher m = Pattern.compile("(?im)^\\s*Endpoint\\s*=\\s*(.+?)\\s*$").matcher(text);
        if (m.find()) ep = m.group(1);
        m = Pattern.compile("(?im)^\\s*Address\\s*=\\s*(.+?)\\s*$").matcher(text);
        if (m.find()) ad = m.group(1);
        return new String[]{ep, ad};
    }

    void connect(final String text) {
        new Thread(() -> {
            try {
                if (backend == null) backend = new GoBackend(ctx);
                Config cfg = Config.parse(new ByteArrayInputStream(prepare(text, ctx.getPackageName()).getBytes("UTF-8")));
                backend.setState(tunnel, Tunnel.State.UP, cfg);
            } catch (Exception e) {
                up = false;
                String m = e.getMessage();
                listener.onState(false, "Could not connect: " + (m == null ? e.toString() : m));
            }
        }).start();
    }

    void disconnect() {
        new Thread(() -> {
            try {
                if (backend == null) backend = new GoBackend(ctx);
                backend.setState(tunnel, Tunnel.State.DOWN, null);
            } catch (Exception e) {
                String m = e.getMessage();
                listener.onState(up, "Could not disconnect: " + (m == null ? e.toString() : m));
            }
        }).start();
    }
}
