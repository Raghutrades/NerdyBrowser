package com.nerdyintruder.nerdybrowser;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * The owl on the home screen. Android does not let an app icon in the app drawer move, but a widget can,
 * so this one plays the owl's routine (eye rolls, wink, hop...) and opens NerdyBrowser when tapped.
 */
public class OwlWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_owl);
            Intent i = new Intent(c, MainActivity.class);
            i.setAction(Intent.ACTION_MAIN);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.owl_root, pi);
            m.updateAppWidget(id, rv);
        }
    }
}
