package com.nerdyintruder.nerdybrowser;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;

/**
 * Feeds a downloaded (or still downloading) file to the Downloads screen, so it can show a
 * picture, play a short video glimpse or play audio. Supports byte ranges, which videos need
 * for seeking. A file that is only half downloaded is served as far as it has got.
 */
final class Preview {
    static final class Src {
        File file;
        Uri uri;
        String mime = "application/octet-stream";
        boolean partial;
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    static WebResourceResponse serve(Context c, Src s, Map<String, String> req) {
        ParcelFileDescriptor pfd = null;
        try {
            if (s.file != null) {
                if (!s.file.exists()) return notFound();
                pfd = ParcelFileDescriptor.open(s.file, ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (s.uri != null) {
                if ("file".equals(s.uri.getScheme())) {
                    File f = new File(s.uri.getPath());
                    if (!f.exists()) return notFound();
                    pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
                } else {
                    pfd = c.getContentResolver().openFileDescriptor(s.uri, "r");
                }
            }
            if (pfd == null) return notFound();
            final long size = pfd.getStatSize();
            if (size <= 0) {
                pfd.close();
                return notFound();
            }
            long start = 0, end = size - 1;
            boolean ranged = false;
            String rg = null;
            if (req != null) {
                for (Map.Entry<String, String> e : req.entrySet()) {
                    if ("range".equalsIgnoreCase(e.getKey())) rg = e.getValue();
                }
            }
            if (rg != null && rg.startsWith("bytes=")) {
                try {
                    String r = rg.substring(6).split(",")[0].trim();
                    int dash = r.indexOf('-');
                    String a = r.substring(0, dash), b = r.substring(dash + 1);
                    if (a.isEmpty()) {
                        long n = Long.parseLong(b);
                        start = Math.max(0, size - n);
                    } else {
                        start = Long.parseLong(a);
                        if (!b.isEmpty()) end = Math.min(size - 1, Long.parseLong(b));
                    }
                    ranged = true;
                } catch (Exception ignored) {
                    start = 0;
                    end = size - 1;
                }
            }
            if (start > end || start >= size) {
                pfd.close();
                Map<String, String> h = new HashMap<>();
                h.put("Content-Range", "bytes */" + size);
                return new WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", h,
                        new ByteArrayInputStream(new byte[0]));
            }
            final long len = end - start + 1;
            final ParcelFileDescriptor fp = pfd;
            final FileInputStream fis = new FileInputStream(fp.getFileDescriptor());
            final FileChannel ch = fis.getChannel();
            ch.position(start);
            InputStream body = new InputStream() {
                long left = len;

                @Override
                public int read() throws IOException {
                    byte[] one = new byte[1];
                    int n = read(one, 0, 1);
                    return n < 0 ? -1 : (one[0] & 0xff);
                }

                @Override
                public int read(byte[] b, int off, int l) throws IOException {
                    if (left <= 0) return -1;
                    int n = fis.read(b, off, (int) Math.min(l, left));
                    if (n > 0) left -= n;
                    return n;
                }

                @Override
                public void close() throws IOException {
                    try {
                        fis.close();
                    } finally {
                        fp.close();
                    }
                }
            };
            Map<String, String> h = new HashMap<>();
            h.put("Accept-Ranges", "bytes");
            h.put("Content-Length", String.valueOf(len));
            h.put("Cache-Control", s.partial ? "no-store" : "private, max-age=300");
            if (ranged) h.put("Content-Range", "bytes " + start + "-" + end + "/" + size);
            return new WebResourceResponse(s.mime, null, ranged ? 206 : 200, ranged ? "Partial Content" : "OK", h, body);
        } catch (Exception e) {
            if (pfd != null) {
                try {
                    pfd.close();
                } catch (IOException ignored) {
                }
            }
            return notFound();
        }
    }
}
