package com.nerdyintruder.nerdybrowser;

import android.content.res.AssetManager;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** The built-in ad / tracker / popup blocker. Pure logic, no network, no logging. */
class Blocker {
    private final HashSet<String> hosts = new HashSet<>();
    volatile HashSet<String> custom = new HashSet<>();
    volatile HashSet<String> allow = new HashSet<>();
    volatile int level = 1; // 0 off, 1 standard, 2 strict, 3 ultra
    volatile boolean ytAds = true;
    volatile boolean signin = true;
    volatile boolean appCompat = true;
    volatile HashSet<String> compatUser = new HashSet<>();

    /** Web apps (music, video, chat) that break when every privacy tweak is on. They still get ad/tracker blocking. */
    static final String[] COMPAT = {"spotify.com", "scdn.co", "spotifycdn.com", "netflix.com", "primevideo.com", "hotstar.com", "jiohotstar.com",
            "jiocinema.com", "sonyliv.com", "zee5.com", "soundcloud.com", "deezer.com", "tidal.com", "jiosaavn.com", "saavn.com", "gaana.com", "wynk.in",
            "music.youtube.com", "music.apple.com", "tv.apple.com", "twitch.tv", "discord.com", "whatsapp.com", "web.telegram.org", "meet.google.com",
            "zoom.us", "pinterest.com", "teams.microsoft.com", "disneyplus.com", "hbomax.com", "max.com", "crunchyroll.com", "vimeo.com", "dailymotion.com"};

    /** Sites that only offer their web player on a desktop layout. */
    static final String[] AUTO_DESKTOP = {"web.whatsapp.com"};

    /** Sites whose player only works with the phone identity (Spotify plays on the mobile layout, not the desktop one). */
    static final String[] FORCE_MOBILE = {"spotify.com"};

    private static final String[] SIGNIN = {"accounts.google.com", "accounts.youtube.com", "myaccount.google.com", "login.microsoftonline.com",
            "login.live.com", "account.live.com", "appleid.apple.com", "idmsa.apple.com", "signin.aws.amazon.com", "login.yahoo.com"};

    static boolean isSignin(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        for (String s : SIGNIN) if (h.equals(s)) return true;
        return false;
    }

    private static final String[] YT_PATHS = {"/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_", "/youtubei/v1/player/ad_break", "/api/stats/qoe?adformat"};

    private static final String[] PATTERNS = {
            "/pagead/", "/adserver/", "/adsbygoogle", "/analytics.js", "/gtag/js", "/gtm.js", "/fbevents.js",
            "/ga.js", "/collect?v=1", "/pixel.gif", "/ads.js", "/prebid", "/adframe", "/ad_frame", "/banner_ads",
            "/tracking.js", "/tracker.js", "/beacon.js", "/track/pageview", "/__utm.gif"
    };

    private static final String[] TRACK_PARAMS = {
            "fbclid", "gclid", "gclsrc", "dclid", "msclkid", "mc_eid", "mc_cid", "igshid", "yclid", "twclid",
            "_hsenc", "_hsmi", "vero_id", "vero_conv", "ref_src", "ref_url", "s_cid", "wt.mc_id", "oly_enc_id",
            "oly_anon_id", "mkt_tok", "ttclid", "li_fat_id", "_openstat", "rb_clickid", "wickedid", "soc_src", "soc_trk"
    };

    void load(AssetManager am) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(am.open("www/data/hosts.txt"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim().toLowerCase(Locale.ROOT);
                if (line.isEmpty() || line.startsWith("#")) continue;
                hosts.add(line);
            }
            r.close();
        } catch (Exception ignored) {
        }
    }

    void update(JSONObject st) {
        String lv = st.optString("shield", "standard");
        level = "off".equals(lv) ? 0 : "strict".equals(lv) ? 2 : "ultra".equals(lv) ? 3 : 1;
        ytAds = st.optBoolean("videoAds", true);
        signin = st.optBoolean("signinCompat", true);
        appCompat = st.optBoolean("appCompat", true);
        compatUser = toSet(st.optJSONArray("compatSites"));
        custom = toSet(st.optJSONArray("customBlock"));
        allow = toSet(st.optJSONArray("siteAllow"));
    }

    private static HashSet<String> toSet(JSONArray a) {
        HashSet<String> s = new HashSet<>();
        if (a == null) return s;
        for (int i = 0; i < a.length(); i++) {
            String v = a.optString(i, "").trim().toLowerCase(Locale.ROOT);
            if (!v.isEmpty()) s.add(v);
        }
        return s;
    }

    boolean isAllowed(String pageHost) {
        if (pageHost == null) return false;
        if (signin && isSignin(pageHost)) return true;
        String h = pageHost.toLowerCase(Locale.ROOT);
        Set<String> a = allow;
        while (true) {
            if (a.contains(h)) return true;
            int i = h.indexOf('.');
            if (i < 0) return false;
            h = h.substring(i + 1);
        }
    }

    private static boolean suffixIn(String host, String[] list, Set<String> extra) {
        String h = host.toLowerCase(Locale.ROOT);
        while (true) {
            if (extra != null && extra.contains(h)) return true;
            if (list != null) for (String s : list) if (s.equals(h)) return true;
            int i = h.indexOf('.');
            if (i < 0) return false;
            h = h.substring(i + 1);
        }
    }

    /** true for music / video / chat web apps: ads and trackers are still blocked, but nothing that breaks playback or login */
    boolean isCompat(String pageHost) {
        if (!appCompat || pageHost == null || pageHost.isEmpty()) return false;
        return suffixIn(pageHost, COMPAT, compatUser);
    }

    boolean wantsDesktop(String host) {
        if (!appCompat || host == null) return false;
        return suffixIn(host, AUTO_DESKTOP, null);
    }

    boolean wantsMobile(String host) {
        if (!appCompat || host == null) return false;
        return suffixIn(host, FORCE_MOBILE, null);
    }

    /** built-in + your own list, for the page script */
    JSONArray compatArray() {
        JSONArray a = new JSONArray();
        if (!appCompat) return a;
        for (String s : COMPAT) a.put(s);
        for (String s : compatUser) a.put(s);
        return a;
    }

    boolean hostBlocked(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        Set<String> c = custom;
        while (h.indexOf('.') > 0) {
            if (hosts.contains(h) || c.contains(h)) return true;
            h = h.substring(h.indexOf('.') + 1);
        }
        return false;
    }

    static String site(String host) {
        if (host == null) return "";
        String[] p = host.toLowerCase(Locale.ROOT).split("\\.");
        int n = p.length;
        if (n <= 2) return host.toLowerCase(Locale.ROOT);
        String sl = p[n - 2];
        boolean cc = p[n - 1].length() == 2 && (sl.equals("co") || sl.equals("com") || sl.equals("org")
                || sl.equals("net") || sl.equals("gov") || sl.equals("ac") || sl.equals("edu"));
        int keep = cc ? 3 : 2;
        StringBuilder sb = new StringBuilder();
        for (int i = n - keep; i < n; i++) {
            if (sb.length() > 0) sb.append('.');
            sb.append(p[i]);
        }
        return sb.toString();
    }

    /** true when this sub-resource request should be stopped */
    boolean shouldBlock(Uri u, String pageHost, Map<String, String> headers) {
        int lv = level;
        if (lv == 0) return false;
        String host = u.getHost();
        if (host == null) return false;
        if (isAllowed(pageHost)) return false;
        // web apps keep working: only the ad / tracker domain list (and YouTube ad paths) apply, never the script / frame rules
        if (isCompat(pageHost) && lv > 1) lv = 1;
        if (hostBlocked(host)) return true;
        if (ytAds) {
            String hl = host.toLowerCase(Locale.ROOT);
            if (hl.endsWith("youtube.com") || hl.endsWith("youtube-nocookie.com")) {
                String s = u.toString();
                for (String p : YT_PATHS) if (s.contains(p)) return true;
            }
        }
        boolean third = pageHost != null && !site(host).equals(site(pageHost));
        if (lv >= 2 && third) {
            String s = u.toString().toLowerCase(Locale.ROOT);
            for (String p : PATTERNS) if (s.contains(p)) return true;
        }
        if (lv >= 3 && third) {
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase(Locale.ROOT);
            if (path.endsWith(".js") || path.endsWith(".mjs")) return true;
            String acc = headers == null ? null : headers.get("Accept");
            if (acc != null && acc.contains("text/html")) return true;
        }
        return false;
    }

    private static boolean isTrackParam(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        if (l.startsWith("utm_")) return true;
        for (String t : TRACK_PARAMS) if (t.equals(l)) return true;
        return false;
    }

    /** removes utm_*, fbclid, gclid and friends from a link */
    static String clean(String url) {
        try {
            Uri u = Uri.parse(url);
            if (u.isOpaque() || u.getQuery() == null) return url;
            Set<String> names = u.getQueryParameterNames();
            boolean any = false;
            for (String n : names) if (isTrackParam(n)) { any = true; break; }
            if (!any) return url;
            Uri.Builder b = u.buildUpon().clearQuery();
            for (String n : names) {
                if (isTrackParam(n)) continue;
                for (String v : u.getQueryParameters(n)) b.appendQueryParameter(n, v);
            }
            return b.build().toString();
        } catch (Exception e) {
            return url;
        }
    }
}
