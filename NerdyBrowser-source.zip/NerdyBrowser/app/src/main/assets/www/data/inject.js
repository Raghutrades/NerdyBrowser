/* NerdyBrowser page shield. Runs at the start of every page the shield covers.
   __NB_CFG__ is replaced by the app with the current settings. */
(function () {
  try {
    if (window.__nbd) return;
    var CFG = __NB_CFG__;
    var h = location.hostname;
    if (h === 'appassets.androidplatform.net') return;
    window.__nbd = 1;
    var A = CFG.allow || [];
    var allowed = false;
    for (var i = 0; i < A.length; i++) { if (h === A[i] || h.endsWith('.' + A[i])) allowed = true; }

    var css = '';
    var addCss = function (c) { css += c; };

    /* ---- dark page (works even on sites that are shield-allowed) ---- */
    window.__nbDark = function (on) {
      var el = document.getElementById('nb-dark');
      if (!on) { if (el) el.remove(); return; }
      if (el) return;
      el = document.createElement('style'); el.id = 'nb-dark';
      el.textContent = 'html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}' +
        'img,picture,video,canvas,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';
      (document.head || document.documentElement).appendChild(el);
    };
    if (CFG.dark) window.__nbDark(true);

    /* ---- desktop mode: pretend the screen is wide so the real desktop layout is used ---- */
    if (CFG.dw) {
      var setVp = function () {
        var v = document.querySelector('meta[name=viewport]');
        if (!v) { v = document.createElement('meta'); v.name = 'viewport'; (document.head || document.documentElement).appendChild(v); }
        v.setAttribute('content', 'width=' + CFG.dw + ', initial-scale=1');
      };
      setVp();
      document.addEventListener('DOMContentLoaded', setVp);
    }

    if (allowed) return;

    /* ---- privacy: fingerprint, WebRTC, beacons, GPC, referrer ---- */
    var def = function (o, p, v) { try { Object.defineProperty(o, p, { get: function () { return v; }, configurable: true }); } catch (e) { } };
    if (CFG.spoof) {
      def(Navigator.prototype, 'hardwareConcurrency', 4);
      def(Navigator.prototype, 'deviceMemory', 4);
      def(Navigator.prototype, 'languages', Object.freeze(['en-US', 'en']));
      def(Navigator.prototype, 'language', 'en-US');
      def(Navigator.prototype, 'connection', undefined);
      def(Navigator.prototype, 'getBattery', undefined);
      try {
        var gid = CanvasRenderingContext2D.prototype.getImageData;
        CanvasRenderingContext2D.prototype.getImageData = function () {
          var im = gid.apply(this, arguments);
          for (var k = 0; k < im.data.length; k += 4 * 131) { im.data[k] ^= 1; }
          return im;
        };
        var tdu = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function () {
          try {
            var w = this.width, hh = this.height;
            if (w && hh && w * hh < 4e6) {
              var c = document.createElement('canvas'); c.width = w; c.height = hh;
              var x = c.getContext('2d'); x.drawImage(this, 0, 0);
              var im = gid.call(x, 0, 0, Math.min(w, 16), 1); im.data[0] ^= 1; x.putImageData(im, 0, 0);
              return tdu.apply(c, arguments);
            }
          } catch (e) { }
          return tdu.apply(this, arguments);
        };
      } catch (e) { }
    }
    if (CFG.rtc) {
      ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel', 'RTCSessionDescription'].forEach(function (n) {
        try { window[n] = undefined; } catch (e) { }
      });
    }
    /* push-notification spam: sites can ask, but the answer is always no */
    try {
      if (window.Notification) {
        Notification.requestPermission = function (cb) { if (typeof cb === 'function') cb('denied'); return Promise.resolve('denied'); };
        Object.defineProperty(Notification, 'permission', { get: function () { return 'denied'; }, configurable: true });
      }
    } catch (e) { }
    if (CFG.beacon) { try { navigator.sendBeacon = function () { return true; }; } catch (e) { } }
    if (CFG.gpc) { def(Navigator.prototype, 'globalPrivacyControl', true); def(Navigator.prototype, 'doNotTrack', '1'); }
    if (CFG.ref && CFG.ref !== 'default') {
      var m = document.createElement('meta'); m.name = 'referrer';
      m.content = CFG.ref === 'none' ? 'no-referrer' : 'strict-origin';
      (document.head || document.documentElement).appendChild(m);
    }

    /* ---- zoom on every page ---- */
    if (CFG.forceZoom) {
      var fixVp = function () {
        var v = document.querySelector('meta[name=viewport]');
        if (v) v.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=10, user-scalable=yes');
      };
      document.addEventListener('DOMContentLoaded', fixVp);
    }

    /* ---- cosmetic filter: ad frames and slots ---- */
    if (CFG.cosmetic) {
      addCss('ins.adsbygoogle,iframe[src*="doubleclick.net"],iframe[src*="googlesyndication"],iframe[src*="adnxs.com"],' +
        'iframe[src*="taboola"],iframe[src*="outbrain"],div[id^="div-gpt-ad"],div[id^="google_ads_"],[id^="google_ads_iframe"],' +
        '[class*="adsbygoogle"],div[data-ad-slot],div[data-google-query-id],a[href*="doubleclick.net/"],' +
        '.ad-banner,.ad-slot,.adslot,.ad-container,.ad-wrapper,.advert,.advertisement,.sponsored-post,.sponsored-ad,' +
        '#taboola-below-article,[id^="taboola-"],.OUTBRAIN,[data-widget-id^="AR_"],.mgid,div[id^="mgid"],.adthrive-ad,' +
        '.pub_300x250,.pub_728x90,.textAd,.text-ad,.text_ad{display:none!important}');
    }
    /* ---- consent / cookie banners and newsletter nags ---- */
    var CMP = '#onetrust-consent-sdk,#onetrust-banner-sdk,.onetrust-pc-dark-filter,.cc-window,.cc-banner,#cookiebanner,#cookie-banner,' +
      '.cookie-banner,#cookie-notice,.cookie-notice,#cookieNotice,#CybotCookiebotDialog,#CybotCookiebotDialogBodyUnderlay,#cookie-law-info-bar,' +
      '.truste_box_overlay,.truste_overlay,[id^="sp_message_container"],.qc-cmp2-container,#didomi-host,.fc-consent-root,#usercentrics-root,' +
      '.osano-cm-window,.osano-cm-dialog,#gdpr-cookie-message,.gdpr-banner,#cmpbox,#cmpwrapper,.evidon-banner,#truste-consent-track,' +
      '.cky-consent-container,#cookie-consent,.cookie-consent,.cookieconsent,#cookieconsent,.cookie-popup,.js-cookie-consent';
    if (CFG.consent) {
      addCss(CMP + '{display:none!important}body.nb-cmp,html.nb-cmp{overflow:auto!important;position:static!important}');
      var tick = 0;
      var unlock = function () {
        try {
          if (document.querySelector(CMP)) { document.documentElement.classList.add('nb-cmp'); if (document.body) document.body.classList.add('nb-cmp'); }
        } catch (e) { }
        if (++tick < 12) setTimeout(unlock, 700);
      };
      document.addEventListener('DOMContentLoaded', unlock);
    }


    /* ---- your own hide rules ---- */
    if (CFG.hide && CFG.hide.length) {
      try {
        var rules = [];
        CFG.hide.forEach(function (x) {
          x = String(x).trim();
          var i = x.indexOf('##'), host = '', sel = x;
          if (i > 0) { host = x.slice(0, i); sel = x.slice(i + 2); }
          if (host && !(h === host || h.endsWith('.' + host))) return;
          if (sel && /^[^{}]+$/.test(sel)) rules.push(sel);
        });
        if (rules.length) addCss(rules.join(',') + '{display:none!important}');
      } catch (e) { }
    }

    /* ---- YouTube: strip ad data from the player and skip any ad that still starts ---- */
    if (CFG.yt && /(^|\.)youtube(-nocookie)?\.com$/.test(h)) {
      var strip = function (o) {
        try {
          if (o && typeof o === 'object') {
            if (o.adPlacements) o.adPlacements = [];
            if (o.playerAds) o.playerAds = [];
            if (o.adSlots) o.adSlots = [];
            if (o.adBreakHeartbeatParams) delete o.adBreakHeartbeatParams;
            if (o.playerResponse) strip(o.playerResponse);
            if (o.response) strip(o.response);
          }
        } catch (e) { }
        return o;
      };
      try { var jp = JSON.parse; JSON.parse = function () { return strip(jp.apply(this, arguments)); }; } catch (e) { }
      try { var rj = Response.prototype.json; Response.prototype.json = function () { return rj.apply(this, arguments).then(strip); }; } catch (e) { }
      try {
        var ipr; Object.defineProperty(window, 'ytInitialPlayerResponse', { configurable: true, get: function () { return ipr; }, set: function (v) { ipr = strip(v); } });
      } catch (e) { }
      addCss('.video-ads,.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,#player-ads,#masthead-ad,' +
        'ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,' +
        'ytd-banner-promo-renderer,ytd-statement-banner-renderer,ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,' +
        'ad-slot-renderer,ytm-ad-slot-renderer,.ytm-ad-slot-renderer,.ad-container,.ytp-ad-persistent-progress-bar-container{display:none!important}');
      var wasAd = false, prevMuted = false;
      setInterval(function () {
        try {
          var p = document.querySelector('.html5-video-player');
          var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
          var ad = p && p.classList.contains('ad-showing');
          if (ad && v) {
            if (!wasAd) { prevMuted = v.muted; wasAd = true; }
            v.muted = true; v.playbackRate = 16;
            if (isFinite(v.duration) && v.duration > 0) v.currentTime = Math.max(0, v.duration - 0.05);
            var b = document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');
            if (b) b.click();
          } else if (wasAd && v) {
            wasAd = false; v.muted = prevMuted; v.playbackRate = 1;
          }
          var c = document.querySelector('.ytp-ad-overlay-close-button');
          if (c) c.click();
        } catch (e) { }
      }, 250);
    }

    if (css) {
      var st = document.createElement('style'); st.id = 'nb-css'; st.textContent = css;
      (document.head || document.documentElement).appendChild(st);
    }
  } catch (e) { }
})();
