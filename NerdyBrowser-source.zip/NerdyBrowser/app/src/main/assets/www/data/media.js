/* NerdyBrowser media finder. Runs in every page and every embedded frame.
   - puts a small Download button on big images and on videos
   - quietly notes the media links a site's own data hands to its player (JSON, YouTube player, Instagram, X, TikTok, Facebook, Reddit ...)
   - when you tap the button it sends what it found to the app (console line __NBMEDIA__), which shows the quality / size list.
   __NBM_ON__ = 1 when the downloader is on, __NBM_BTN__ = 1 when the buttons should show. */
(function () {
  try {
    if (window.__nbm) return;
    var ON = __NBM_ON__, BTN = __NBM_BTN__;
    var h = location.hostname;
    if (!ON || h === 'appassets.androidplatform.net') return;
    var SI = ['accounts.google.com', 'accounts.youtube.com', 'login.microsoftonline.com', 'login.live.com', 'appleid.apple.com', 'login.yahoo.com'];
    if (SI.indexOf(h) >= 0) return;
    window.__nbm = 1;

    var seq = 0, gid = 0, hits = [], seen = {}, notes = {};
    function abs(u) { try { return new URL(String(u).replace(/\\u0026/g, '&').replace(/&amp;/g, '&'), location.href).href; } catch (e) { return ''; } }
    function add(o) {
      if (!o || !o.url || typeof o.url !== 'string') return;
      if (/^(blob|data|javascript):/i.test(o.url)) return;
      o.url = abs(o.url);
      if (!/^https?:/i.test(o.url)) return;
      if (seen[o.url]) return;
      seen[o.url] = 1; o.t = ++seq;
      hits.push(o);
      if (hits.length > 400) hits.shift();
    }
    function labelFor(k) {
      if (/hd/i.test(k)) return 'HD';
      if (/sd/i.test(k)) return 'SD';
      return '';
    }
    /* walks any JSON and keeps what looks like a media address */
    function scan(o, d) {
      if (!o || typeof o !== 'object' || d > 10) return;
      var i, k, g;
      if (Array.isArray(o)) { for (i = 0; i < o.length && i < 250; i++) scan(o[i], d + 1); return; }
      if (Array.isArray(o.video_versions)) {
        g = 'g' + (++gid);
        o.video_versions.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (o.image_versions2 && Array.isArray(o.image_versions2.candidates)) {
        g = 'g' + (++gid);
        o.image_versions2.candidates.forEach(function (x) { if (x && x.url) add({ k: 'i', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (Array.isArray(o.display_resources)) {
        g = 'g' + (++gid);
        o.display_resources.forEach(function (x) { if (x && x.src) add({ k: 'i', url: x.src, w: x.config_width, h: x.config_height, g: g }); });
      }
      if (o.video_info && Array.isArray(o.video_info.variants)) {
        g = 'g' + (++gid);
        o.video_info.variants.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, br: x.bitrate, m: x.content_type, g: g }); });
      }
      if (o.bitrateInfo && Array.isArray(o.bitrateInfo)) {
        g = 'g' + (++gid);
        o.bitrateInfo.forEach(function (x) {
          var p = x && x.PlayAddr; if (!p) return;
          var u = (p.UrlList && p.UrlList[0]) || p.Uri;
          if (u) add({ k: 'v', url: u, w: p.Width, h: p.Height, br: x.Bitrate, sz: +p.DataSize || 0, g: g });
        });
      }
      var keys = ['playable_url', 'playable_url_quality_hd', 'browser_native_hd_url', 'browser_native_sd_url', 'hd_src', 'sd_src', 'fallback_url', 'hls_url', 'video_url', 'contentUrl', 'playAddr', 'downloadAddr', 'mp4_url', 'hlsUrl'];
      g = null;
      for (i = 0; i < keys.length; i++) {
        var v = o[keys[i]];
        if (typeof v === 'string' && /^(https?:|\/\/|\\u002F|\/)/.test(v)) {
          if (!g) g = 'g' + (++gid);
          add({ k: 'v', url: v.replace(/\\u002F/g, '/'), l: labelFor(keys[i]), g: g });
        }
      }
      var sd = o.streamingData;
      if (sd && typeof sd === 'object') {
        g = 'yt';
        (sd.formats || []).concat(sd.adaptiveFormats || []).forEach(function (f) {
          if (!f) return;
          if (!f.url) { if (f.signatureCipher || f.cipher) notes.cipher = (notes.cipher || 0) + 1; return; }
          var mt = String(f.mimeType || ''), mime = mt.split(';')[0];
          var ad = sd.adaptiveFormats && sd.adaptiveFormats.indexOf(f) >= 0;
          var isA = mime.indexOf('audio/') === 0;
          add({ k: isA ? 'a' : 'v', url: f.url, w: f.width, h: f.height, br: f.bitrate, m: mime, sz: +f.contentLength || 0, vo: ad && !isA, ao: ad && isA, g: g, l: f.qualityLabel || '' });
        });
        if (sd.hlsManifestUrl) add({ k: 'v', url: sd.hlsManifestUrl, g: g });
      }
      for (k in o) { var c = o[k]; if (c && typeof c === 'object') scan(c, d + 1); }
    }
    function parseTxt(t) {
      if (!t || t.length > 4e6) return;
      t = String(t).replace(/^\)\]\}'?\s*/, '').replace(/^for\s*\(;;\);/, '');
      var c = t.charAt(0);
      if (c !== '{' && c !== '[') return;
      try { scan(JSON.parse(t), 0); return; } catch (e) { }
      var ls = t.split('\n');
      for (var i = 0; i < ls.length && i < 60; i++) { try { if (ls[i].charAt(0) === '{') scan(JSON.parse(ls[i]), 0); } catch (e) { } }
    }
    try {
      var of = window.fetch;
      if (of) window.fetch = function () {
        var p = of.apply(this, arguments);
        try {
          p.then(function (r) {
            try {
              var ct = (r.headers && r.headers.get('content-type')) || '';
              if (/json|javascript|text\/plain|text\/html/.test(ct) && !/text\/html/.test(ct)) r.clone().text().then(parseTxt).catch(function () { });
            } catch (e) { }
          }).catch(function () { });
        } catch (e) { }
        return p;
      };
      var oo = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function () {
        try {
          this.addEventListener('load', function () {
            try {
              var rt = this.responseType;
              if (rt === '' || rt === 'text') parseTxt(this.responseText);
              else if (rt === 'json' && this.response) scan(this.response, 0);
            } catch (e) { }
          });
        } catch (e) { }
        return oo.apply(this, arguments);
      };
    } catch (e) { }

    var pageScanned = 0;
    function scanScripts() {
      if (pageScanned && Date.now() - pageScanned < 4000) return;
      pageScanned = Date.now();
      try {
        var ss = document.querySelectorAll('script[type="application/json"],script[type="application/ld+json"],script#__NEXT_DATA__,script#SIGI_STATE,script#__UNIVERSAL_DATA_FOR_REHYDRATION__'), tot = 0;
        for (var i = 0; i < ss.length && tot < 6e6; i++) { var tx = ss[i].textContent || ''; tot += tx.length; if (tx.length < 4e6) parseTxt(tx); }
      } catch (e) { }
      try {
        var ms = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
        for (var j = 0; j < ms.length; j++) add({ k: 'v', url: ms[j].content, g: 'og' });
      } catch (e) { }
    }
    function youtube() {
      if (!/(^|\.)youtube(-nocookie)?\.com$/.test(h)) return;
      try {
        var mp = document.getElementById('movie_player') || document.querySelector('.html5-video-player'), pr = null;
        if (mp && mp.getPlayerResponse) pr = mp.getPlayerResponse();
        if (!pr) pr = window.ytInitialPlayerResponse;
        if (pr) { seen = {}; hits = hits.filter(function (x) { return x.g !== 'yt'; }); scan(pr, 0); }
      } catch (e) { }
    }

    var IMG = /\.(jpe?g|png|webp|gif|avif|bmp)(\?|#|$)/i;
    function parseSet(s, base) {
      var out = [];
      String(s || '').split(',').forEach(function (p) {
        p = p.trim(); if (!p) return;
        var m = p.split(/\s+/), u = abs(m[0]), w = 0;
        if (m[1] && /w$/i.test(m[1])) w = parseInt(m[1], 10) || 0;
        if (u) out.push({ k: 'i', url: u, w: w, h: 0, g: 'set' });
      });
      return out;
    }
    function pathOf(u) { try { return new URL(u).pathname; } catch (e) { return u; } }

    function gather(el, mode) {
      var items = [], info = { notes: [] };
      scanScripts(); youtube();
      var pick = function (a) { a.forEach(function (x) { items.push(x); }); };
      if (el && el.tagName === 'IMG') {
        var cur = el.currentSrc || el.src || '';
        if (cur && !/^data:/.test(cur)) items.push({ k: 'i', url: abs(cur), w: el.naturalWidth || 0, h: el.naturalHeight || 0, l: 'As shown', g: 'cur' });
        else if (/^data:image\//.test(cur)) info.notes.push('This image is built into the page itself.');
        pick(parseSet(el.srcset));
        var pic = el.closest && el.closest('picture');
        if (pic) Array.prototype.forEach.call(pic.querySelectorAll('source'), function (s) { pick(parseSet(s.srcset)); });
        ['data-src', 'data-original', 'data-large', 'data-full', 'data-zoom-src', 'data-hi-res-src', 'data-lazy-src', 'data-highres', 'data-image'].forEach(function (a) {
          var v = el.getAttribute && el.getAttribute(a);
          if (v && /^(https?:)?\/\//.test(v) || (v && v.charAt(0) === '/')) items.push({ k: 'i', url: abs(v), w: 0, h: 0, l: 'Full size (from page)', g: 'attr' });
        });
        var a = el.closest && el.closest('a[href]');
        if (a && IMG.test(a.getAttribute('href') || '')) items.push({ k: 'i', url: abs(a.getAttribute('href')), w: 0, h: 0, l: 'Linked picture', g: 'link' });
        var cp = pathOf(abs(cur));
        hits.forEach(function (x) { if (x.k === 'i' && pathOf(x.url) === cp) items.push(x); });
        try {
          var u = new URL(abs(cur));
          if (u.hostname === 'pbs.twimg.com') {
            ['orig', '4096x4096', 'large', 'medium', 'small'].forEach(function (n) {
              var v = new URL(u.href); v.searchParams.set('name', n);
              items.push({ k: 'i', url: v.href, w: n === 'orig' ? 0 : (n === '4096x4096' ? 4096 : n === 'large' ? 1024 : n === 'medium' ? 600 : 360), h: 0, l: n === 'orig' ? 'Original' : '', g: 'tw' });
            });
          }
        } catch (e) { }
      } else if (el && el.tagName === 'VIDEO') {
        var vs = el.currentSrc || el.src || '';
        if (vs && !/^blob:/.test(vs)) items.push({ k: 'v', url: abs(vs), w: el.videoWidth || 0, h: el.videoHeight || 0, l: 'Video file', g: 'cur' });
        else if (/^blob:/.test(vs)) info.notes.push('This site plays the video in pieces, so there is no single file behind the player.');
        Array.prototype.forEach.call(el.querySelectorAll('source'), function (s) {
          if (!s.src) return;
          var lb = s.getAttribute('label') || s.getAttribute('title') || s.getAttribute('res') || s.getAttribute('size') || '';
          var sz = parseInt(s.getAttribute('size') || s.getAttribute('res') || '', 10) || 0;
          items.push({ k: 'v', url: abs(s.src), w: 0, h: sz, l: lb && !/^\d+$/.test(lb) ? lb : '', m: s.type || '', g: 'src' });
        });
        if (el.poster) items.push({ k: 'i', url: abs(el.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { if (x.k !== 'i') items.push(x); });
      } else {
        /* whole-page mode (from the menu) */
        var vids = document.getElementsByTagName('video');
        for (var i = 0; i < vids.length && i < 12; i++) {
          var v2 = vids[i], s2 = v2.currentSrc || v2.src || '';
          if (s2 && !/^blob:/.test(s2)) items.push({ k: 'v', url: abs(s2), w: v2.videoWidth || 0, h: v2.videoHeight || 0, l: 'Video file', g: 'cur' });
          if (v2.poster) items.push({ k: 'i', url: abs(v2.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        }
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { items.push(x); });
        var imgs = document.images, n = 0;
        for (var j = 0; j < imgs.length && n < 60; j++) {
          var im = imgs[j];
          if (im.naturalWidth >= 200 && im.naturalHeight >= 120 && im.currentSrc && !/^data:/.test(im.currentSrc)) { items.push({ k: 'i', url: abs(im.currentSrc), w: im.naturalWidth, h: im.naturalHeight, l: 'Picture', g: 'page' }); n++; }
        }
      }
      if (notes.cipher) info.notes.push(notes.cipher + ' YouTube format(s) are locked by YouTube and cannot be listed.');
      var out = { mode: mode, page: location.href, title: document.title || '', items: items.slice(0, 160), notes: info.notes };
      try { console.log('__NBMEDIA__' + JSON.stringify(out)); } catch (e) { }
    }
    window.__nbmPage = function () { gather(null, 'page'); };

    /* ---- the buttons ---- */
    if (!BTN) return;
    var host = null, root = null, pills = new Map(), vis = new Set(), io = null, raf = 0;
    var ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0l-5-5m5 5l5-5M5 21h14"/></svg>';
    function ensure() {
      if (host) return;
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483645;pointer-events:none;contain:layout style';
      root = host.attachShadow({ mode: 'closed' });
      root.innerHTML = '<style>.p{position:fixed;pointer-events:auto;display:flex;align-items:center;gap:5px;height:30px;padding:0 12px 0 9px;border-radius:15px;background:rgba(18,18,24,.8);color:#fff;font:600 12px/1 system-ui,sans-serif;border:1px solid rgba(255,255,255,.3);box-shadow:0 2px 8px rgba(0,0,0,.4);-webkit-tap-highlight-color:transparent;touch-action:manipulation;user-select:none;-webkit-user-select:none}.p svg{width:15px;height:15px}.p:active{background:#f0642f}</style>';
      (document.documentElement || document.body).appendChild(host);
    }
    function mkPill(el) {
      ensure();
      var b = document.createElement('div');
      b.className = 'p'; b.innerHTML = ICON + '<span>' + (el.tagName === 'VIDEO' ? 'Save video' : 'Save') + '</span>';
      var go = function (e) { e.preventDefault(); e.stopPropagation(); gather(el, el.tagName === 'VIDEO' ? 'video' : 'image'); };
      b.addEventListener('click', go);
      b.addEventListener('touchend', function (e) { e.stopPropagation(); }, { passive: true });
      root.appendChild(b);
      return b;
    }
    function place() {
      raf = 0;
      var vw = window.innerWidth, vh = window.innerHeight;
      vis.forEach(function (el) {
        var r = el.getBoundingClientRect(), p = pills.get(el);
        if (r.width < 150 || r.height < 100 || r.bottom < 40 || r.top > vh - 20 || r.right < 20 || r.left > vw - 20) { if (p) p.style.display = 'none'; return; }
        if (!p) { p = mkPill(el); pills.set(el, p); }
        p.style.display = 'flex';
        if (el.tagName === 'VIDEO') {
          p.style.left = 'auto'; p.style.right = Math.max(8, vw - r.right + 8) + 'px';
          p.style.top = Math.max(r.top + 8, 8) + 'px'; p.style.bottom = 'auto';
        } else {
          p.style.right = 'auto'; p.style.left = Math.max(r.left + 8, 8) + 'px';
          p.style.top = Math.max(r.top + 4, Math.min(r.bottom, vh) - 38) + 'px'; p.style.bottom = 'auto';
        }
      });
    }
    function sched() { if (!raf) raf = requestAnimationFrame(place); }
    function watch(el) {
      if (!el || el.__nbw) return;
      if (el.tagName !== 'IMG' && el.tagName !== 'VIDEO') return;
      el.__nbw = 1;
      try { io.observe(el); } catch (e) { }
    }
    function start() {
      if (!window.IntersectionObserver) return;
      io = new IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (e.isIntersecting) vis.add(e.target);
          else { vis.delete(e.target); var p = pills.get(e.target); if (p) p.style.display = 'none'; }
        });
        sched();
      }, { threshold: 0 });
      Array.prototype.forEach.call(document.querySelectorAll('img,video'), watch);
      new MutationObserver(function (ms) {
        ms.forEach(function (m) {
          Array.prototype.forEach.call(m.addedNodes, function (n) {
            if (n.nodeType !== 1) return;
            watch(n);
            if (n.querySelectorAll) Array.prototype.forEach.call(n.querySelectorAll('img,video'), watch);
          });
        });
      }).observe(document.documentElement, { childList: true, subtree: true });
      window.addEventListener('scroll', sched, { passive: true, capture: true });
      window.addEventListener('resize', sched, { passive: true });
      setInterval(sched, 800);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  } catch (e) { }
})();
