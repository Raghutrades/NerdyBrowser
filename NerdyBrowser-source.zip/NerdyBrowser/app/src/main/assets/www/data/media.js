/* NerdyBrowser media finder. Runs in every page and every embedded frame.
   - puts a small Download button on big images and on videos
   - quietly notes the media links a site's own data hands to its player (JSON, YouTube player, Instagram, X, TikTok, Facebook, Reddit ...)
   - when you tap the button it sends what it found to the app (console line __NBMEDIA__), which shows the quality / size list.
   __NBM_ON__ = 1 when the downloader is on, __NBM_BTN__ = 1 when the buttons should show. */
(function () {
  try {
    if (window.__nbm) return;
    var ON = __NBM_ON__, BTN = __NBM_BTN__;
    var h = location.hostname;
    if (!ON || h === 'appassets.androidplatform.net') return;
    var SI = ['accounts.google.com', 'accounts.youtube.com', 'login.microsoftonline.com', 'login.live.com', 'appleid.apple.com', 'login.yahoo.com'];
    if (SI.indexOf(h) >= 0) return;
    window.__nbm = 1;

    var seq = 0, gid = 0, hits = [], seen = {}, notes = {}, nodes = 0, spent = 0;
    /* sites whose own data feeds carry video links; everywhere else the app's network sniffer + the page itself are used (no hooks = no slowdown) */
    var HOOK = /(^|\.)(instagram\.com|facebook\.com|fb\.watch|threads\.net|twitter\.com|x\.com|tiktok\.com|reddit\.com|vimeo\.com|dailymotion\.com|streamable\.com|imgur\.com)$/.test(h);
    function abs(u) { try { return new URL(String(u).replace(/\\u0026/g, '&').replace(/&amp;/g, '&'), location.href).href; } catch (e) { return ''; } }
    function add(o) {
      if (!o || !o.url || typeof o.url !== 'string') return;
      if (/^(blob|data|javascript):/i.test(o.url)) return;
      o.url = abs(o.url);
      if (!/^https?:/i.test(o.url)) return;
      if (seen[o.url]) return;
      seen[o.url] = 1; o.t = ++seq;
      hits.push(o);
      if (hits.length > 400) hits.shift();
    }
    function labelFor(k) {
      if (/hd/i.test(k)) return 'HD';
      if (/sd/i.test(k)) return 'SD';
      return '';
    }
    /* walks any JSON and keeps what looks like a media address */
    function scan(o, d) {
      if (!o || typeof o !== 'object' || d > 10) return;
      if (d === 0) nodes = 0;
      if (++nodes > 60000) return;
      var i, k, g;
      if (Array.isArray(o)) { for (i = 0; i < o.length && i < 250; i++) scan(o[i], d + 1); return; }
      if (Array.isArray(o.video_versions)) {
        g = 'g' + (++gid);
        o.video_versions.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (o.image_versions2 && Array.isArray(o.image_versions2.candidates)) {
        g = 'g' + (++gid);
        o.image_versions2.candidates.forEach(function (x) { if (x && x.url) add({ k: 'i', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (Array.isArray(o.display_resources)) {
        g = 'g' + (++gid);
        o.display_resources.forEach(function (x) { if (x && x.src) add({ k: 'i', url: x.src, w: x.config_width, h: x.config_height, g: g }); });
      }
      if (o.video_info && Array.isArray(o.video_info.variants)) {
        g = 'g' + (++gid);
        o.video_info.variants.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, br: x.bitrate, m: x.content_type, g: g }); });
      }
      if (o.bitrateInfo && Array.isArray(o.bitrateInfo)) {
        g = 'g' + (++gid);
        o.bitrateInfo.forEach(function (x) {
          var p = x && x.PlayAddr; if (!p) return;
          var u = (p.UrlList && p.UrlList[0]) || p.Uri;
          if (u) add({ k: 'v', url: u, w: p.Width, h: p.Height, br: x.Bitrate, sz: +p.DataSize || 0, g: g });
        });
      }
      if (o.video_list && typeof o.video_list === 'object' && !Array.isArray(o.video_list)) {
        g = 'g' + (++gid);
        for (k in o.video_list) { var vl = o.video_list[k]; if (vl && typeof vl.url === 'string') add({ k: 'v', url: vl.url, w: vl.width, h: vl.height, g: g }); }
      }
      var keys = ['playable_url', 'playable_url_quality_hd', 'browser_native_hd_url', 'browser_native_sd_url', 'hd_src', 'sd_src', 'fallback_url', 'hls_url', 'video_url', 'contentUrl', 'playAddr', 'downloadAddr', 'mp4_url', 'hlsUrl'];
      g = null;
      for (i = 0; i < keys.length; i++) {
        var v = o[keys[i]];
        if (typeof v === 'string' && /^(https?:|\/\/|\\u002F|\/)/.test(v)) {
          if (!g) g = 'g' + (++gid);
          add({ k: 'v', url: v.replace(/\\u002F/g, '/'), l: labelFor(keys[i]), g: g });
        }
      }
      var sd = o.streamingData;
      if (sd && typeof sd === 'object') {
        g = 'yt';
        (sd.formats || []).concat(sd.adaptiveFormats || []).forEach(function (f) {
          if (!f) return;
          if (!f.url) { if (f.signatureCipher || f.cipher) notes.cipher = (notes.cipher || 0) + 1; return; }
          var mt = String(f.mimeType || ''), mime = mt.split(';')[0];
          var ad = sd.adaptiveFormats && sd.adaptiveFormats.indexOf(f) >= 0;
          var isA = mime.indexOf('audio/') === 0;
          add({ k: isA ? 'a' : 'v', url: f.url, w: f.width, h: f.height, br: f.bitrate, m: mime, sz: +f.contentLength || 0, vo: ad && !isA, ao: ad && isA, g: g, l: f.qualityLabel || '' });
        });
        if (sd.hlsManifestUrl) add({ k: 'v', url: sd.hlsManifestUrl, g: g });
      }
      for (k in o) { var c = o[k]; if (c && typeof c === 'object') scan(c, d + 1); }
    }
    function parseTxt(t) {
      if (!t || t.length > 2e6 || spent > 700) return;
      var t0 = Date.now();
      try {
        t = String(t).replace(/^\)\]\}'?\s*/, '').replace(/^for\s*\(;;\);/, '');
        var c = t.charAt(0);
        if (c !== '{' && c !== '[') return;
        try { scan(JSON.parse(t), 0); return; } catch (e) { }
        var ls = t.split('\n');
        for (var i = 0; i < ls.length && i < 60; i++) { try { if (ls[i].charAt(0) === '{') scan(JSON.parse(ls[i]), 0); } catch (e) { } }
      } finally { spent += Date.now() - t0; }
    }
    if (HOOK) try {
      var of = window.fetch;
      if (of) window.fetch = function () {
        var p = of.apply(this, arguments);
        try {
          p.then(function (r) {
            try {
              if (spent > 700) return;
              var ct = (r.headers && r.headers.get('content-type')) || '';
              var cl = +((r.headers && r.headers.get('content-length')) || 0);
              if (/json|javascript|text\/plain/.test(ct) && cl < 1.5e6) r.clone().text().then(parseTxt).catch(function () { });
            } catch (e) { }
          }).catch(function () { });
        } catch (e) { }
        return p;
      };
      var oo = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function () {
        try {
          this.addEventListener('load', function () {
            try {
              if (spent > 700) return;
              var rt = this.responseType;
              if (rt === '' || rt === 'text') parseTxt(this.responseText);
              else if (rt === 'json' && this.response) { var t0 = Date.now(); scan(this.response, 0); spent += Date.now() - t0; }
            } catch (e) { }
          });
        } catch (e) { }
        return oo.apply(this, arguments);
      };
    } catch (e) { }

    var pageScanned = 0;
    function scanScripts() {
      if (pageScanned && Date.now() - pageScanned < 4000) return;
      pageScanned = Date.now();
      try {
        var ss = document.querySelectorAll('script[type="application/json"],script[type="application/ld+json"],script#__NEXT_DATA__,script#SIGI_STATE,script#__UNIVERSAL_DATA_FOR_REHYDRATION__'), tot = 0;
        for (var i = 0; i < ss.length && tot < 6e6; i++) { var tx = ss[i].textContent || ''; tot += tx.length; if (tx.length < 2e6) parseTxt(tx); }
      } catch (e) { }
      try {
        var ms = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
        for (var j = 0; j < ms.length; j++) add({ k: 'v', url: ms[j].content, g: 'og' });
      } catch (e) { }
    }
    var ytAsked = '', ytDone = 0;
    function ytAsk(id) {
      if (ytAsked === id) return; ytAsked = id;
      var clients = [
        { c: { clientName: 'ANDROID_VR', clientVersion: '1.60.19', deviceMake: 'Oculus', deviceModel: 'Quest 3', osName: 'Android', osVersion: '12L', androidSdkVersion: 32, hl: 'en' }, n: 28 },
        { c: { clientName: 'IOS', clientVersion: '20.10.4', deviceMake: 'Apple', deviceModel: 'iPhone16,2', osName: 'iPhone', osVersion: '18.3.2.22D82', hl: 'en' }, n: 5 }
      ];
      var k = 0; ytDone = 0;
      (function next() {
        if (k >= clients.length) { ytDone = 1; return; }
        var cl = clients[k++];
        try {
          fetch('/youtubei/v1/player?prettyPrint=false', { method: 'POST', credentials: 'omit', headers: { 'content-type': 'application/json', 'x-youtube-client-name': String(cl.n), 'x-youtube-client-version': cl.c.clientVersion },
            body: JSON.stringify({ videoId: id, context: { client: cl.c }, contentCheckOk: true, racyCheckOk: true }) })
            .then(function (r) { return r.json(); })
            .then(function (j) { var before = hits.length; scan(j, 0); for (var q = before; q < hits.length; q++) hits[q].g = 'ytx'; if (hits.length === before) next(); else ytDone = 1; })
            .catch(function () { next(); });
        } catch (e) { next(); }
      })();
    }
    function youtube() {
      if (!/(^|\.)youtube(-nocookie)?\.com$/.test(h)) return;
      try {
        var mp = document.getElementById('movie_player') || document.querySelector('.html5-video-player'), pr = null;
        if (mp && mp.getPlayerResponse) pr = mp.getPlayerResponse();
        if (!pr) pr = window.ytInitialPlayerResponse;
        if (pr) { seen = {}; hits = hits.filter(function (x) { return x.g !== 'yt'; }); scan(pr, 0); }
        var m = /[?&]v=([\w-]{11})/.exec(location.search) || /\/shorts\/([\w-]{11})/.exec(location.pathname);
        if (m) ytAsk(m[1]);
      } catch (e) { }
    }

    var IMG = /\.(jpe?g|png|webp|gif|avif|bmp)(\?|#|$)/i;
    function parseSet(s, base) {
      var out = [];
      String(s || '').split(',').forEach(function (p) {
        p = p.trim(); if (!p) return;
        var m = p.split(/\s+/), u = abs(m[0]), w = 0;
        if (m[1] && /w$/i.test(m[1])) w = parseInt(m[1], 10) || 0;
        if (u) out.push({ k: 'i', url: u, w: w, h: 0, g: 'set' });
      });
      return out;
    }
    function pinVariants(u, all) {
      var m = /^(https?:\/\/i\.pinimg\.com\/)(?:\d+x\d*|originals)(\/.*)$/.exec(u), out = [];
      if (!m) return out;
      out.push({ k: 'i', url: m[1] + 'originals' + m[2], w: 0, h: 0, l: 'Original', g: 'pin' });
      if (all) [['736x', 736], ['474x', 474], ['236x', 236]].forEach(function (z) { out.push({ k: 'i', url: m[1] + z[0] + m[2], w: z[1], h: 0, g: 'pin' }); });
      return out;
    }
    function perfMedia(items) {
      try {
        var pe = performance.getEntriesByType('resource'), c = 0;
        for (var q = pe.length - 1; q >= 0 && c < 80; q--) {
          var nm = pe[q].name || '';
          if (/\.(mp4|m4v|webm|mov|m3u8|mp3|m4a|aac|ogg|opus)(\?|#|$)/i.test(nm) && !/videoplayback/.test(nm)) {
            items.push({ k: /\.(mp3|m4a|aac|ogg|opus)(\?|#|$)/i.test(nm) ? 'a' : 'v', url: nm, w: 0, h: 0, l: '', g: 'perf' }); c++;
          }
        }
      } catch (e) { }
    }
    function pathOf(u) { try { return new URL(u).pathname; } catch (e) { return u; } }

    function gather(el, mode) {
      var items = [], info = { notes: [] };
      scanScripts(); youtube();
      var pick = function (a) { a.forEach(function (x) { items.push(x); }); };
      if (el && el.tagName === 'IMG') {
        var cur = el.currentSrc || el.src || '';
        if (cur && !/^data:/.test(cur)) items.push({ k: 'i', url: abs(cur), w: el.naturalWidth || 0, h: el.naturalHeight || 0, l: 'As shown', g: 'cur' });
        else if (/^data:image\//.test(cur)) info.notes.push('This image is built into the page itself.');
        pick(parseSet(el.srcset));
        var pic = el.closest && el.closest('picture');
        if (pic) Array.prototype.forEach.call(pic.querySelectorAll('source'), function (s) { pick(parseSet(s.srcset)); });
        ['data-src', 'data-original', 'data-large', 'data-full', 'data-zoom-src', 'data-hi-res-src', 'data-lazy-src', 'data-highres', 'data-image'].forEach(function (a) {
          var v = el.getAttribute && el.getAttribute(a);
          if (v && /^(https?:)?\/\//.test(v) || (v && v.charAt(0) === '/')) items.push({ k: 'i', url: abs(v), w: 0, h: 0, l: 'Full size (from page)', g: 'attr' });
        });
        var a = el.closest && el.closest('a[href]');
        if (a && IMG.test(a.getAttribute('href') || '')) items.push({ k: 'i', url: abs(a.getAttribute('href')), w: 0, h: 0, l: 'Linked picture', g: 'link' });
        pick(pinVariants(abs(cur), true));
        var cp = pathOf(abs(cur));
        hits.forEach(function (x) { if (x.k === 'i' && pathOf(x.url) === cp) items.push(x); });
        try {
          var u = new URL(abs(cur));
          if (u.hostname === 'pbs.twimg.com') {
            ['orig', '4096x4096', 'large', 'medium', 'small'].forEach(function (n) {
              var v = new URL(u.href); v.searchParams.set('name', n);
              items.push({ k: 'i', url: v.href, w: n === 'orig' ? 0 : (n === '4096x4096' ? 4096 : n === 'large' ? 1024 : n === 'medium' ? 600 : 360), h: 0, l: n === 'orig' ? 'Original' : '', g: 'tw' });
            });
          }
        } catch (e) { }
      } else if (el && el.tagName === 'VIDEO') {
        var vs = el.currentSrc || el.src || '';
        if (vs && !/^blob:/.test(vs)) items.push({ k: 'v', url: abs(vs), w: el.videoWidth || 0, h: el.videoHeight || 0, l: 'Video file', g: 'cur' });
        else if (/^blob:/.test(vs)) info.notes.push('This site plays the video in pieces, so there is no single file behind the player.');
        Array.prototype.forEach.call(el.querySelectorAll('source'), function (s) {
          if (!s.src) return;
          var lb = s.getAttribute('label') || s.getAttribute('title') || s.getAttribute('res') || s.getAttribute('size') || '';
          var sz = parseInt(s.getAttribute('size') || s.getAttribute('res') || '', 10) || 0;
          items.push({ k: 'v', url: abs(s.src), w: 0, h: sz, l: lb && !/^\d+$/.test(lb) ? lb : '', m: s.type || '', g: 'src' });
        });
        if (el.poster) items.push({ k: 'i', url: abs(el.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { if (x.k !== 'i') items.push(x); });
        perfMedia(items);
      } else {
        /* whole-page mode (from the menu) */
        var vids = document.getElementsByTagName('video');
        for (var i = 0; i < vids.length && i < 12; i++) {
          var v2 = vids[i], s2 = v2.currentSrc || v2.src || '';
          if (s2 && !/^blob:/.test(s2)) items.push({ k: 'v', url: abs(s2), w: v2.videoWidth || 0, h: v2.videoHeight || 0, l: 'Video file', g: 'cur' });
          if (v2.poster) items.push({ k: 'i', url: abs(v2.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        }
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { items.push(x); });
        perfMedia(items);
        var imgs = document.images, cand = [], vh2 = window.innerHeight;
        for (var j = 0; j < imgs.length && j < 400; j++) {
          var im = imgs[j];
          if (im.naturalWidth >= 200 && im.naturalHeight >= 120 && im.currentSrc && !/^data:/.test(im.currentSrc)) {
            var rr = im.getBoundingClientRect();
            cand.push({ im: im, d: (rr.bottom < 0 || rr.top > vh2) ? 1e6 + Math.abs(rr.top) : 0 });
          }
        }
        cand.sort(function (a, b) { return a.d - b.d; });
        cand.slice(0, 40).forEach(function (c) {
          var cu = abs(c.im.currentSrc);
          items.push({ k: 'i', url: cu, w: c.im.naturalWidth, h: c.im.naturalHeight, l: 'Picture', g: 'page' });
          pinVariants(cu, false).forEach(function (x) { items.push(x); });
        });
      }
      if (notes.cipher) info.notes.push(notes.cipher + ' YouTube format(s) are locked by YouTube and cannot be listed.');
      var out = { mode: mode, page: location.href, title: document.title || '', items: items.slice(0, 160), notes: info.notes };
      try { console.log('__NBMEDIA__' + JSON.stringify(out)); } catch (e) { }
    }
    function ytId() { return (/[?&]v=([\w-]{11})/.exec(location.search) || /\/shorts\/([\w-]{11})/.exec(location.pathname) || [])[1] || ''; }
    window.__nbmImg = function (src) {
      try {
        var im = document.images, el = null;
        for (var i = 0; i < im.length; i++) { if ((im[i].currentSrc || im[i].src) === src) { el = im[i]; break; } }
        if (!el) { el = document.createElement('img'); el.src = src; }
        gather(el, 'image'); return 1;
      } catch (e) { return 0; }
    };
    window.__nbmPage = function () {
      if (/(^|\.)youtube\.com$/.test(h)) { var id = ytId(); if (id) { ytAsk(id); if (!ytDone) { setTimeout(function () { gather(null, 'page'); }, 1500); return; } } }
      gather(null, 'page');
    };

    /* ---- the app itself shows the Save button (nothing is added to the page, so layouts never move and strict sites cannot break it).
       The app asks this every few seconds, so it must be cheap: it only looks at videos, big visible pictures and big video iframes. ---- */
    var PLAYERFR = /(youtube(-nocookie)?\.com\/embed|player\.vimeo\.com|dailymotion\.com\/embed|streamable\.com\/e|\/embed\/|player\.)/i;
    window.__nbmHas = function () {
      try {
        if (document.hidden) return 0;
        if (/(^|\.)youtube\.com$/.test(h)) { var yi = ytId(); if (yi) { ytAsk(yi); return 1; } return 0; }
        var vw = window.innerWidth, vh = window.innerHeight, i, r;
        var v = document.getElementsByTagName('video');
        for (i = 0; i < v.length && i < 12; i++) { r = v[i].getBoundingClientRect(); if (r.width >= 150 && r.height >= 90 && r.bottom > 0 && r.top < vh) return 1; }
        var f = document.getElementsByTagName('iframe');
        for (i = 0; i < f.length && i < 12; i++) { r = f[i].getBoundingClientRect(); if (r.width >= 240 && r.height >= 130 && r.bottom > 0 && r.top < vh && PLAYERFR.test(f[i].src || '')) return 1; }
        var im = document.images, n = 0;
        for (i = 0; i < im.length && n < 24; i++) {
          var e = im[i];
          if (e.naturalWidth < 200) continue;
          r = e.getBoundingClientRect(); n++;
          if (r.width >= 200 && r.height >= 120 && r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw) return 1;
        }
      } catch (e) { }
      return 0;
    };
  } catch (e) { }
})();
