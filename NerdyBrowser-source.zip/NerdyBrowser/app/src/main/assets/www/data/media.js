/* NerdyBrowser media finder. Runs in every page and every embedded frame.
   - puts a small Download button on big images and on videos
   - quietly notes the media links a site's own data hands to its player (JSON, YouTube player, Instagram, X, TikTok, Facebook, Reddit ...)
   - when you tap the button it sends what it found to the app (console line __NBMEDIA__), which shows the quality / size list.
   __NBM_ON__ = 1 when the downloader is on, __NBM_BTN__ = 1 when the buttons should show. */
(function () {
  try {
    if (window.__nbm) return;
    var ON = __NBM_ON__, BTN = __NBM_BTN__;
    var h = location.hostname;
    if (!ON || h === 'appassets.androidplatform.net') return;
    var SI = ['accounts.google.com', 'accounts.youtube.com', 'login.microsoftonline.com', 'login.live.com', 'appleid.apple.com', 'login.yahoo.com'];
    if (SI.indexOf(h) >= 0) return;
    window.__nbm = 1;

    var seq = 0, gid = 0, hits = [], seen = {}, notes = {}, nodes = 0, spent = 0;
    /* sites whose own data feeds carry video links; everywhere else the app's network sniffer + the page itself are used (no hooks = no slowdown) */
    var HOOK = /(^|\.)(instagram\.com|facebook\.com|fb\.watch|threads\.net|twitter\.com|x\.com|tiktok\.com|reddit\.com|vimeo\.com|dailymotion\.com|streamable\.com|imgur\.com)$/.test(h);
    function abs(u) { try { return new URL(String(u).replace(/\\u0026/g, '&').replace(/&amp;/g, '&'), location.href).href; } catch (e) { return ''; } }
    function add(o) {
      if (!o || !o.url || typeof o.url !== 'string') return;
      if (/^(blob|data|javascript):/i.test(o.url)) return;
      o.url = abs(o.url);
      if (!/^https?:/i.test(o.url)) return;
      if (seen[o.url]) return;
      seen[o.url] = 1; o.t = ++seq;
      hits.push(o);
      if (hits.length > 400) hits.shift();
    }
    function labelFor(k) {
      if (/hd/i.test(k)) return 'HD';
      if (/sd/i.test(k)) return 'SD';
      return '';
    }
    /* walks any JSON and keeps what looks like a media address */
    function scan(o, d) {
      if (!o || typeof o !== 'object' || d > 10) return;
      if (d === 0) nodes = 0;
      if (++nodes > 60000) return;
      var i, k, g;
      if (Array.isArray(o)) { for (i = 0; i < o.length && i < 250; i++) scan(o[i], d + 1); return; }
      if (Array.isArray(o.video_versions)) {
        g = 'g' + (++gid);
        o.video_versions.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (o.image_versions2 && Array.isArray(o.image_versions2.candidates)) {
        g = 'g' + (++gid);
        o.image_versions2.candidates.forEach(function (x) { if (x && x.url) add({ k: 'i', url: x.url, w: x.width, h: x.height, g: g }); });
      }
      if (Array.isArray(o.display_resources)) {
        g = 'g' + (++gid);
        o.display_resources.forEach(function (x) { if (x && x.src) add({ k: 'i', url: x.src, w: x.config_width, h: x.config_height, g: g }); });
      }
      if (o.video_info && Array.isArray(o.video_info.variants)) {
        g = 'g' + (++gid);
        o.video_info.variants.forEach(function (x) { if (x && x.url) add({ k: 'v', url: x.url, br: x.bitrate, m: x.content_type, g: g }); });
      }
      if (o.bitrateInfo && Array.isArray(o.bitrateInfo)) {
        g = 'g' + (++gid);
        o.bitrateInfo.forEach(function (x) {
          var p = x && x.PlayAddr; if (!p) return;
          var u = (p.UrlList && p.UrlList[0]) || p.Uri;
          if (u) add({ k: 'v', url: u, w: p.Width, h: p.Height, br: x.Bitrate, sz: +p.DataSize || 0, g: g });
        });
      }
      if (o.video_list && typeof o.video_list === 'object' && !Array.isArray(o.video_list)) {
        g = 'g' + (++gid);
        for (k in o.video_list) { var vl = o.video_list[k]; if (vl && typeof vl.url === 'string') add({ k: 'v', url: vl.url, w: vl.width, h: vl.height, g: g }); }
      }
      var keys = ['playable_url', 'playable_url_quality_hd', 'browser_native_hd_url', 'browser_native_sd_url', 'hd_src', 'sd_src', 'fallback_url', 'hls_url', 'video_url', 'contentUrl', 'playAddr', 'downloadAddr', 'mp4_url', 'hlsUrl'];
      g = null;
      for (i = 0; i < keys.length; i++) {
        var v = o[keys[i]];
        if (typeof v === 'string' && /^(https?:|\/\/|\\u002F|\/)/.test(v)) {
          if (!g) g = 'g' + (++gid);
          add({ k: 'v', url: v.replace(/\\u002F/g, '/'), l: labelFor(keys[i]), g: g });
        }
      }
      var sd = o.streamingData;
      if (sd && typeof sd === 'object') {
        g = 'yt';
        (sd.formats || []).concat(sd.adaptiveFormats || []).forEach(function (f) {
          if (!f) return;
          if (!f.url) { if (f.signatureCipher || f.cipher) notes.cipher = (notes.cipher || 0) + 1; return; }
          var mt = String(f.mimeType || ''), mime = mt.split(';')[0];
          var ad = sd.adaptiveFormats && sd.adaptiveFormats.indexOf(f) >= 0;
          var isA = mime.indexOf('audio/') === 0;
          add({ k: isA ? 'a' : 'v', url: f.url, w: f.width, h: f.height, br: f.bitrate, m: mime, sz: +f.contentLength || 0, vo: ad && !isA, ao: ad && isA, g: g, l: f.qualityLabel || '' });
        });
        if (sd.hlsManifestUrl) add({ k: 'v', url: sd.hlsManifestUrl, g: g });
      }
      for (k in o) { var c = o[k]; if (c && typeof c === 'object') scan(c, d + 1); }
    }
    function parseTxt(t) {
      if (!t || t.length > 2e6 || spent > 700) return;
      var t0 = Date.now();
      try {
        t = String(t).replace(/^\)\]\}'?\s*/, '').replace(/^for\s*\(;;\);/, '');
        var c = t.charAt(0);
        if (c !== '{' && c !== '[') return;
        try { scan(JSON.parse(t), 0); return; } catch (e) { }
        var ls = t.split('\n');
        for (var i = 0; i < ls.length && i < 60; i++) { try { if (ls[i].charAt(0) === '{') scan(JSON.parse(ls[i]), 0); } catch (e) { } }
      } finally { spent += Date.now() - t0; }
    }
    if (HOOK) try {
      var of = window.fetch;
      if (of) window.fetch = function () {
        var p = of.apply(this, arguments);
        try {
          p.then(function (r) {
            try {
              if (spent > 700) return;
              var ct = (r.headers && r.headers.get('content-type')) || '';
              var cl = +((r.headers && r.headers.get('content-length')) || 0);
              if (/json|javascript|text\/plain/.test(ct) && cl < 1.5e6) r.clone().text().then(parseTxt).catch(function () { });
            } catch (e) { }
          }).catch(function () { });
        } catch (e) { }
        return p;
      };
      var oo = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function () {
        try {
          this.addEventListener('load', function () {
            try {
              if (spent > 700) return;
              var rt = this.responseType;
              if (rt === '' || rt === 'text') parseTxt(this.responseText);
              else if (rt === 'json' && this.response) { var t0 = Date.now(); scan(this.response, 0); spent += Date.now() - t0; }
            } catch (e) { }
          });
        } catch (e) { }
        return oo.apply(this, arguments);
      };
    } catch (e) { }

    var pageScanned = 0;
    function scanScripts() {
      if (pageScanned && Date.now() - pageScanned < 4000) return;
      pageScanned = Date.now();
      try {
        var ss = document.querySelectorAll('script[type="application/json"],script[type="application/ld+json"],script#__NEXT_DATA__,script#SIGI_STATE,script#__UNIVERSAL_DATA_FOR_REHYDRATION__'), tot = 0;
        for (var i = 0; i < ss.length && tot < 6e6; i++) { var tx = ss[i].textContent || ''; tot += tx.length; if (tx.length < 2e6) parseTxt(tx); }
      } catch (e) { }
      try {
        var ms = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
        for (var j = 0; j < ms.length; j++) add({ k: 'v', url: ms[j].content, g: 'og' });
      } catch (e) { }
    }
    function youtube() {
      if (!/(^|\.)youtube(-nocookie)?\.com$/.test(h)) return;
      try {
        var mp = document.getElementById('movie_player') || document.querySelector('.html5-video-player'), pr = null;
        if (mp && mp.getPlayerResponse) pr = mp.getPlayerResponse();
        if (!pr) pr = window.ytInitialPlayerResponse;
        if (pr) { seen = {}; hits = hits.filter(function (x) { return x.g !== 'yt'; }); scan(pr, 0); }
      } catch (e) { }
    }

    var IMG = /\.(jpe?g|png|webp|gif|avif|bmp)(\?|#|$)/i;
    function parseSet(s, base) {
      var out = [];
      String(s || '').split(',').forEach(function (p) {
        p = p.trim(); if (!p) return;
        var m = p.split(/\s+/), u = abs(m[0]), w = 0;
        if (m[1] && /w$/i.test(m[1])) w = parseInt(m[1], 10) || 0;
        if (u) out.push({ k: 'i', url: u, w: w, h: 0, g: 'set' });
      });
      return out;
    }
    function pinVariants(u, all) {
      var m = /^(https?:\/\/i\.pinimg\.com\/)(?:\d+x\d*|originals)(\/.*)$/.exec(u), out = [];
      if (!m) return out;
      out.push({ k: 'i', url: m[1] + 'originals' + m[2], w: 0, h: 0, l: 'Original', g: 'pin' });
      if (all) [['736x', 736], ['474x', 474], ['236x', 236]].forEach(function (z) { out.push({ k: 'i', url: m[1] + z[0] + m[2], w: z[1], h: 0, g: 'pin' }); });
      return out;
    }
    function perfMedia(items) {
      try {
        var pe = performance.getEntriesByType('resource'), c = 0;
        for (var q = pe.length - 1; q >= 0 && c < 80; q--) {
          var nm = pe[q].name || '';
          if (/\.(mp4|m4v|webm|mov|m3u8|mp3|m4a|aac|ogg|opus)(\?|#|$)/i.test(nm) && !/videoplayback/.test(nm)) {
            items.push({ k: /\.(mp3|m4a|aac|ogg|opus)(\?|#|$)/i.test(nm) ? 'a' : 'v', url: nm, w: 0, h: 0, l: '', g: 'perf' }); c++;
          }
        }
      } catch (e) { }
    }
    function pathOf(u) { try { return new URL(u).pathname; } catch (e) { return u; } }

    function gather(el, mode) {
      var items = [], info = { notes: [] };
      scanScripts(); youtube();
      var pick = function (a) { a.forEach(function (x) { items.push(x); }); };
      if (el && el.tagName === 'IMG') {
        var cur = el.currentSrc || el.src || '';
        if (cur && !/^data:/.test(cur)) items.push({ k: 'i', url: abs(cur), w: el.naturalWidth || 0, h: el.naturalHeight || 0, l: 'As shown', g: 'cur' });
        else if (/^data:image\//.test(cur)) info.notes.push('This image is built into the page itself.');
        pick(parseSet(el.srcset));
        var pic = el.closest && el.closest('picture');
        if (pic) Array.prototype.forEach.call(pic.querySelectorAll('source'), function (s) { pick(parseSet(s.srcset)); });
        ['data-src', 'data-original', 'data-large', 'data-full', 'data-zoom-src', 'data-hi-res-src', 'data-lazy-src', 'data-highres', 'data-image'].forEach(function (a) {
          var v = el.getAttribute && el.getAttribute(a);
          if (v && /^(https?:)?\/\//.test(v) || (v && v.charAt(0) === '/')) items.push({ k: 'i', url: abs(v), w: 0, h: 0, l: 'Full size (from page)', g: 'attr' });
        });
        var a = el.closest && el.closest('a[href]');
        if (a && IMG.test(a.getAttribute('href') || '')) items.push({ k: 'i', url: abs(a.getAttribute('href')), w: 0, h: 0, l: 'Linked picture', g: 'link' });
        pick(pinVariants(abs(cur), true));
        var cp = pathOf(abs(cur));
        hits.forEach(function (x) { if (x.k === 'i' && pathOf(x.url) === cp) items.push(x); });
        try {
          var u = new URL(abs(cur));
          if (u.hostname === 'pbs.twimg.com') {
            ['orig', '4096x4096', 'large', 'medium', 'small'].forEach(function (n) {
              var v = new URL(u.href); v.searchParams.set('name', n);
              items.push({ k: 'i', url: v.href, w: n === 'orig' ? 0 : (n === '4096x4096' ? 4096 : n === 'large' ? 1024 : n === 'medium' ? 600 : 360), h: 0, l: n === 'orig' ? 'Original' : '', g: 'tw' });
            });
          }
        } catch (e) { }
      } else if (el && el.tagName === 'VIDEO') {
        var vs = el.currentSrc || el.src || '';
        if (vs && !/^blob:/.test(vs)) items.push({ k: 'v', url: abs(vs), w: el.videoWidth || 0, h: el.videoHeight || 0, l: 'Video file', g: 'cur' });
        else if (/^blob:/.test(vs)) info.notes.push('This site plays the video in pieces, so there is no single file behind the player.');
        Array.prototype.forEach.call(el.querySelectorAll('source'), function (s) {
          if (!s.src) return;
          var lb = s.getAttribute('label') || s.getAttribute('title') || s.getAttribute('res') || s.getAttribute('size') || '';
          var sz = parseInt(s.getAttribute('size') || s.getAttribute('res') || '', 10) || 0;
          items.push({ k: 'v', url: abs(s.src), w: 0, h: sz, l: lb && !/^\d+$/.test(lb) ? lb : '', m: s.type || '', g: 'src' });
        });
        if (el.poster) items.push({ k: 'i', url: abs(el.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { if (x.k !== 'i') items.push(x); });
        perfMedia(items);
      } else {
        /* whole-page mode (from the menu) */
        var vids = document.getElementsByTagName('video');
        for (var i = 0; i < vids.length && i < 12; i++) {
          var v2 = vids[i], s2 = v2.currentSrc || v2.src || '';
          if (s2 && !/^blob:/.test(s2)) items.push({ k: 'v', url: abs(s2), w: v2.videoWidth || 0, h: v2.videoHeight || 0, l: 'Video file', g: 'cur' });
          if (v2.poster) items.push({ k: 'i', url: abs(v2.poster), w: 0, h: 0, l: 'Cover picture', g: 'poster' });
        }
        hits.slice().sort(function (a, b) { return b.t - a.t; }).forEach(function (x) { items.push(x); });
        perfMedia(items);
        var imgs = document.images, cand = [], vh2 = window.innerHeight;
        for (var j = 0; j < imgs.length && j < 400; j++) {
          var im = imgs[j];
          if (im.naturalWidth >= 200 && im.naturalHeight >= 120 && im.currentSrc && !/^data:/.test(im.currentSrc)) {
            var rr = im.getBoundingClientRect();
            cand.push({ im: im, d: (rr.bottom < 0 || rr.top > vh2) ? 1e6 + Math.abs(rr.top) : 0 });
          }
        }
        cand.sort(function (a, b) { return a.d - b.d; });
        cand.slice(0, 40).forEach(function (c) {
          var cu = abs(c.im.currentSrc);
          items.push({ k: 'i', url: cu, w: c.im.naturalWidth, h: c.im.naturalHeight, l: 'Picture', g: 'page' });
          pinVariants(cu, false).forEach(function (x) { items.push(x); });
        });
      }
      if (notes.cipher) info.notes.push(notes.cipher + ' YouTube format(s) are locked by YouTube and cannot be listed.');
      var out = { mode: mode, page: location.href, title: document.title || '', items: items.slice(0, 160), notes: info.notes };
      try { console.log('__NBMEDIA__' + JSON.stringify(out)); } catch (e) { }
    }
    window.__nbmPage = function () { gather(null, 'page'); };

    /* ---- ONE small floating Save button (top page only; nothing is attached to pictures or videos) ---- */
    if (!BTN || window.top !== window) return;
    var host = null, root = null, btn = null, tm = 0;
    var ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0l-5-5m5 5l5-5M5 21h14"/></svg>';
    function ensure() {
      if (host) return;
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483645;pointer-events:none;contain:layout style';
      root = host.attachShadow({ mode: 'closed' });
      root.innerHTML = '<style>.p{position:fixed;right:10px;bottom:120px;width:42px;height:42px;border-radius:21px;display:none;align-items:center;justify-content:center;pointer-events:auto;background:rgba(18,18,24,.72);color:#fff;border:1px solid rgba(255,255,255,.3);box-shadow:0 2px 8px rgba(0,0,0,.4);opacity:.8;touch-action:none;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none}.p svg{width:20px;height:20px}.p:active{background:#f0642f}</style>';
      btn = document.createElement('div');
      btn.className = 'p'; btn.innerHTML = ICON;
      root.appendChild(btn);
      var sx = 0, sy = 0, ox = 0, oy = 0, mv = false, down = false;
      btn.addEventListener('pointerdown', function (e) {
        down = true; mv = false; sx = e.clientX; sy = e.clientY;
        var r = btn.getBoundingClientRect(); ox = r.left; oy = r.top;
        try { btn.setPointerCapture(e.pointerId); } catch (x) { }
        e.stopPropagation();
      });
      btn.addEventListener('pointermove', function (e) {
        if (!down) return;
        var dx = e.clientX - sx, dy = e.clientY - sy;
        if (!mv && Math.abs(dx) + Math.abs(dy) < 10) return;
        mv = true; /* drag it anywhere if it covers something */
        btn.style.right = 'auto'; btn.style.bottom = 'auto';
        btn.style.left = Math.max(0, Math.min(window.innerWidth - 42, ox + dx)) + 'px';
        btn.style.top = Math.max(0, Math.min(window.innerHeight - 42, oy + dy)) + 'px';
        e.preventDefault();
      });
      btn.addEventListener('pointerup', function (e) { if (!down) return; down = false; e.stopPropagation(); if (!mv) gather(null, 'page'); });
      btn.addEventListener('pointercancel', function () { down = false; });
      (document.documentElement || document.body).appendChild(host);
    }
    function hasMedia() {
      try {
        var v = document.getElementsByTagName('video'), i;
        for (i = 0; i < v.length && i < 20; i++) { var r = v[i].getBoundingClientRect(); if (r.width >= 150 && r.height >= 90) return true; }
        var im = document.images, vw = window.innerWidth, vh = window.innerHeight;
        for (i = 0; i < im.length && i < 150; i++) {
          var q = im[i].getBoundingClientRect();
          if (q.width >= 200 && q.height >= 120 && q.bottom > 0 && q.top < vh && q.right > 0 && q.left < vw) return true;
        }
      } catch (e) { }
      return false;
    }
    function tick() {
      try {
        if (!document.hidden) {
          if (hasMedia()) { ensure(); if (btn) btn.style.display = 'flex'; }
          else if (btn) btn.style.display = 'none';
        }
      } catch (e) { }
      tm = setTimeout(tick, 2500);
    }
    function start() { tm = setTimeout(tick, 1200); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  } catch (e) { }
})();
