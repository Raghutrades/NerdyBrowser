/* NerdyBrowser element picker: tap something on the page to hide it for good on this site. */
(function () {
  try {
    if (window.__nbPick) return;
    window.__nbPick = 1;
    var box = document.createElement('div');
    box.style.cssText = 'position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #f0642f;background:rgba(240,100,47,.22);border-radius:4px;display:none';
    var bar = document.createElement('div');
    bar.textContent = 'Tap the thing you want to hide  (tap here to cancel)';
    bar.style.cssText = 'position:fixed;left:8px;right:8px;top:8px;z-index:2147483647;background:#1f2937;color:#fff;font:600 14px sans-serif;padding:12px 14px;border-radius:14px;text-align:center;box-shadow:0 4px 18px rgba(0,0,0,.4)';
    document.documentElement.appendChild(box);
    document.documentElement.appendChild(bar);
    var cur = null;
    function esc(s) { return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&'); }
    function sel(el) {
      var parts = [];
      for (var n = el; n && n.nodeType === 1 && n !== document.body && parts.length < 4; n = n.parentElement) {
        var s = n.tagName.toLowerCase();
        if (n.id && !/\d{4,}/.test(n.id)) { parts.unshift('#' + esc(n.id)); break; }
        var cl = (n.className && typeof n.className === 'string' ? n.className.trim().split(/\s+/) : []).filter(function (c) { return c && !/\d{3,}|^(active|open|show|hover|focus)$/.test(c); });
        if (cl.length) s += '.' + esc(cl[0]);
        parts.unshift(s);
        try { if (document.querySelectorAll(parts.join(' > ')).length === 1) break; } catch (e) { }
      }
      return parts.join(' > ');
    }
    function hi(t) {
      var el = document.elementFromPoint(t.clientX, t.clientY);
      if (!el || el === bar || el === box || el === document.documentElement || el === document.body) return;
      cur = el;
      var r = el.getBoundingClientRect();
      box.style.display = 'block'; box.style.left = r.left + 'px'; box.style.top = r.top + 'px'; box.style.width = r.width + 'px'; box.style.height = r.height + 'px';
    }
    function done() {
      document.removeEventListener('touchmove', onMove, true); document.removeEventListener('touchstart', onMove, true);
      document.removeEventListener('click', onClick, true);
      box.remove(); bar.remove(); window.__nbPick = 0;
    }
    function onMove(e) { var t = e.touches && e.touches[0]; if (t) hi(t); }
    function onClick(e) {
      if (e.target === bar) { e.preventDefault(); e.stopPropagation(); done(); return; }
      e.preventDefault(); e.stopPropagation();
      var el = cur || e.target;
      var s = sel(el);
      try { el.style.setProperty('display', 'none', 'important'); } catch (x) { }
      done();
      if (s) console.log('__NBHIDE__' + s);
    }
    document.addEventListener('touchstart', onMove, true);
    document.addEventListener('touchmove', onMove, true);
    document.addEventListener('click', onClick, true);
  } catch (e) { }
})();
