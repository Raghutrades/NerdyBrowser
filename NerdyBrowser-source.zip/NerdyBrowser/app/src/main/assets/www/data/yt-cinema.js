/* NerdyBrowser · YouTube Cinema. A Netflix-style way to watch YouTube.
   It reads the videos YouTube itself puts on the page (your own home feed, subscriptions, search results)
   and shows them as a hero banner + rows, with Shorts on their own row. Nothing is sent anywhere.
   The Classic | Cinema | Shorts switch at the bottom goes back to normal YouTube at any time. */
(function () {
  try {
    var h = location.hostname;
    if (!/(^|\.)youtube\.com$/.test(h) || /^(accounts|music|studio)\./.test(h) || window.top !== window || window.__nbc) return;
    window.__nbc = 1;
    var ls = function (k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { } return null; };
    var cinema = function () { var v = ls('nbcine'); return v === 'cinema' || v === 'videos'; };
    var P = function () { return location.pathname; };
    var onShorts = function () { return P().indexOf('/shorts') === 0; };
    var browse = function () { var p = P(); return p === '/' || p === '/feed/subscriptions' || p === '/results' || p === '/feed/trending' || p === '/feed/explore'; };
    var isResults = function () { return P() === '/results'; };
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var el = function (tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

    /* ---------------- look ---------------- */
    var D = 'html.nb-cn ';
    var plain = ['ytd-reel-shelf-renderer', 'ytm-reel-shelf-renderer', 'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2', 'ytd-rich-shelf-renderer[is-shorts]', 'ytd-mini-guide-entry-renderer[aria-label="Shorts"]'];
    var hasList = ['ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-grid-video-renderer', 'ytd-compact-video-renderer', 'ytm-video-with-context-renderer', 'ytm-compact-video-renderer', 'ytm-rich-item-renderer']
      .map(function (t) { return t + ':has(a[href^="/shorts/"])'; });
    hasList.push('ytm-rich-section-renderer:has(ytm-shorts-lockup-view-model)', 'ytm-rich-section-renderer:has(ytm-reel-shelf-renderer)', 'ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)',
      'ytm-item-section-renderer:has(ytm-reel-shelf-renderer)', 'ytd-guide-entry-renderer:has(a[title="Shorts"])', 'ytm-pivot-bar-item-renderer:has([class*="shorts"])');
    var css =
      D.trim() + '{--yt-spec-base-background:#0b0b0f!important;--yt-spec-raised-background:#15151c!important;--yt-spec-menu-background:#15151c!important;--yt-spec-general-background-a:#0b0b0f!important;' +
      '--yt-spec-general-background-b:#0b0b0f!important;--yt-spec-general-background-c:#15151c!important;--yt-spec-text-primary:#f5f5f7!important;--yt-spec-text-secondary:#a9a9b6!important;' +
      '--yt-spec-icon-active-other:#f5f5f7!important;--yt-spec-10-percent-layer:#262631!important;--yt-spec-badge-chip-background:#1d1d26!important;color-scheme:dark}' +
      D + 'body,' + D + 'ytd-app,' + D + 'ytm-app,' + D + 'ytd-masthead,' + D + 'ytm-mobile-topbar-renderer,' + D + '.mobile-topbar-header{background:#0b0b0f!important}' +
      D + 'ytd-thumbnail,' + D + 'ytd-thumbnail a,' + D + '.video-thumbnail-container-large,' + D + '.media-item-thumbnail-container{border-radius:16px!important;overflow:hidden!important}' +
      /* the pill */
      '#nbc-bar{position:fixed;left:50%;bottom:calc(env(safe-area-inset-bottom,0px) + 14px);transform:translateX(-50%);z-index:2147483647;display:flex;gap:2px;padding:3px;border-radius:999px;' +
      'background:rgba(18,18,24,.88);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);box-shadow:0 6px 22px rgba(0,0,0,.5);font:600 12px/1 system-ui,sans-serif}' +
      '#nbc-bar button{all:unset;padding:9px 14px;border-radius:999px;color:#d2d2dc;cursor:pointer;-webkit-tap-highlight-color:transparent}' +
      '#nbc-bar button.on{background:linear-gradient(135deg,#ff4d5e,#ff8a3d);color:#fff}' +
      /* the cinema screen */
      '#nbt{position:fixed;inset:0;z-index:2147483000;overflow-y:auto;overflow-x:hidden;background:#0b0b0f;color:#f5f5f7;font:14px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;' +
      'overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding-bottom:110px;display:none}' +
      '#nbt.on{display:block}' +
      '#nbt *{box-sizing:border-box}' +
      '#nbt .top{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:10px;padding:calc(env(safe-area-inset-top,0px) + 10px) 14px 10px;background:linear-gradient(#0b0b0f 70%,rgba(11,11,15,0))}' +
      '#nbt .logo{font-weight:800;font-size:17px;letter-spacing:-.3px;white-space:nowrap}#nbt .logo b{background:linear-gradient(135deg,#ff4d5e,#ff8a3d);-webkit-background-clip:text;background-clip:text;color:transparent}' +
      '#nbt form{flex:1;display:flex;min-width:0}' +
      '#nbt input{flex:1;min-width:0;height:36px;border-radius:18px;border:1px solid #2a2a36;background:#16161d;color:#f5f5f7;padding:0 14px;font-size:14px;outline:none}' +
      '#nbt input:focus{border-color:#ff6a4d}' +
      '#nbt .tabs{display:flex;gap:8px;padding:0 14px 6px;overflow-x:auto;scrollbar-width:none}' +
      '#nbt .tabs a,#nbt .chips span{flex:none;padding:8px 15px;border-radius:999px;background:#16161d;color:#cfcfda;text-decoration:none;font-weight:600;font-size:13px;border:1px solid #23232d;cursor:pointer}' +
      '#nbt .tabs a.on,#nbt .chips span.on{background:#f5f5f7;color:#111;border-color:#f5f5f7}' +
      '#nbt .chips{display:flex;gap:8px;padding:4px 14px 10px;overflow-x:auto;scrollbar-width:none}' +
      '#nbt .chips:empty{display:none}' +
      '#nbt .hero{position:relative;margin:4px 14px 6px;border-radius:20px;overflow:hidden;background:#15151c;aspect-ratio:16/9;max-height:56vh;box-shadow:0 14px 40px rgba(0,0,0,.55)}' +
      '#nbt .hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}' +
      '#nbt .hero:after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(11,11,15,.96) 0%,rgba(11,11,15,.35) 52%,rgba(11,11,15,0) 100%)}' +
      '#nbt .hero .in{position:absolute;left:0;right:0;bottom:0;z-index:2;padding:16px}' +
      '#nbt .hero .k{font-size:11px;font-weight:700;letter-spacing:.14em;color:#ff8a3d;margin-bottom:6px}' +
      '#nbt .hero h1{margin:0 0 4px;font-size:clamp(17px,4.6vw,28px);line-height:1.15;font-weight:800;text-shadow:0 2px 12px rgba(0,0,0,.6);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}' +
      '#nbt .hero p{margin:0 0 12px;color:#c9c9d4;font-size:12.5px}' +
      '#nbt .play{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:999px;background:#fff;color:#111;font-weight:800;text-decoration:none;font-size:14px}' +
      '#nbt .row{margin-top:20px}' +
      '#nbt .row h2{margin:0 14px 10px;font-size:17px;font-weight:800;letter-spacing:-.2px}' +
      '#nbt .rail{display:flex;gap:12px;overflow-x:auto;padding:0 14px 6px;scroll-snap-type:x proximity;scroll-padding-left:14px;scrollbar-width:none}' +
      '#nbt .rail::-webkit-scrollbar,#nbt .tabs::-webkit-scrollbar,#nbt .chips::-webkit-scrollbar{display:none}' +
      '#nbt .cd{flex:none;width:min(64vw,270px);scroll-snap-align:start;color:inherit;text-decoration:none;display:block;-webkit-tap-highlight-color:transparent}' +
      '#nbt .th{position:relative;aspect-ratio:16/9;border-radius:14px;overflow:hidden;background:#1a1a22;box-shadow:0 6px 18px rgba(0,0,0,.4);transition:transform .15s}' +
      '#nbt .cd:active .th{transform:scale(.97)}' +
      '#nbt .th img{width:100%;height:100%;object-fit:cover;display:block}' +
      '#nbt .du{position:absolute;right:7px;bottom:7px;padding:3px 6px;border-radius:6px;background:rgba(0,0,0,.78);font-size:11px;font-weight:700;font-style:normal}' +
      '#nbt .tt{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin:8px 2px 2px;font-weight:700;font-size:13.5px}' +
      '#nbt .mt{display:block;margin:0 2px;color:#9d9dab;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '#nbt .rail.sh .cd{width:122px}' +
      '#nbt .rail.sh .th{aspect-ratio:9/16;border-radius:16px}' +
      '#nbt .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:16px 12px;padding:0 14px}' +
      '#nbt .grid .cd{width:auto}' +
      '#nbt .more{text-align:center;color:#6f6f7d;font-size:12px;padding:22px 0}' +
      '#nbt .empty{padding:40px 24px;text-align:center;color:#9d9dab}' +
      '#nbt .sk{height:calc(56vw);max-height:300px;margin:6px 14px;border-radius:20px;background:linear-gradient(100deg,#15151c 30%,#20202a 50%,#15151c 70%);background-size:200% 100%;animation:nbsk 1.2s linear infinite}' +
      '@keyframes nbsk{to{background-position:-200% 0}}';

    /* ---------------- reading the page ---------------- */
    var ITEM = 'ytd-rich-item-renderer,ytd-video-renderer,ytd-grid-video-renderer,ytd-compact-video-renderer,ytm-video-with-context-renderer,ytm-compact-video-renderer,ytm-rich-item-renderer,ytm-media-item,yt-lockup-view-model,ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,ytd-reel-item-renderer,ytm-reel-item-renderer';
    var AD = 'ytd-ad-slot-renderer,ytd-promoted-video-renderer,ytd-display-ad-renderer,ytd-in-feed-ad-layout-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ad-slot-renderer,ytm-ad-slot-renderer,ytd-promoted-sparkles-web-renderer,ytm-promoted-sparkles-web-renderer';
    var TITLE = '#video-title,h3,.media-item-headline,.yt-lockup-metadata-view-model-wiz__title,.shortsLockupViewModelHostMetadataTitle,[class*="metadata-title"]';
    var seen = {}, vids = [], shorts = [], chipEls = [], chipSig = '', key = '', hold = 0;
    var ui = null, heroBox, railsBox, gridBox, chipBox, moreBox, input, shortRail = null, curRail = null, railN = 0, railCount = 0, heroDone = false, vRendered = 0, sRendered = 0, lastLoad = 0;
    var RN = ['Top picks', 'More to watch', 'Keep exploring', 'Fresh finds', 'Worth a look', 'Binge-worthy', 'Still going', 'Even more'];

    function idOf(href) { var m = /[?&]v=([\w-]{11})/.exec(href) || /\/shorts\/([\w-]{11})/.exec(href); return m ? m[1] : null; }
    function lines(c) { return (c.innerText || c.textContent || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean); }
    function read(a, c, short) {
      var t = '';
      var te = c.querySelector(TITLE);
      if (te) t = (te.getAttribute('title') || te.textContent || '').trim();
      if (!t) t = (a.getAttribute('title') || '').trim();
      var L = lines(c), dur = '', ch = '', meta = '';
      for (var i = 0; i < L.length; i++) { if (/^(\d{1,2}:)?\d{1,2}:\d{2}$/.test(L[i])) { dur = L[i]; break; } if (/^LIVE$/i.test(L[i])) { dur = 'LIVE'; break; } }
      if (!t) { for (var k = 0; k < Math.min(L.length, 5); k++) { if (L[k] !== dur && !/^(\d{1,2}:)?\d{1,2}:\d{2}$/.test(L[k]) && L[k].length > t.length && L[k].length > 3) t = L[k]; } }
      if (!t) t = (a.getAttribute('aria-label') || '').trim();
      for (var m = 0; m < L.length; m++) {
        if (L[m] === t || L[m] === dur || /^(\d{1,2}:)?\d{1,2}:\d{2}$/.test(L[m]) || /^(now playing|live|new|shorts?)$/i.test(L[m])) continue;
        if (/(views?|watching|ago|waiting)\b/i.test(L[m])) { if (!meta) meta = L[m]; continue; }
        if (!ch && L[m].length < 60 && L[m].length > 1) ch = L[m];
      }
      if (!t && !short) return null;
      return { t: t.slice(0, 140), ch: ch, meta: meta, dur: dur };
    }
    function scan() {
      var as = document.querySelectorAll('a[href*="/watch?v="],a[href*="/shorts/"]');
      for (var i = 0; i < as.length; i++) {
        var a = as[i];
        if (a.closest('#nbt') || a.closest(AD)) continue;
        var href = a.getAttribute('href') || '', id = idOf(href);
        if (!id || seen[id]) continue;
        var short = href.indexOf('/shorts/') > -1;
        var c = a.closest(ITEM) || a.parentElement;
        if (!c) continue;
        var r = read(a, c, short);
        if (!r) continue;
        r.id = id; r.s = short; seen[id] = 1;
        (short ? shorts : vids).push(r);
      }
      /* the chips (categories) that YouTube shows on its own page */
      var ce = document.querySelectorAll('yt-chip-cloud-chip-renderer,ytm-chip-cloud-chip-renderer');
      var sig = '', arr = [];
      for (var j = 0; j < ce.length; j++) {
        var tx = (ce[j].textContent || '').trim();
        if (!tx || ce[j].closest('#nbt')) continue;
        var on = ce[j].hasAttribute('selected') || ce[j].classList.contains('selected') || ce[j].getAttribute('aria-selected') === 'true' || !!ce[j].querySelector('[aria-selected="true"],.selected');
        arr.push({ e: ce[j], t: tx, on: on }); sig += tx + (on ? '*' : '') + '|';
      }
      if (sig !== chipSig) { chipSig = sig; chipEls = arr; drawChips(); }
    }

    /* ---------------- drawing ---------------- */
    function card(r) {
      var a = el('a', 'cd'); a.href = r.s ? '/shorts/' + r.id : '/watch?v=' + r.id;
      var th = el('div', 'th'), im = el('img'); im.loading = 'lazy'; im.alt = '';
      im.src = 'https://i.ytimg.com/vi/' + r.id + '/' + (r.s ? 'hq2.jpg' : 'mqdefault.jpg');
      im.onerror = function () { if (!im.dataset.f) { im.dataset.f = 1; im.src = 'https://i.ytimg.com/vi/' + r.id + '/hqdefault.jpg'; } };
      th.appendChild(im);
      if (r.dur && !r.s) th.appendChild(el('i', 'du', r.dur));
      a.appendChild(th);
      a.appendChild(el('b', 'tt', r.t || 'Short'));
      var m = [r.ch, r.meta].filter(Boolean).join(' · ');
      if (m && !r.s) a.appendChild(el('span', 'mt', m));
      return a;
    }
    function build() {
      if (ui) return;
      ui = el('div'); ui.id = 'nbt';
      var top = el('div', 'top'), logo = el('div', 'logo'); logo.innerHTML = '<b>Nerdy</b>Tube';
      var f = el('form'); input = el('input'); input.type = 'search'; input.placeholder = 'Search YouTube'; input.setAttribute('enterkeyhint', 'search'); f.appendChild(input);
      f.addEventListener('submit', function (e) { e.preventDefault(); var q = input.value.trim(); if (q) location.href = '/results?search_query=' + encodeURIComponent(q); });
      top.appendChild(logo); top.appendChild(f); ui.appendChild(top);
      var tabs = el('div', 'tabs');
      [['/', 'Home'], ['/feed/subscriptions', 'Subscriptions'], ['/shorts', 'Shorts']].forEach(function (x) {
        var a = el('a', '', x[1]); a.href = x[0]; a.setAttribute('data-p', x[0]); tabs.appendChild(a);
      });
      ui.appendChild(tabs);
      chipBox = el('div', 'chips'); ui.appendChild(chipBox);
      heroBox = el('div'); ui.appendChild(heroBox);
      railsBox = el('div'); ui.appendChild(railsBox);
      gridBox = el('div'); ui.appendChild(gridBox);
      moreBox = el('div', 'more', 'Loading…'); ui.appendChild(moreBox);
      ui.addEventListener('scroll', function () { grow(); }, { passive: true });
      document.documentElement.appendChild(ui);
    }
    function drawChips() {
      if (!chipBox) return;
      chipBox.textContent = '';
      chipEls.slice(0, 40).forEach(function (c, i) {
        var s = el('span', c.on ? 'on' : '', c.t);
        s.addEventListener('click', function () { try { c.e.click(); } catch (e) { } hold = Date.now() + 700; clearItems(); });
        chipBox.appendChild(s);
      });
    }
    function clearItems() {
      seen = {}; vids = []; shorts = []; vRendered = 0; sRendered = 0; heroDone = false; shortRail = null; curRail = null; railN = 0; railCount = 0;
      if (ui) { heroBox.textContent = ''; railsBox.textContent = ''; gridBox.textContent = ''; moreBox.textContent = 'Loading…'; }
    }
    function hero(r) {
      var hb = el('div', 'hero'), im = el('img'); im.alt = '';
      im.src = 'https://i.ytimg.com/vi/' + r.id + '/maxresdefault.jpg';
      im.onload = function () { if (im.naturalWidth && im.naturalWidth < 400) im.src = 'https://i.ytimg.com/vi/' + r.id + '/hqdefault.jpg'; };
      im.onerror = function () { if (!im.dataset.f) { im.dataset.f = 1; im.src = 'https://i.ytimg.com/vi/' + r.id + '/hqdefault.jpg'; } };
      hb.appendChild(im);
      var inn = el('div', 'in'); inn.appendChild(el('div', 'k', 'FEATURED'));
      inn.appendChild(el('h1', '', r.t));
      inn.appendChild(el('p', '', [r.ch, r.meta, r.dur].filter(Boolean).join(' · ')));
      var p = el('a', 'play', '▶  Play'); p.href = '/watch?v=' + r.id; inn.appendChild(p);
      hb.appendChild(inn); heroBox.textContent = ''; heroBox.appendChild(hb);
    }
    function newRail(title, cls) {
      var row = el('div', 'row'); row.appendChild(el('h2', '', title));
      var rail = el('div', 'rail' + (cls ? ' ' + cls : '')); row.appendChild(rail);
      return { row: row, rail: rail };
    }
    function render() {
      if (!ui) return;
      var res = isResults();
      if (!res && !heroDone && vids.length) { hero(vids[0]); heroDone = true; vRendered = 1; }
      if (res) {
        if (!gridBox.firstChild) { gridBox.className = 'grid'; }
        while (vRendered < vids.length) gridBox.appendChild(card(vids[vRendered++]));
      } else {
        while (vRendered < vids.length) {
          if (!curRail || railCount >= 10) {
            var n = newRail(RN[railN % RN.length]); railN++; railCount = 0; curRail = n.rail; railsBox.appendChild(n.row);
            if (railN === 1 && shorts.length >= 2 && !shortRail) addShortRail();
          }
          curRail.appendChild(card(vids[vRendered++])); railCount++;
        }
        if (!shortRail && shorts.length >= 2 && curRail) addShortRail();
      }
      if (shortRail) while (sRendered < shorts.length) shortRail.appendChild(card(shorts[sRendered++]));
      moreBox.textContent = vids.length ? 'Loading more…' : (Date.now() - startedAt > 9000 ? 'Nothing to show here yet. Try the Classic view, or sign in on YouTube.' : 'Loading…');
    }
    function addShortRail() {
      var n = newRail('Shorts', 'sh'); shortRail = n.rail; sRendered = 0;
      if (railsBox.firstChild && railsBox.firstChild.nextSibling) railsBox.insertBefore(n.row, railsBox.firstChild.nextSibling); else railsBox.appendChild(n.row);
    }
    var startedAt = Date.now();
    function grow() {
      if (!ui || !ui.classList.contains('on') || Date.now() - lastLoad < 1400) return;
      if (ui.scrollHeight - ui.scrollTop - ui.clientHeight < 1400) {
        lastLoad = Date.now();
        try { window.scrollTo(0, document.documentElement.scrollHeight); var s = document.scrollingElement; if (s) s.scrollTop = s.scrollHeight; } catch (e) { }
      }
    }

    /* ---------------- the switch ---------------- */
    var bar = null;
    function mkBar() {
      bar = el('div'); bar.id = 'nbc-bar';
      [['off', 'Classic'], ['cinema', 'Cinema'], ['shorts', 'Shorts']].forEach(function (m) {
        var b = el('button', '', m[1]); b.setAttribute('data-m', m[0]);
        b.addEventListener('click', function (e) {
          e.preventDefault(); e.stopPropagation();
          if (m[0] === 'shorts') { location.href = '/shorts'; return; }
          ls('nbcine', m[0]);
          if (onShorts()) location.href = '/'; else tick(true);
        }, true);
        bar.appendChild(b);
      });
      document.documentElement.appendChild(bar);
    }
    function sweep(on) {
      var as, i, c;
      if (on) {
        as = document.querySelectorAll('a[href*="/shorts/"]');
        for (i = 0; i < as.length; i++) {
          if (as[i].closest('#nbt')) continue;
          c = as[i].closest('ytd-rich-item-renderer,ytd-video-renderer,ytd-grid-video-renderer,ytd-compact-video-renderer,ytm-video-with-context-renderer,ytm-compact-video-renderer,ytm-rich-item-renderer,ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2');
          if (c && !c.hasAttribute('data-nbh')) { c.setAttribute('data-nbh', '1'); c.style.setProperty('display', 'none', 'important'); }
        }
      } else {
        as = document.querySelectorAll('[data-nbh]');
        for (i = 0; i < as.length; i++) { as[i].style.removeProperty('display'); as[i].removeAttribute('data-nbh'); }
      }
    }
    function tick(force) {
      try {
        var de = document.documentElement;
        if (!de) return;
        if (!document.getElementById('nbc-css')) { var st = el('style'); st.id = 'nbc-css'; st.textContent = css; (document.head || de).appendChild(st); var hs = el('style'); hs.id = 'nbc-has'; hs.textContent = hasList.map(function (x) { return D + x; }).join(',') + ',' + plain.map(function (x) { return D + x; }).join(',') + '{display:none!important}'; (document.head || de).appendChild(hs); }
        if (!bar) mkBar();
        var cn = cinema() && !onShorts();
        if (de.classList.contains('nb-cn') !== cn) de.classList.toggle('nb-cn', cn);
        sweep(cn);
        var k = P() + location.search;
        if (k !== key) { key = k; startedAt = Date.now(); hold = Date.now() + 1100; clearItems(); if (input) { var q = /[?&]search_query=([^&]*)/.exec(location.search); input.value = q ? decodeURIComponent(q[1].replace(/\+/g, ' ')) : ''; } }
        var show = cn && browse() && !document.fullscreenElement;
        if (show) { build(); }
        if (ui) {
          ui.classList.toggle('on', show);
          if (show) {
            if (Date.now() > hold) { scan(); render(); grow(); }
            var ts = ui.querySelectorAll('.tabs a');
            for (var i = 0; i < ts.length; i++) ts[i].className = ts[i].getAttribute('data-p') === P() ? 'on' : '';
          }
        }
        var cur = onShorts() ? 'shorts' : (cinema() ? 'cinema' : 'off');
        for (var q2 = 0; q2 < bar.children.length; q2++) bar.children[q2].className = bar.children[q2].getAttribute('data-m') === cur ? 'on' : '';
        bar.style.display = document.fullscreenElement ? 'none' : '';
      } catch (e) { }
    }
    tick();
    setInterval(tick, 700);
    document.addEventListener('yt-navigate-finish', function () { hold = Date.now() + 500; tick(); });
  } catch (e) { }
})();
