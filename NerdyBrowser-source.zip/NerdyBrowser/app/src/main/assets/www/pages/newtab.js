(function () {
  'use strict';
  function get(k, d) { try { var v = localStorage.getItem('nb_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  var S = get('settings', {}), BM = get('bookmarks', []), ST = get('stats', { blocked: 0, since: Date.now() }), FAV = get('fav', {});
  var root = document.documentElement;
  root.dataset.theme = S.theme || 'sunrise';
  if (/^#[0-9a-f]{6}$/i.test(S.accent || '')) { root.style.setProperty('--acc2', S.accent); root.style.setProperty('--acc', S.accent); }
  document.body.className = S.ntStyle === 'plain' ? 'plain' : (S.ntStyle === 'grid' ? 'grid' : '');
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  var SVGNS = 'http://www.w3.org/2000/svg';
  function icon(paths, cls) {
    var s = document.createElementNS(SVGNS, 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'i' + (cls ? ' ' + cls : ''));
    paths.forEach(function (d) { var p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', d); s.appendChild(p); });
    return s;
  }
  function host(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }

  /* ---------- search ---------- */
  var E = {
    ddg: ['DuckDuckGo', 'https://duckduckgo.com/?q=%s'], brave: ['Brave Search', 'https://search.brave.com/search?q=%s'],
    startpage: ['Startpage', 'https://www.startpage.com/do/search?q=%s'], ecosia: ['Ecosia', 'https://www.ecosia.org/search?q=%s'],
    qwant: ['Qwant', 'https://www.qwant.com/?q=%s'], mojeek: ['Mojeek', 'https://www.mojeek.com/search?q=%s'],
    google: ['Google', 'https://www.google.com/search?q=%s'], bing: ['Bing', 'https://www.bing.com/search?q=%s'], custom: ['Custom', '']
  };
  var eng = E[S.engine] || E.ddg, tpl = S.engine === 'custom' ? (S.customEngine || '') : eng[1];
  if (!tpl || tpl.indexOf('%s') < 0) { tpl = E.ddg[1]; eng = E.ddg; }
  $('eng').textContent = 'Private search with ' + eng[0];
  $('f').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('q').value.trim();
    if (!v) return;
    var u;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) u = v;
    else if (!/\s/.test(v) && /^[^\s\/]+\.[a-z]{2,}([:\/?#].*)?$/i.test(v)) u = 'https://' + v;
    else u = tpl.replace('%s', encodeURIComponent(v));
    location.href = u;
  });

  /* ---------- header and greeting ---------- */
  var now = new Date(), h = now.getHours();
  var g = h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 22 ? 'Good evening' : 'Late night';
  $('gr').textContent = g;
  var nm = (S.ntName || '').trim(), hi = $('hi'), sp = el('span', '', nm || 'Welcome back');
  hi.appendChild(sp);
  $('date').textContent = now.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  if (S.ntStats !== false && ST) {
    var n = ST.blocked || 0;
    $('shp').hidden = false;
    $('sn').textContent = n >= 10000 ? (n / 1000).toFixed(n >= 100000 ? 0 : 1) + 'k' : n.toLocaleString();
    $('shp').title = 'Ads and trackers stopped since ' + new Date(ST.since || Date.now()).toLocaleDateString() + ', counted only on this phone';
  }

  /* ---------- quick actions ---------- */
  var QA = [
    ['downloads', 'Downloads', '#3B82F6', ['M12 4v11', 'M8 11l4 4 4-4', 'M5 20h14']],
    ['bookmarks', 'Bookmarks', '#F59E0B', ['M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z']],
    ['history', 'History', '#8B5CF6', ['M12 7v5l3 2', 'M4 12a8 8 0 1 0 2.4-5.7', 'M4 4v4h4']],
    ['tabs', 'Tabs', '#10B981', ['M4 8l8-4 8 4-8 4z', 'M4 12l8 4 8-4', 'M4 16l8 4 8-4']],
    ['vpn', 'VPN', '#EF4F63', ['M7 11V8a5 5 0 0 1 10 0v3', 'M5 11h14v9H5z']],
    ['settings', 'Settings', '#64748B', ['M4 7h10', 'M18 7h2', 'M4 17h2', 'M10 17h10', 'M14 5v4', 'M8 15v4']]
  ];
  QA.forEach(function (q) {
    var a = el('a'); a.href = 'nb-act://' + q[0]; a.style.setProperty('--q', q[2]);
    var ic = el('span', 'ic'); ic.appendChild(icon(q[3])); a.appendChild(ic); a.appendChild(el('span', '', q[1]));
    $('qa').appendChild(a);
  });

  /* ---------- shortcuts ---------- */
  (function () {
    if (S.ntDial === false) return;
    var pins = BM.filter(function (b) { return b.pin; }).slice(0, 8);
    if (!pins.length) return;
    $('dialS').hidden = false;
    pins.forEach(function (b) {
      var hs = host(b.url), a = el('a'); a.href = b.url;
      var i = el('i'), f = FAV[hs];
      if (typeof f === 'string' && f.indexOf('data:') === 0) { i.className = 'fv'; var im = document.createElement('img'); im.alt = ''; im.src = f; i.appendChild(im); }
      else {
        var hue = 0; for (var k = 0; k < hs.length; k++) hue = (hue * 31 + hs.charCodeAt(k)) % 360;
        i.style.setProperty('--c', 'hsl(' + hue + ' 62% 52%)'); i.textContent = (hs || b.title || '?').charAt(0);
      }
      a.appendChild(i); a.appendChild(el('span', '', b.title || hs)); $('dial').appendChild(a);
    });
  })();

  /* ---------- tip ---------- */
  var TIPS = [
    ['Burn button', 'Menu, then Burn all, closes every tab and wipes cookies, site data and cache in one tap.'],
    ['Split screen', 'Tap the panes icon to see two, three or four pages at once. Long-press a link to open it in the other pane.'],
    ['Reader mode', 'Menu, then Reader mode, strips a page down to the article, with no ads and no clutter.'],
    ['Shield level', 'Ultra blocks every third-party script. If a site breaks, turn the shield off for that site only.'],
    ['Clean links', 'NerdyBrowser removes utm_ and fbclid junk from links before opening them.'],
    ['JavaScript off', 'For the safest reading, switch JavaScript off for a single tab from the menu.'],
    ['Your IP', 'No browser hides your network address by itself. Pair this with a VPN or private DNS for that.'],
    ['Zoom', 'Zoom is remembered per site, so a small-print site can be big while others stay normal.'],
    ['Pin shortcuts', 'Pin a bookmark and it shows up on this page as a shortcut.'],
    ['App lock', 'In Settings, Device, turn on phone-unlock to open the browser, for a quick extra lock.']
  ];
  if (S.ntTips !== false) {
    var t = TIPS[Math.floor(Date.now() / 86400000) % TIPS.length], tp = $('tip');
    tp.hidden = false;
    tp.appendChild(icon(['M9 18h6', 'M10 21h4', 'M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z']));
    var d = el('div'); d.appendChild(el('b', '', t[0] + '. ')); d.appendChild(document.createTextNode(t[1])); tp.appendChild(d);
  }

  /* ---------- Markets ---------- */
  (function () {
    if (S.ntMarkets === false) return;
    var sec = $('mk'); sec.hidden = false;
    var G = { all: 'All', in: 'India', us: 'US', as: 'Asia', eu: 'Europe', cm: 'Commodities', cr: 'Crypto' };
    var tab = 'in', data = [], prev = {}, stamp = 0, expanded = false, FIRST = 4;
    try { tab = localStorage.getItem('nb_mktab') || 'in'; } catch (e) { }
    var elT = $('mtabs'), elR = $('mrow'), elS = $('ms'), elM = $('md'), elMore = $('mmore');
    function fmt(q) {
      var p = q.p, dg = Math.abs(p) >= 1000 ? 2 : (Math.abs(p) < 10 ? 4 : 2);
      if (q.g === 'cr' && p >= 100) dg = 2; if (q.g === 'cr' && p < 10) dg = 4;
      var loc = q.g === 'in' ? 'en-IN' : 'en-US';
      var tx = p.toLocaleString(loc, { minimumFractionDigits: dg, maximumFractionDigits: dg });
      return (q.g === 'cm' && q.s !== 'DX-Y.NYB' || q.g === 'cr') ? '$' + tx : tx;
    }
    function drawTabs() {
      elT.textContent = '';
      Object.keys(G).forEach(function (k) {
        var b = el('button', tab === k ? 'on' : '', G[k]);
        b.onclick = function () { tab = k; expanded = false; try { localStorage.setItem('nb_mktab', k); } catch (e) { } drawTabs(); drawCards(false); };
        elT.appendChild(b);
      });
    }
    function drawMood() {
      elM.textContent = '';
      var up = 0, dn = 0; data.forEach(function (q) { if (q.pc > 0) up++; else if (q.pc < 0) dn++; });
      if (!up && !dn) return;
      var a = el('i'); a.style.background = '#12a863'; a.style.flex = up || 0.01;
      var b = el('i'); b.style.background = '#e5384f'; b.style.flex = dn || 0.01;
      elM.appendChild(a); elM.appendChild(b);
    }
    function drawCards(anim) {
      elR.textContent = '';
      var l = data.filter(function (q) { return tab === 'all' || q.g === tab; });
      var list = expanded ? l : l.slice(0, FIRST);
      list.forEach(function (q) {
        var a = el('a', 'qc ' + (q.pc > 0 ? 'up' : q.pc < 0 ? 'dn' : 'fl'));
        a.href = 'https://finance.yahoo.com/quote/' + encodeURIComponent(q.s); a.rel = 'noopener';
        a.appendChild(el('small', '', q.n));
        a.appendChild(el('b', '', fmt(q)));
        var pct = q.pc == null ? '—' : (q.pc > 0 ? '▲ +' : q.pc < 0 ? '▼ ' : '') + Math.abs(q.pc).toFixed(2) + '%';
        a.appendChild(el('em', '', pct));
        if (q.c != null) a.appendChild(el('span', 'ab', (q.c >= 0 ? '+' : '−') + Math.abs(q.c).toLocaleString('en-US', { maximumFractionDigits: Math.abs(q.p) < 10 ? 4 : 2 })));
        if (anim && prev[q.s] != null && prev[q.s] !== q.p) a.classList.add('flash');
        elR.appendChild(a);
      });
      elMore.hidden = l.length <= FIRST;
      elMore.textContent = expanded ? 'Show fewer' : 'Show all ' + l.length;
    }
    elMore.onclick = function () { expanded = !expanded; drawCards(false); };
    window.__nbQuotes = function (d) {
      try {
        if (!d || !d.q || !d.q.length) return;
        var old = {}; data.forEach(function (q) { old[q.s] = q.p; }); prev = old;
        data = d.q; stamp = d.t || Date.now();
        var tm = new Date(stamp);
        elS.textContent = 'Delayed prices · updated ' + tm.getHours() + ':' + ('0' + tm.getMinutes()).slice(-2) + ' · tap a card for the chart';
        drawMood(); drawTabs(); drawCards(true);
      } catch (e) { }
    };
    drawTabs();
    setTimeout(function () { if (!data.length) elS.textContent = 'Could not load prices yet. They refresh by themselves.'; }, 20000);
  })();

  /* ---------- Discover: news ---------- */
  (function () {
    if (S.ntNews === false) return;
    $('news').hidden = false;
    var CATS = {
      in: ['India', '#F97316'], mk: ['Markets', '#D99A00'], tc: ['Tech', '#6366F1'], au: ['Auto', '#4C9A2A'],
      wd: ['World', '#9B51E0'], sp: ['Sports', '#EF4444'], cr: ['Crypto', '#DB2777'], en: ['Showbiz', '#E8728A']
    };
    var KEYS = ['in', 'mk', 'tc', 'wd', 'au', 'sp', 'cr', 'en'];
    var items = [], cat = '', shown = 0, rest = [], STEP = 8, seen = +get('newsseen', 0) || 0, stamp = 0;
    try { cat = localStorage.getItem('nb_newscat') || ''; } catch (e) { }
    var elChips = $('chips'), elFeat = $('feat'), elCar = $('car'), elList = $('nl'), elLd = $('ld'), elSub = $('ns'), elSq = $('sq');

    function ago(ts) {
      var m = Math.max(0, Math.round((Date.now() - ts) / 60000));
      if (m < 1) return 'just now'; if (m < 60) return m + ' min ago';
      var hh = Math.round(m / 60); if (hh < 24) return hh + ' h ago';
      return Math.round(hh / 24) + ' d ago';
    }
    function k(c) { return CATS[c] || CATS.in; }
    function link(a, it) { a.href = it.l; a.rel = 'noopener'; a.style.setProperty('--c', k(it.c)[1]); }
    function pic(it, eager) {
      var f = document.createDocumentFragment();
      f.appendChild(el('div', 'ph', (it.s || '?').charAt(0)));
      if (it.im) {
        var im = document.createElement('img'); im.className = 'im'; im.alt = ''; im.decoding = 'async';
        if (!eager) im.loading = 'lazy';
        im.onerror = function () { if (im.parentNode) im.parentNode.removeChild(im); };
        im.src = it.im; f.appendChild(im);
      }
      return f;
    }
    function filtered() { return items.filter(function (x) { return !cat || x.c === cat; }); }

    function drawChips() {
      elChips.textContent = '';
      var counts = {}; items.forEach(function (x) { counts[x.c] = (counts[x.c] || 0) + 1; });
      var all = el('button', 'ch all' + (cat ? '' : ' on'), 'For you'); all.onclick = function () { setCat(''); }; elChips.appendChild(all);
      KEYS.forEach(function (c) {
        if (!counts[c]) return;
        var b = el('button', 'ch' + (cat === c ? ' on' : '')); b.style.setProperty('--c', CATS[c][1]);
        b.appendChild(el('i')); b.appendChild(document.createTextNode(CATS[c][0]));
        b.onclick = function () { setCat(cat === c ? '' : c); }; elChips.appendChild(b);
      });
    }
    function setCat(c) { cat = c; try { localStorage.setItem('nb_newscat', c); } catch (e) { } drawAll(); }

    function drawTop() {
      elFeat.textContent = ''; elCar.textContent = '';
      var l = filtered().slice(), used = {};
      var withIm = l.filter(function (x) { return x.im; });
      var f = withIm[0] || l[0];
      if (f) {
        var a = el('a', 'feat'); link(a, f); used[f.l] = 1;
        a.appendChild(pic(f, true)); a.appendChild(el('span', 'tag', k(f.c)[0])); a.appendChild(el('b', '', f.t));
        a.appendChild(el('span', 'mt', f.s + ' · ' + ago(f.ts)));
        elFeat.appendChild(a);
      }
      var cs = (withIm.length >= 3 ? withIm : l).filter(function (x) { return !used[x.l]; }).slice(0, 5);
      cs.forEach(function (it) {
        used[it.l] = 1;
        var a = el('a', 'cc'); link(a, it);
        a.appendChild(pic(it)); a.appendChild(el('span', 'tag', k(it.c)[0])); a.appendChild(el('b', '', it.t));
        a.appendChild(el('span', 'mt', it.s + ' · ' + ago(it.ts)));
        elCar.appendChild(a);
      });
      $('carH').hidden = !cs.length; elCar.hidden = !cs.length;
      rest = l.filter(function (x) { return !used[x.l]; });
      $('lstH').hidden = !rest.length;
    }

    function card(it, i) {
      var big = i % 6 === 3 && it.im;
      var a = el('a', 'nc' + (big ? ' big' : '')); link(a, it);
      a.style.animationDelay = (i % STEP) * 40 + 'ms';
      var tx = el('div', 'tx');
      tx.appendChild(el('span', 'cat', k(it.c)[0]));
      var b = el('b', '');
      if (it.ts > seen) b.appendChild(el('span', 'nw', 'NEW'));
      b.appendChild(document.createTextNode(it.t)); tx.appendChild(b);
      tx.appendChild(el('span', 'm', it.s + ' · ' + ago(it.ts)));
      var th = el('div', 'th'); th.appendChild(pic(it));
      a.appendChild(tx); a.appendChild(th);
      return a;
    }
    function more() {
      var end = Math.min(rest.length, shown + STEP);
      for (var i = shown; i < end; i++) elList.appendChild(card(rest[i], i));
      shown = end;
      if (shown < rest.length) elLd.textContent = 'Showing ' + (shown + (filtered().length - rest.length)) + ' of ' + filtered().length + ' · scroll for more';
      else elLd.textContent = filtered().length ? 'You are all caught up (' + filtered().length + ' stories). Tap Refresh for more.' : 'Nothing in this topic yet.';
    }
    function drawAll() {
      drawChips(); drawTop();
      elList.textContent = ''; shown = 0; more();
      if (stamp) elSub.textContent = 'India, world, tech, auto and markets · updated ' + ago(stamp);
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { if (es[0].isIntersecting && items.length && shown < rest.length) more(); }, { rootMargin: '400px' }).observe(elLd);
    }
    window.__nbNews = function (d) {
      try {
        if (!d || !d.items || !d.items.length) return;
        items = d.items; stamp = d.t || Date.now();
        drawAll();
        var newest = 0; items.forEach(function (x) { if (x.ts > newest) newest = x.ts; });
        try { localStorage.setItem('nb_newsseen', JSON.stringify(newest)); } catch (e) { }
      } catch (e) { }
    };
    window.__nbBusy = function (b) {
      elSq.className = 'rb' + (b ? ' busy' : '');
      if (!items.length) {
        if (b) {
          if (!elFeat.firstChild) { elFeat.appendChild(el('div', 'sk f')); for (var i = 0; i < 3; i++) elList.appendChild(el('div', 'sk')); }
        } else { elFeat.textContent = ''; elList.textContent = ''; elLd.textContent = 'Could not reach the news sources. Check your connection, then tap Refresh.'; elSub.textContent = 'No stories yet'; }
      }
    };
  })();
})();
