'use strict';
(function () {
  function get(k, d) { try { var v = localStorage.getItem('nb_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  var S = get('settings', {}), BM = get('bookmarks', []), ST = get('stats', { blocked: 0, since: Date.now() });
  var root = document.documentElement;
  root.dataset.theme = S.theme || 'sunrise';
  if (/^#[0-9a-f]{6}$/i.test(S.accent || '')) { root.style.setProperty('--acc2', S.accent); root.style.setProperty('--acc', S.accent); }
  document.body.className = S.ntStyle === 'plain' ? '' : (S.ntStyle === 'grid' ? 'grid' : 'glow');

  var E = {
    ddg: ['DuckDuckGo', 'https://duckduckgo.com/?q=%s'], brave: ['Brave Search', 'https://search.brave.com/search?q=%s'],
    startpage: ['Startpage', 'https://www.startpage.com/do/search?q=%s'], ecosia: ['Ecosia', 'https://www.ecosia.org/search?q=%s'],
    qwant: ['Qwant', 'https://www.qwant.com/?q=%s'], mojeek: ['Mojeek', 'https://www.mojeek.com/search?q=%s'],
    google: ['Google', 'https://www.google.com/search?q=%s'], bing: ['Bing', 'https://www.bing.com/search?q=%s'], custom: ['Custom', '']
  };
  var eng = E[S.engine] || E.ddg, tpl = S.engine === 'custom' ? (S.customEngine || '') : eng[1];
  if (!tpl || tpl.indexOf('%s') < 0) { tpl = E.ddg[1]; eng = E.ddg; }
  document.getElementById('eng').textContent = 'Searching with ' + eng[0];

  var h = new Date().getHours();
  var g = h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 22 ? 'Good evening' : 'Late night';
  document.getElementById('hi').textContent = g + (S.ntName ? ', ' + S.ntName : '') + '. Nobody is following you here.';

  document.getElementById('f').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = document.getElementById('q').value.trim();
    if (!v) return;
    var u;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) u = v;
    else if (!/\s/.test(v) && /^[^\s\/]+\.[a-z]{2,}([:\/?#].*)?$/i.test(v)) u = 'https://' + v;
    else u = tpl.replace('%s', encodeURIComponent(v));
    location.href = u;
  });

  function host(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  var dial = document.getElementById('dial');
  if (S.ntDial === false) dial.hidden = true;
  else {
    var pins = BM.filter(function (b) { return b.pin; }).slice(0, 8);
    pins.forEach(function (b) {
      var a = document.createElement('a'); a.href = b.url;
      var i = document.createElement('i'); i.textContent = (host(b.url) || b.title || '?').charAt(0);
      var s = document.createElement('span'); s.textContent = b.title;
      a.appendChild(i); a.appendChild(s); dial.appendChild(a);
    });
    if (!pins.length) dial.hidden = true;
  }

  var st = document.getElementById('stats');
  if (S.ntStats !== false && ST) {
    st.hidden = false;
    document.getElementById('sn').textContent = (ST.blocked || 0).toLocaleString();
    document.getElementById('ss').textContent = 'since ' + new Date(ST.since || Date.now()).toLocaleDateString() + ', counted only on this phone';
  }

  var TIPS = [
    ['Burn button', 'Menu, then Burn all, closes every tab and wipes cookies, site data and cache in one tap.'],
    ['Split screen', 'Tap the panes icon to see two, three or four pages at once. Long-press a link to open it in the other pane.'],
    ['Reader mode', 'Menu, then Reader mode, strips a page down to the article, with no ads and no clutter.'],
    ['Shield level', 'Ultra blocks every third-party script. If a site breaks, turn the shield off for that site only.'],
    ['Clean links', 'NerdyBrowser removes utm_ and fbclid junk from links before opening them.'],
    ['JavaScript off', 'For the safest reading, switch JavaScript off for a single tab from the menu.'],
    ['Your IP', 'No browser hides your network address by itself. Pair this with a VPN or private DNS for that.'],
    ['Zoom', 'Zoom is remembered per site, so a small-print site can be big while others stay normal.'],
    ['Pin shortcuts', 'Pin a bookmark and it shows up on this page as a shortcut.'],
    ['App lock', 'In Settings, Device, turn on phone-unlock to open the browser, for a quick extra lock.']
  ];
  var tip = document.getElementById('tip');
  if (S.ntTips !== false) {
    var t = TIPS[Math.floor(Date.now() / 86400000) % TIPS.length];
    tip.hidden = false;
    var b = document.createElement('b'); b.textContent = t[0] + ': ';
    tip.appendChild(b); tip.appendChild(document.createTextNode(t[1]));
  }
})();
