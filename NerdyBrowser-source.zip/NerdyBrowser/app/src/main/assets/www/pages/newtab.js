'use strict';
(function () {
  function get(k, d) { try { var v = localStorage.getItem('nb_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  var S = get('settings', {}), BM = get('bookmarks', []), ST = get('stats', { blocked: 0, since: Date.now() });
  var root = document.documentElement;
  root.dataset.theme = S.theme || 'sunrise';
  if (/^#[0-9a-f]{6}$/i.test(S.accent || '')) { root.style.setProperty('--acc2', S.accent); root.style.setProperty('--acc', S.accent); }
  document.body.className = S.ntStyle === 'plain' ? '' : (S.ntStyle === 'grid' ? 'grid' : 'glow');

  var E = {
    ddg: ['DuckDuckGo', 'https://duckduckgo.com/?q=%s'], brave: ['Brave Search', 'https://search.brave.com/search?q=%s'],
    startpage: ['Startpage', 'https://www.startpage.com/do/search?q=%s'], ecosia: ['Ecosia', 'https://www.ecosia.org/search?q=%s'],
    qwant: ['Qwant', 'https://www.qwant.com/?q=%s'], mojeek: ['Mojeek', 'https://www.mojeek.com/search?q=%s'],
    google: ['Google', 'https://www.google.com/search?q=%s'], bing: ['Bing', 'https://www.bing.com/search?q=%s'], custom: ['Custom', '']
  };
  var eng = E[S.engine] || E.ddg, tpl = S.engine === 'custom' ? (S.customEngine || '') : eng[1];
  if (!tpl || tpl.indexOf('%s') < 0) { tpl = E.ddg[1]; eng = E.ddg; }
  document.getElementById('eng').textContent = 'Searching with ' + eng[0];

  var h = new Date().getHours();
  var g = h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 22 ? 'Good evening' : 'Late night';
  document.getElementById('hi').textContent = g + (S.ntName ? ', ' + S.ntName : '') + '. Nobody is following you here.';

  document.getElementById('f').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = document.getElementById('q').value.trim();
    if (!v) return;
    var u;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) u = v;
    else if (!/\s/.test(v) && /^[^\s\/]+\.[a-z]{2,}([:\/?#].*)?$/i.test(v)) u = 'https://' + v;
    else u = tpl.replace('%s', encodeURIComponent(v));
    location.href = u;
  });

  function host(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  var dial = document.getElementById('dial');
  if (S.ntDial === false) dial.hidden = true;
  else {
    var pins = BM.filter(function (b) { return b.pin; }).slice(0, 8);
    pins.forEach(function (b) {
      var a = document.createElement('a'); a.href = b.url;
      var i = document.createElement('i'); i.textContent = (host(b.url) || b.title || '?').charAt(0);
      var s = document.createElement('span'); s.textContent = b.title;
      a.appendChild(i); a.appendChild(s); dial.appendChild(a);
    });
    if (!pins.length) dial.hidden = true;
  }

  var st = document.getElementById('stats');
  if (S.ntStats !== false && ST) {
    st.hidden = false;
    document.getElementById('sn').textContent = (ST.blocked || 0).toLocaleString();
    document.getElementById('ss').textContent = 'since ' + new Date(ST.since || Date.now()).toLocaleDateString() + ', counted only on this phone';
  }

  var TIPS = [
    ['Burn button', 'Menu, then Burn all, closes every tab and wipes cookies, site data and cache in one tap.'],
    ['Split screen', 'Tap the panes icon to see two, three or four pages at once. Long-press a link to open it in the other pane.'],
    ['Reader mode', 'Menu, then Reader mode, strips a page down to the article, with no ads and no clutter.'],
    ['Shield level', 'Ultra blocks every third-party script. If a site breaks, turn the shield off for that site only.'],
    ['Clean links', 'NerdyBrowser removes utm_ and fbclid junk from links before opening them.'],
    ['JavaScript off', 'For the safest reading, switch JavaScript off for a single tab from the menu.'],
    ['Your IP', 'No browser hides your network address by itself. Pair this with a VPN or private DNS for that.'],
    ['Zoom', 'Zoom is remembered per site, so a small-print site can be big while others stay normal.'],
    ['Pin shortcuts', 'Pin a bookmark and it shows up on this page as a shortcut.'],
    ['App lock', 'In Settings, Device, turn on phone-unlock to open the browser, for a quick extra lock.']
  ];
  var tip = document.getElementById('tip');
  if (S.ntTips !== false) {
    var t = TIPS[Math.floor(Date.now() / 86400000) % TIPS.length];
    tip.hidden = false;
    var b = document.createElement('b'); b.textContent = t[0] + ': ';
    tip.appendChild(b); tip.appendChild(document.createTextNode(t[1]));
  }


  /* ---------- Market Band: indices, commodities, crypto ---------- */
  (function () {
    var sec = document.getElementById('mk');
    if (S.ntMarkets === false) return;
    sec.hidden = false;
    var G = { all: ['🌐', 'All'], in: ['🇮🇳', 'India'], us: ['🇺🇸', 'US'], as: ['🌏', 'Asia'], eu: ['🇪🇺', 'Europe'], cm: ['🛢️', 'Commodities'], cr: ['₿', 'Crypto'] };
    var tab = 'in', data = [], prev = {}, stamp = 0;
    try { tab = localStorage.getItem('nb_mktab') || 'in'; } catch (e) { }
    var elT = document.getElementById('mtabs'), elR = document.getElementById('mrow'), elS = document.getElementById('ms'), elM = document.getElementById('md');
    function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
    function fmt(q) {
      var p = q.p, d = Math.abs(p) >= 1000 ? 2 : (Math.abs(p) < 10 ? 4 : 2);
      if (q.g === 'cr' && p >= 100) d = 2; if (q.g === 'cr' && p < 10) d = 4;
      var loc = q.g === 'in' ? 'en-IN' : 'en-US';
      var t = p.toLocaleString(loc, { minimumFractionDigits: d, maximumFractionDigits: d });
      return (q.g === 'cm' && q.s !== 'DX-Y.NYB' || q.g === 'cr') ? '$' + t : t;
    }
    function drawTabs() {
      elT.textContent = '';
      Object.keys(G).forEach(function (k) {
        var b = el('button', 'ch' + (tab === k ? ' on' : ''), G[k][0] + ' ' + G[k][1]);
        b.onclick = function () { tab = k; try { localStorage.setItem('nb_mktab', k); } catch (e) { } drawTabs(); drawCards(false); };
        elT.appendChild(b);
      });
    }
    function drawMood() {
      elM.textContent = '';
      var up = 0, dn = 0; data.forEach(function (q) { if (q.pc > 0) up++; else if (q.pc < 0) dn++; });
      if (!up && !dn) return;
      var a = el('i'); a.style.background = '#1FBF75'; a.style.flex = up || 0.01;
      var b = el('i'); b.style.background = '#EF4F63'; b.style.flex = dn || 0.01;
      elM.appendChild(a); elM.appendChild(b);
    }
    function drawCards(anim) {
      elR.textContent = '';
      data.filter(function (q) { return tab === 'all' || q.g === tab; }).forEach(function (q) {
        var a = el('a', 'qc ' + (q.pc > 0 ? 'up' : q.pc < 0 ? 'dn' : ''));
        a.href = 'https://finance.yahoo.com/quote/' + encodeURIComponent(q.s); a.rel = 'noopener';
        a.appendChild(el('small', '', q.n));
        a.appendChild(el('b', '', fmt(q)));
        var ch = q.c == null ? '—' : (q.c >= 0 ? '▲ +' : '▼ ') + Math.abs(q.c).toLocaleString('en-US', { maximumFractionDigits: Math.abs(q.p) < 10 ? 4 : 2 }) + '  (' + (q.pc >= 0 ? '+' : '') + q.pc.toFixed(2) + '%)';
        a.appendChild(el('span', '', ch));
        if (anim && prev[q.s] != null && prev[q.s] !== q.p) a.classList.add('flash');
        elR.appendChild(a);
      });
    }
    window.__nbQuotes = function (d) {
      try {
        if (!d || !d.q || !d.q.length) return;
        var old = {}; data.forEach(function (q) { old[q.s] = q.p; }); prev = old;
        data = d.q; stamp = d.t || Date.now();
        var t = new Date(stamp);
        elS.textContent = 'Delayed prices · updated ' + t.getHours() + ':' + ('0' + t.getMinutes()).slice(-2) + ' · tap a card for the full chart';
        drawMood(); drawTabs(); drawCards(true);
      } catch (e) { }
    };
    drawTabs();
    setTimeout(function () { if (!data.length) elS.textContent = 'Could not load prices yet. Check your connection; they refresh by themselves.'; }, 20000);
  })();

  /* ---------- The Juice Bar: a mixed news blend ---------- */
  (function () {
    var sec = document.getElementById('news');
    if (S.ntNews === false) return;
    sec.hidden = false;
    var CATS = {
      in: ['🍊', 'India', '#FF8A3D'], mk: ['🥭', 'Markets', '#E8A600'], tc: ['🫐', 'Tech', '#6C63FF'],
      au: ['🍏', 'Auto', '#5FA52B'], wd: ['🍇', 'World', '#9B51E0'], sp: ['🍉', 'Sports', '#EF4F63'],
      cr: ['🍓', 'Crypto', '#E6396B'], en: ['🍑', 'Showbiz', '#E8728A']
    };
    var KEYS = ['in', 'mk', 'tc', 'wd', 'au', 'sp', 'cr', 'en'];
    var items = [], cat = '', shown = 0, STEP = 8, seen = +get('newsseen', 0) || 0, stamp = 0, busy = false, io = null;
    try { cat = localStorage.getItem('nb_newscat') || ''; } catch (e) { }
    var elMeter = document.getElementById('mt'), elChips = document.getElementById('chips'), elHero = document.getElementById('hero'),
      elList = document.getElementById('nl'), elLd = document.getElementById('ld'), elSub = document.getElementById('ns'), elSq = document.getElementById('sq');

    function ago(ts) {
      var m = Math.max(0, Math.round((Date.now() - ts) / 60000));
      if (m < 1) return 'just now'; if (m < 60) return m + ' min ago';
      var h = Math.round(m / 60); if (h < 24) return h + ' h ago';
      return Math.round(h / 24) + ' d ago';
    }
    function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
    function colorOf(c) { return (CATS[c] || CATS.in)[2]; }
    function tagOf(c) { var k = CATS[c] || CATS.in; return el('span', 'tag', k[0] + ' ' + k[1]); }
    function link(a, it) { a.href = it.l; a.rel = 'noopener'; a.style.setProperty('--c', colorOf(it.c)); }

    function filtered() { return items.filter(function (x) { return !cat || x.c === cat; }); }

    function drawChips() {
      elChips.textContent = ''; elMeter.textContent = '';
      var counts = {}; items.forEach(function (x) { counts[x.c] = (counts[x.c] || 0) + 1; });
      var all = el('button', 'ch' + (cat ? '' : ' on'), '🥤 Blend ' + items.length);
      all.onclick = function () { setCat(''); }; elChips.appendChild(all);
      KEYS.forEach(function (k) {
        if (!counts[k]) return;
        var b = el('button', 'ch' + (cat === k ? ' on' : ''), CATS[k][0] + ' ' + CATS[k][1]);
        b.style.setProperty('--c', CATS[k][2]); b.onclick = function () { setCat(cat === k ? '' : k); };
        elChips.appendChild(b);
        var seg = el('i', cat && cat !== k ? 'off' : ''); seg.style.background = CATS[k][2]; seg.style.flex = counts[k];
        seg.onclick = b.onclick; elMeter.appendChild(seg);
      });
    }
    function setCat(c) { cat = c; try { localStorage.setItem('nb_newscat', c); } catch (e) { } drawAll(); }

    function drawHero() {
      elHero.textContent = '';
      var pool = filtered().filter(function (x) { return x.im; }).slice(0, 6);
      if (pool.length < 3) pool = filtered().slice(0, 5);
      pool.forEach(function (it) {
        var a = el('a', 'hc'); link(a, it);
        a.appendChild(el('div', 'bg', CATS[it.c][0]));
        if (it.im) { var im = document.createElement('img'); im.src = it.im; im.alt = ''; a.appendChild(im); }
        a.appendChild(tagOf(it.c)); a.appendChild(el('b', '', it.t)); a.appendChild(el('span', '', it.s + ' · ' + ago(it.ts)));
        elHero.appendChild(a);
      });
      elHero.hidden = !pool.length;
    }

    function card(it, i) {
      var a = el('a', 'nc' + (i % 5 === 3 && it.im ? ' big' : '')); link(a, it);
      a.style.animationDelay = (i % STEP) * 40 + 'ms';
      var th = el('div', 'th');
      if (it.im) { var im = document.createElement('img'); im.src = it.im; im.alt = ''; im.loading = 'lazy'; th.appendChild(im); } else th.textContent = CATS[it.c][0];
      var tx = el('div', 'tx');
      tx.appendChild(tagOf(it.c));
      var b = el('b', ''); if (it.ts > seen) { var n = el('span', 'nw', 'NEW'); n.style.setProperty('--c', colorOf(it.c)); b.appendChild(n); }
      b.appendChild(document.createTextNode(it.t)); tx.appendChild(b);
      tx.appendChild(el('span', 'm', it.s + ' · ' + ago(it.ts)));
      a.appendChild(th); a.appendChild(tx);
      return a;
    }

    function more() {
      var l = filtered(), end = Math.min(l.length, shown + STEP);
      for (var i = shown; i < end; i++) elList.appendChild(card(l[i], i));
      shown = end;
      if (shown < l.length) { elLd.textContent = 'Showing ' + shown + ' of ' + l.length + ' · keep scrolling for more'; }
      else elLd.textContent = l.length ? 'That was the whole blend (' + l.length + ' stories). Tap Fresh squeeze for more.' : 'Nothing in this flavour yet.';
    }

    function drawAll() {
      drawChips(); drawHero();
      elList.textContent = ''; shown = 0; more();
      elSub.textContent = stamp ? 'Mixed from India, the world, tech, auto and markets · updated ' + ago(stamp) : elSub.textContent;
    }

    // progressive loading: the next few stories appear as you reach the end
    function watch() {
      if (!('IntersectionObserver' in window)) return;
      io = new IntersectionObserver(function (es) {
        if (es[0].isIntersecting && items.length && shown < filtered().length) more();
      }, { rootMargin: '300px' });
      io.observe(elLd);
    }

    window.__nbNews = function (d) {
      try {
        if (!d || !d.items || !d.items.length) return;
        items = d.items; stamp = d.t || Date.now();
        drawAll();
        var newest = 0; items.forEach(function (x) { if (x.ts > newest) newest = x.ts; });
        try { localStorage.setItem('nb_newsseen', JSON.stringify(newest)); } catch (e) { }
      } catch (e) { }
    };
    window.__nbBusy = function (b) {
      busy = !!b;
      elSq.className = 'sq' + (b ? ' busy' : '');
      if (!items.length) {
        if (b) {
          if (!elList.firstChild) for (var i = 0; i < 3; i++) elList.appendChild(el('div', 'sk'));
        } else { elList.textContent = ''; elLd.textContent = 'Could not reach the news sources. Check your connection, then tap Fresh squeeze.'; elSub.textContent = 'No blend yet'; }
      }
    };
    watch();
  })();
})();
