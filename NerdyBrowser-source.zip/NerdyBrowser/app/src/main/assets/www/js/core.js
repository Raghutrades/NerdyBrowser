'use strict';
/* ===== NerdyBrowser · core: store, settings, themes, layouts, helpers ===== */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* the Android bridge (a harmless stand-in when this page is opened in a normal browser) */
const HAS_NB = typeof NBAndroid !== 'undefined';
const A = HAS_NB ? NBAndroid : new Proxy({
  get: k => localStorage.getItem('nbv_' + k) || '', set: (k, v) => localStorage.setItem('nbv_' + k, v),
  stats: () => '{"hosts":{},"page":0,"total":0}', state: () => '{}',
}, { get: (o, p) => (p in o ? o[p] : () => { }) });

const HOME_URL = location.origin + '/assets/www/pages/newtab.html';

const Store = {
  get(k, d) { try { const v = A.get(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { const s = JSON.stringify(v); try { A.set(k, s); } catch (e) { } try { localStorage.setItem('nb_' + k, s); } catch (e) { } },
};

/* ---------- settings ---------- */
const DEF = {
  theme: 'sunrise', uiStyle: 'classic', accent: '', toolbarPos: 'top', density: 'normal', tabStrip: true, splash: true, splashStyle: 'clean',
  layout: 'single', ratio: 55, gap: 4, textZoom: 100, pageZoom: 100, siteZoom: {}, forceZoom: true, desktopDefault: false, darkPages: 'off',
  shield: 'standard', popups: 'gesture', blockDialogs: false, cosmetic: true, consent: true, stripParams: true, blockExternal: true,
  blockAutoplay: true, customBlock: [], siteAllow: [], appCompat: true, compatSites: [], ytCinema: true,
  httpsOnly: true, cookies: 'first', spoof: true, noWebrtc: true, noBeacon: true, gpc: true, referrer: 'origin', safeBrowsing: false,
  js: true, images: true, ua: 'default', customUA: '',
  wipeExit: true, noCache: false, saveHistory: false, restoreTabs: false,
  engine: 'ddg', customEngine: '', home: '',
  ntDial: true, ntNews: true, ntMarkets: true, ntTips: true, ntStats: true, ntStyle: 'glow', ntName: '',
  keepScreen: false, secure: false, appLock: false, askDownload: true,
  readerTheme: 'paper', readerFont: 'serif', readerSize: 19,
  autoHide: true, alwaysFull: false, fsBtnAddr: true, fsBtnRow: true, fsBtnStrip: true, cutout: true, desktopWidth: 1280, sleepTabs: true, videoAds: true, hideSelectors: [],
  proxy: '', vpnKill: false, vpnAuto: true, optRow: false, keepLogins: true, signinCompat: true, chromeLook: true, pullRefresh: true, swipeTabs: true, dlSort: true, dlWifiOnly: false, dlSmart: true, dlParallel: '3', dlGlobal: '0', dlEachLimit: '0', dlMedia: true, dlView: 'list', dlPreviews: true, pullClose: true, workspaces: [], edgeSwipe: true, edgeSize: 24, dlButtons: true, customRects: null, basePreset: 'single', splashSound: true, splashVol: 70,
};
let S = Object.assign({}, DEF, Store.get('settings', {}));
if (!S.v32) { S.v32 = 1; S.splashStyle = 'warp'; try { Store.set('settings', S); } catch (e) { } }
if (!S.v33) { S.v33 = 1; S.splashStyle = 'clean'; S.uiStyle = 'island'; S.edgeSwipe = true; try { Store.set('settings', S); } catch (e) { } }
if (!S.v34) { S.v34 = 1; S.alwaysFull = false; S.fsBtnAddr = true; S.fsBtnRow = true; S.fsBtnStrip = true; try { Store.set('settings', S); } catch (e) { } }

function saveSettings() {
  Store.set('settings', S);
  A.settings(JSON.stringify(S));
}

/* ---------- themes ---------- */
const THEMES = {
  sunrise: { n: 'Sunrise', a: '#f0642f', b: '#d6336c', c: '#fff7f0', t: '#2a1f1a' },
  meadow: { n: 'Meadow', a: '#2f9e6f', b: '#1c7c54', c: '#f3fbf5', t: '#17261d' },
  ocean: { n: 'Ocean', a: '#1c8fd0', b: '#0b7285', c: '#f1f8fd', t: '#15232e' },
  lavender: { n: 'Lavender', a: '#845ef7', b: '#9c36b5', c: '#f7f3fe', t: '#221a33' },
  blossom: { n: 'Blossom', a: '#e64980', b: '#be4bdb', c: '#fff3f7', t: '#2d1822' },
  sunny: { n: 'Sunny', a: '#e8890c', b: '#ffd43b', c: '#fffbea', t: '#2b2410' },
  slate: { n: 'Slate', a: '#4c6ef5', b: '#3b5bdb', c: '#f4f6f9', t: '#1c2530' },
  sand: { n: 'Sand', a: '#b9772a', b: '#8a5a1b', c: '#faf6ee', t: '#2e2a22' },
  midnight: { n: 'Midnight', a: '#8f7bff', b: '#3b2f9e', c: '#14121f', t: '#ece9f7', dark: true },
  aurora: { n: 'Aurora', a: '#2dd4bf', b: '#0f766e', c: '#0a1418', t: '#e6f6f4', dark: true },
  ember: { n: 'Ember', a: '#ff5a3c', b: '#b42318', c: '#160b0b', t: '#f6e9e4', dark: true },
  black: { n: 'Black (OLED)', a: '#a78bfa', b: '#4a3fbf', c: '#000000', t: '#eeeeee', dark: true },
};

function applyTheme() {
  const k = THEMES[S.theme] ? S.theme : 'sunrise';
  const r = document.documentElement;
  r.dataset.theme = k;
  if (/^#[0-9a-f]{6}$/i.test(S.accent || '')) { r.style.setProperty('--acc2', S.accent); r.style.setProperty('--acc', S.accent); }
  else { r.style.removeProperty('--acc2'); r.style.removeProperty('--acc'); }
  document.body.classList.toggle('compact', S.density === 'compact');
  ['glass', 'island', 'neon'].forEach(k => document.body.classList.toggle('ui-' + k, S.uiStyle === k));
  document.body.classList.toggle('top', S.toolbarPos !== 'bottom');
  document.body.classList.toggle('bottom', S.toolbarPos === 'bottom');
  const cs = getComputedStyle(r);
  const hex = v => { v = (v || '').trim(); return /^#[0-9a-f]{6}$/i.test(v) ? v : '#ffffff'; };
  A.bars(hex(cs.getPropertyValue('--bg')), !!THEMES[k].dark, hex(cs.getPropertyValue('--acc2')), hex(cs.getPropertyValue('--line')));
}

/* ---------- search ---------- */
const ENGINES = {
  ddg: ['DuckDuckGo', 'https://duckduckgo.com/?q=%s'],
  brave: ['Brave Search', 'https://search.brave.com/search?q=%s'],
  startpage: ['Startpage', 'https://www.startpage.com/do/search?q=%s'],
  ecosia: ['Ecosia', 'https://www.ecosia.org/search?q=%s'],
  qwant: ['Qwant', 'https://www.qwant.com/?q=%s'],
  mojeek: ['Mojeek', 'https://www.mojeek.com/search?q=%s'],
  google: ['Google', 'https://www.google.com/search?q=%s'],
  bing: ['Bing', 'https://www.bing.com/search?q=%s'],
  custom: ['My own (set below)', ''],
};
function searchUrl(q) {
  let tpl = S.engine === 'custom' ? S.customEngine : (ENGINES[S.engine] || ENGINES.ddg)[1];
  if (!tpl || tpl.indexOf('%s') < 0) tpl = ENGINES.ddg[1];
  return tpl.replace('%s', encodeURIComponent(q));
}
/* typed text -> address */
function resolve(input) {
  const v = (input || '').trim();
  if (!v) return HOME_URL;
  if (/^(about:home|nb:\/\/home)$/i.test(v)) return HOME_URL;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) return v;
  if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?([\/?#].*)?$/i.test(v)) return 'http://' + v;
  if (!/\s/.test(v) && /^[^\s\/]+\.[a-z]{2,}([:\/?#].*)?$/i.test(v)) return 'https://' + v;
  return searchUrl(v);
}
function homeUrl() { return S.home && S.home.trim() ? resolve(S.home) : HOME_URL; }
const isHomeUrl = u => !u || u.indexOf('/assets/www/pages/') >= 0;
function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
function niceUrl(u) {
  try { const x = new URL(u); let p = x.pathname === '/' ? '' : x.pathname; return x.hostname.replace(/^www\./, '') + p + (x.search ? x.search : ''); } catch (e) { return u; }
}

/* ---------- layouts: every pane is [x, y, w, h] as fractions of the screen ---------- */
const LAYOUTS = [
  ['single', 'One page'], ['cols2', 'Side by side'], ['rows2', 'Stacked'], ['left1', 'Big left, 2 right'],
  ['right1', 'Big right, 2 left'], ['top1', 'Big top, 2 below'], ['bottom1', 'Big bottom, 2 above'], ['grid4', '2 × 2 grid'],
  ['cols3', '3 columns'], ['rows3', '3 rows'], ['left3', 'Big left, 3 right'],
];
function layoutRects(name, r) {
  r = Math.max(0.3, Math.min(0.7, r || 0.55));
  const q = 1 - r;
  switch (name) {
    case 'cols2': return [[0, 0, 0.5 + (r - 0.5), 1], [r, 0, q, 1]];
    case 'rows2': return [[0, 0, 1, r], [0, r, 1, q]];
    case 'left1': return [[0, 0, r, 1], [r, 0, q, 0.5], [r, 0.5, q, 0.5]];
    case 'right1': return [[q, 0, r, 1], [0, 0, q, 0.5], [0, 0.5, q, 0.5]];
    case 'top1': return [[0, 0, 1, r], [0, r, 0.5, q], [0.5, r, 0.5, q]];
    case 'bottom1': return [[0, q, 1, r], [0, 0, 0.5, q], [0.5, 0, 0.5, q]];
    case 'grid4': return [[0, 0, 0.5, 0.5], [0.5, 0, 0.5, 0.5], [0, 0.5, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5]];
    case 'cols3': return [[0, 0, 1 / 3, 1], [1 / 3, 0, 1 / 3, 1], [2 / 3, 0, 1 / 3, 1]];
    case 'rows3': return [[0, 0, 1, 1 / 3], [0, 1 / 3, 1, 1 / 3], [0, 2 / 3, 1, 1 / 3]];
    case 'left3': return [[0, 0, r, 1], [r, 0, q, 1 / 3], [r, 1 / 3, q, 1 / 3], [r, 2 / 3, q, 1 / 3]];
    default: return [[0, 0, 1, 1]];
  }
}
function layoutSvg(name, w, h) {
  w = w || 54; h = h || 38;
  const g = 1.6, rs = layoutRects(name, 0.55);
  return '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' + rs.map((r, i) =>
    '<rect class="' + (i === 0 ? 'b' : '') + '" x="' + (r[0] * w + g / 2).toFixed(1) + '" y="' + (r[1] * h + g / 2).toFixed(1) + '" width="' + (r[2] * w - g).toFixed(1) + '" height="' + (r[3] * h - g).toFixed(1) + '" rx="3"/>').join('') + '</svg>';
}
function applyLayout() {
  const rs = (S.layout === 'custom' && Array.isArray(S.customRects) && S.customRects.length) ? S.customRects : layoutRects(S.layout, S.ratio / 100);
  A.layout(JSON.stringify(rs), S.layout);
}

/* ---------- bookmarks, history, stats ---------- */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
let BM = Store.get('bookmarks', null);
if (!BM) {
  BM = [
    ['DuckDuckGo', 'https://duckduckgo.com/'], ['Wikipedia', 'https://www.wikipedia.org/'], ['GitHub', 'https://github.com/'],
    ['OpenStreetMap', 'https://www.openstreetmap.org/'], ['Hacker News', 'https://news.ycombinator.com/'], ['Internet Archive', 'https://archive.org/'],
  ].map((x, i) => ({ id: uid() + i, title: x[0], url: x[1], pin: true, ts: Date.now() - i }));
  Store.set('bookmarks', BM);
}
let HIST = Store.get('history', []);
let STATS = Store.get('stats', { blocked: 0, since: Date.now() });
const saveBM = () => Store.set('bookmarks', BM);
const saveHist = () => Store.set('history', HIST);
const isBookmarked = u => BM.some(b => b.url === u);

/* keep the page-readable copies (for the new tab page) in step with the app's own store */
function mirrorAll() {
  Store.set('settings', S); Store.set('bookmarks', BM); Store.set('history', HIST); Store.set('stats', STATS);
}

/* ---------- small helpers ---------- */
let toastT = 0;
function toast(m, ms) {
  const t = $('#toast');
  t.textContent = m; t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, ms || 2200);
}
let modalEl = null;
function modal(o) {
  return new Promise(res => {
    const m = modalEl = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = '<div class="mbox"><h3>' + esc(o.title || '') + '</h3>' + (o.text ? '<p>' + esc(o.text) + '</p>' : '') +
      (o.textarea ? '<textarea class="tarea" spellcheck="false">' + esc(o.value || '') + '</textarea>' : o.input ? '<input class="tin" type="text" value="' + esc(o.value || '') + '" spellcheck="false" autocomplete="off">' : '') +
      '<div class="mrow">' + (o.cancel === false ? '' : '<button class="btn" data-m="0">' + esc(o.cancel || 'Cancel') + '</button>') +
      '<button class="btn ' + (o.danger ? 'warn' : 'pri') + '" data-m="1">' + esc(o.ok || 'OK') + '</button></div></div>';
    document.body.appendChild(m);
    const inp = $('input,textarea', m);
    if (inp) { inp.focus(); if (inp.select && o.input) inp.select(); }
    const done = v => { m.remove(); modalEl = null; res(v); };
    m.addEventListener('click', e => {
      const b = e.target.closest('[data-m]');
      if (b) done(b.dataset.m === '1' ? (inp ? inp.value : true) : null);
      else if (e.target === m) done(null);
    });
  });
}
function debounce(fn, ms) { let t; return function () { clearTimeout(t); const a = arguments; t = setTimeout(() => fn.apply(null, a), ms); }; }
