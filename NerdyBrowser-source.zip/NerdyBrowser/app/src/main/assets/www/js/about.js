'use strict';
/* ===== NerdyBrowser · About =====
   EDIT HERE. Same idea as the About page in NerdyReader.
   Photo: put raghu.jpg (or .png/.webp) next to index.html in assets/www/ (the build copies it from the repo root). */
const AB_PHOTO = ['raghu.jpg', 'raghu.png', 'raghu.jpeg', 'raghu.webp'];
const AB_SKILLS = ['Front-end development', 'Scrum', 'Kanban', 'Jira', 'Azure tools', 'Systems thinking', 'Building trading tools (QuantReloaded)', 'Video editing: After Effects, Blender', 'Testing ideas before using them'];
const AB_FE = ['HTML5', 'CSS3 (custom properties, grid, flexbox)', 'JavaScript (ES6+, no framework)', 'Android WebView tabs in one Java shell', 'Everything served locally, nothing hosted', 'GitHub Actions to build the APK'];
const AB_BOOKS = [
  ['The False Green', 'Trading psychology: why a green screen can lie to you, and what it does to decisions.'],
  ['Who\u2019s Trading Your Account? The Second Trader', 'The other trader inside you, the one who takes over when emotion kicks in.'],
  ['The Eight Power and Trading Paradoxes', 'The contradictions every trader has to live with.'],
  ['The Inner Citadel Trade', 'Building the inside of a trader so the outside can follow.'],
  ['The Blind Candle', 'Reading price and your own mind when the picture is incomplete.'],
];
const AB_STORY = [
  ['2018', 'First steps in the markets', 'I started trading in 2018. In those early days I lost money, mostly because I did not yet understand how markets actually behave.'],
  ['2020 to 2023', 'Away from the screen, closer to the truth', 'I stepped back and worked freelance and regular jobs: video editing, After Effects, Blender. I also took an entry-level role at Fyers, answering calls from traders. Listening to so many of them taught me how markets really behave, and how human psychology shows up in trading: gaps in knowledge, technical problems, and the same emotional mistakes again and again. Later I left Fyers.'],
  ['A hard stretch', 'Habits that became hurdles', 'This was also a heavy period personally. I went through depression and difficult life events, and fell into drinking and smoking. In time I saw that these habits distracted me from the goals I wanted and had become hurdles. I decided to quit, but I kept failing to control the urges. That is what sent me into books on neuroscience, and on trading, because I needed to make money and I never wanted to work under a boss.'],
  ['2023 to 2024', 'Trading again, more lessons', 'I returned to trading while editing videos for creators on Instagram and YouTube. I made small amounts of money, explored trading again, and took more losses along the way.'],
  ['The turning point', 'Quitting alcohol, and asking why', 'One day, full of hatred for the habit and the mental hangover that came with it, I quit alcohol. Then I focused on the real question: why could I not quit before? I took working on myself seriously. I studied characters from Breaking Bad, The Mentalist, The Big Bang Theory, Batman and Money Heist, tried to borrow their habits, read more on habits, neuroscience and trading, learned to think in systems, and built my own tools, including the QuantReloaded dashboard.'],
  ['Today', 'Sober, and still building', 'I have been completely sober for almost a year now. Smoking still triggers me sometimes, and I know I will quit that too. NerdyBrowser is the quiet window I use to look things up without being followed.'],
];
const AB_WHY = [
  ['shield', 'Blocks the noise', 'Ads, trackers, popups, spam overlays, cookie banners and tracking links are stopped before they load.'],
  ['panes', 'Many pages at once', 'Split the screen any way you like: side by side, big plus two small, a grid. Each pane is its own tab.'],
  ['flame', 'Forgets on purpose', 'Cookies and site data are wiped when you close it, and one Burn button clears everything now.'],
  ['sliders', 'Yours to tune', 'Ten themes, your own accent colour, layouts, zoom, text size, shield levels and more.'],
];
const AB_PRIV = [
  'There is no account, no sign-up, no server behind it and no analytics of any kind.',
  'Bookmarks, settings and the optional history stay on this phone, inside the app.',
  'Camera, microphone and location are always refused. The app only asks Android for internet access.',
  'The shield cuts tracking a lot, but no app can hide your IP address from websites or your network. For that, add a VPN or private DNS.',
  'Uninstalling the app removes everything it stored.',
];

const abCard = (i, t, p) => '<div class="mini"><div class="row2"><span class="ico">' + ic(i, 16) + '</span><b>' + esc(t) + '</b></div><p>' + esc(p) + '</p></div>';
const abSec = (title, inner, open) => '<details class="sec"' + (open ? ' open' : '') + '><summary><b>' + esc(title) + '</b><span class="chev">' + ic('down', 18) + '</span></summary><div class="in">' + inner + '</div></details>';

function aboutHTML() {
  return '<div class="ph"><h2>About<div class="sub">The person behind NerdyBrowser, and why it exists</div></h2><button class="ib" data-act="close">' + ic('x') + '</button></div>' +
    '<section class="card abhero"><div class="abph"><span class="abav">R</span><img class="abimg" data-i="0" src="' + AB_PHOTO[0] + '" alt="Raghu"></div>' +
    '<div><div class="serif abname">Raghu</div><div class="mute sm">Trader, author and builder. I never follow random advice: I test it, from every angle, before it touches my trading.</div>' +
    '<div class="wrap gap" style="margin-top:12px"><a class="btn pri" href="https://www.instagram.com/nerdyintruder/">' + ic('heart', 14) + ' @NerdyIntruder</a></div></div></section>' +
    abSec('Who I am', '<p class="sm">I am an active retail trader. I trade equity and F&amp;O, mostly intraday, on NSE and BSE. I also trade crypto (BTC and ETH) and Nasdaq perpetual contracts on Delta Exchange. Trading is the centre of my work and my thinking, and the hardest part of it has never been the chart. It is the person looking at the chart.</p><p class="sm">I do not copy what I am told. Every idea, indicator and tool gets tested first: what works for me, what does not, and why. I look at it from my own point of view and from several others, and I only deploy it in my trading after it has survived the test. That is also how I built this browser.</p><p class="sm">I write about trading psychology, discipline and performance as @NerdyIntruder.</p>', true) +
    abSec('Skills', '<div class="wrap gap6">' + AB_SKILLS.map(x => '<span class="chip2">' + esc(x) + '</span>').join('') + '</div><p class="sm mute" style="margin-top:10px">I have the skills for a software career and I did try to get there. Personal problems kept holding me back and the jobs never came. That was never for lack of trying. Meanwhile I went fully into trading, and I have not looked back.</p>') +
    abSec('Front-end skills', '<p class="sm mute">I build the whole front end myself. This browser is plain HTML, CSS and JavaScript around a small Android shell.</p><div class="wrap gap6" style="margin-top:8px">' + AB_FE.map(x => '<span class="chip2">' + esc(x) + '</span>').join('') + '</div>') +
    abSec('My story', '<div class="abtl">' + AB_STORY.map(x => '<div class="abstep"><span class="abdot"></span><div class="xs mute">' + esc(x[0]) + '</div><b>' + esc(x[1]) + '</b><p class="sm" style="margin:4px 0 0">' + esc(x[2]) + '</p></div>').join('') + '</div>') +
    abSec('My books', '<p class="xs mute" style="margin:0 0 8px">If you are interested, have a look at my work.</p><div class="grid2">' + AB_BOOKS.map(b => '<div class="mini"><b>' + esc(b[0]) + '</b><p>' + esc(b[1]) + '</p></div>').join('') + '</div>') +
    abSec('Why NerdyBrowser', '<div class="grid2">' + AB_WHY.map(b => abCard(b[0], b[1], b[2])).join('') + '</div>') +
    abSec('Your data and privacy', '<div class="sm">' + AB_PRIV.map(x => '<div class="row2" style="align-items:flex-start;margin-bottom:8px"><span style="color:var(--acc);margin-top:2px">' + ic('check', 14) + '</span><span>' + esc(x) + '</span></div>').join('') + '</div>') +
    '<div class="card" style="text-align:center"><div class="serif" style="font-size:20px">Browse deep. Leave no trace.</div><div class="mute sm" style="margin-top:6px">Made with <span style="color:var(--warn)">&#10084;</span> by Raghu</div></div>';
}
function aboutMount() {
  $$('img.abimg').forEach(img => {
    img.addEventListener('load', () => img.classList.add('ok'));
    img.addEventListener('error', () => {
      const i = +img.dataset.i + 1;
      if (i < AB_PHOTO.length) { img.dataset.i = i; img.src = AB_PHOTO[i]; } else img.style.display = 'none';
    });
  });
}
