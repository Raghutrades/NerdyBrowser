'use strict';
/* ===== NerdyBrowser · main: state sync, toolbar, events, splash, reader, boot ===== */
let T = { tabs: [], panes: [], active: 0, layout: 'single', total: 0 };
let ORIENT = 'auto', dlTimer = 0;
let panel = null, findOn = false, lastBarH = 0, lastTotal = 0, stripSig = '', lastActive = -1, statT = 0, urlFocused = false;

function curTab() { return T.tabs.find(t => t.id === T.panes[T.active]) || T.tabs[0] || null; }

/* ---------- toolbar rendering ---------- */
function initIcons() {
  $('#bBack').innerHTML = ic('back', 22); $('#bFwd').innerHTML = ic('fwd', 22); $('#bHome').innerHTML = ic('home', 21);
  $('#bNew').innerHTML = ic('plus', 22); $('#bLay').innerHTML = ic('panes', 21); $('#bMenu').innerHTML = ic('menu', 22);
  $('#fp').innerHTML = ic('up', 18); $('#fn').innerHTML = ic('down', 18); $('#fx').innerHTML = ic('x', 18); $('#clearUrl').innerHTML = ic('x', 15);
}
function renderBars() {
  const t = curTab();
  $('#bBack').disabled = !(t && t.back);
  $('#bFwd').disabled = !(t && t.fwd);
  const loading = !!(t && t.loading);
  $('#reloadBtn').innerHTML = ic(loading ? 'x' : 'reload', 21);
  const pg = $('#prog i');
  pg.style.width = loading ? Math.max(8, t.progress) + '%' : '0';
  pg.style.opacity = loading ? 1 : 0;
  if (!urlFocused) $('#url').value = t && t.url ? niceUrl(t.url) : '';
  const secure = t && /^https:/.test(t.url || ''), plain = t && /^http:/.test(t.url || '');
  const li = $('#lockIc');
  li.className = 'li' + (plain ? ' bad' : '');
  li.innerHTML = t && t.url ? ic(secure ? 'lock' : 'unlock', 16) : ic('search', 16);
  const sb = $('#shieldBtn');
  sb.innerHTML = ic('shield', 22) + (t && t.blocked ? '<span class="cnt">' + (t.blocked > 99 ? '99+' : t.blocked) + '</span>' : '');
  sb.style.opacity = t && t.url && t.shield === false ? '.4' : '1';
  $('#bTabs').innerHTML = '<span style="border:2px solid currentColor;border-radius:7px;min-width:22px;height:22px;display:grid;place-items:center;padding:0 3px">' + T.tabs.length + '</span>';
  const strip = $('#strip');
  strip.hidden = !S.tabStrip;
  const multi = T.panes.length > 1, act = T.panes[T.active];
  const html = T.tabs.map(x => {
    const pi = T.panes.indexOf(x.id);
    return '<div class="chip' + (x.id === act ? ' act' : '') + '" data-act="chip" data-id="' + x.id + '"><span class="lt">' + esc((x.url ? hostOf(x.url) : 'N')[0] || 'N') + '</span><span class="tt">' + esc(x.title || 'New tab') + '</span>' +
      (multi && pi >= 0 ? '<span class="pn">' + (pi + 1) + '</span>' : '') + '<button class="x" data-act="chipx" data-id="' + x.id + '" aria-label="Close tab">' + ic('x', 13) + '</button></div>';
  }).join('');
  if (html !== stripSig) {
    stripSig = html; strip.innerHTML = html;
    if (act !== lastActive) { const a = $('.chip.act', strip); if (a) strip.scrollLeft = Math.max(0, a.offsetLeft - 40); }
  }
  lastActive = act;
  $('#vpnb').hidden = !T.vpn;
  $('#findbar').hidden = !findOn;
  requestAnimationFrame(() => reportBar(false));
}
function reportBar(force) {
  if (panel) return;
  const h = Math.ceil($('#bars').getBoundingClientRect().height);
  if (h > 0 && (force || h !== lastBarH)) { lastBarH = h; A.chrome('bar', h); }
}

/* ---------- panels ---------- */
function setBodyMode(full) {
  document.body.classList.toggle('full', full);
  document.body.classList.toggle('bar', !full);
}
function openPanel(name) {
  if (!PANELS[name]) return;
  if (name === 'shield') { try { shieldStats = JSON.parse(A.stats()); } catch (e) { } }
  if (name === 'vpn') { try { VPN = JSON.parse(A.vpnInfo()); } catch (e) { } }
  if (name === 'downloads') loadDL();
  const was = panel;
  panel = name;
  $('#sheet').hidden = false;
  setBodyMode(true);
  if (!was) A.chrome('full', 0);
  renderPanel(false);
}
function renderPanel(keep) {
  if (!panel) return;
  const P = PANELS[panel], el = $('#panel'), sc = keep ? el.scrollTop : 0;
  el.className = P.sheet ? '' : 'page';
  el.innerHTML = P.html();
  if (P.mount) P.mount();
  el.scrollTop = sc;
}
function closePanel() {
  if (!panel) return;
  panel = null;
  $('#sheet').hidden = true;
  setBodyMode(false);
  A.chrome('bar', lastBarH || 130);
  requestAnimationFrame(() => reportBar(true));
}
function loadDL() { try { DL = JSON.parse(A.downloadsList()); } catch (e) { DL = []; } }
setInterval(() => { if (panel === 'downloads' && !modalEl) { loadDL(); renderPanel(true); } }, 1200);
const softRender = debounce(() => { if (panel && ['tabs', 'layout', 'shield', 'menu'].includes(panel) && !document.activeElement.matches('input,select,textarea')) renderPanel(true); }, 160);

/* ---------- settings changes ---------- */
function setS(k, v, keepPanel) {
  if (k === 'ratio' && S.layout === 'custom') { S.layout = S.basePreset || 'cols2'; S.customRects = null; }
  S[k] = v;
  saveSettings();
  if (['theme', 'accent', 'toolbarPos', 'density'].includes(k)) applyTheme();
  if (k === 'layout' || k === 'ratio') applyLayout();
  if (['tabStrip', 'density', 'toolbarPos'].includes(k)) { stripSig = ''; renderBars(); }
  if (panel && !keepPanel) renderPanel(true);
}

/* ---------- reader mode ---------- */
function readerRun(cfg) {
  try {
    if (document.getElementById('nb-reader')) { location.reload(); return; }
    var all = document.querySelectorAll('article,main,[role=main],section,div');
    var sc = [], max = 0, i, j;
    for (i = 0; i < all.length; i++) {
      var el = all[i], ps = el.querySelectorAll('p'), s = 0;
      for (j = 0; j < ps.length; j++) { var l = (ps[j].textContent || '').trim().length; if (l > 60) s += l; }
      s -= el.querySelectorAll('a').length * 20;
      if (el.tagName === 'ARTICLE') s *= 1.3;
      sc.push([el, s]); if (s > max) max = s;
    }
    var best = null, bl = 1e12;
    for (i = 0; i < sc.length; i++) { if (sc[i][1] >= max * 0.7 && sc[i][1] > 200) { var tl = sc[i][0].textContent.length; if (tl < bl) { bl = tl; best = sc[i][0]; } } }
    if (!best) {
      var n = document.createElement('div'); n.textContent = 'NerdyBrowser: no article found on this page';
      n.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);background:#222;color:#fff;padding:10px 16px;border-radius:20px;z-index:2147483647;font:14px sans-serif';
      document.body.appendChild(n); setTimeout(function () { n.remove(); }, 2500); return;
    }
    var clone = best.cloneNode(true);
    var junk = clone.querySelectorAll('script,style,nav,aside,footer,form,iframe,button,noscript,[class*=share],[class*=social],[class*=comment],[class*=related],[class*=newsletter],[class*=promo],[class*=advert]');
    for (i = 0; i < junk.length; i++) junk[i].remove();
    var title = document.title;
    var nodes = clone.querySelectorAll('h1,h2,h3,h4,p,ul,ol,blockquote,pre,img'), out = [];
    for (i = 0; i < nodes.length; i++) {
      var d = nodes[i];
      if (d.parentElement && d.parentElement.closest('blockquote,ul,ol,pre,p,h1,h2,h3,h4')) continue;
      out.push(d);
    }
    var doc = document;
    doc.head.querySelectorAll('style,link[rel=stylesheet]').forEach(function (x) { x.remove(); });
    doc.body.removeAttribute('style'); doc.body.className = ''; doc.body.innerHTML = '';
    var st = doc.createElement('style');
    var ff = cfg.font === 'serif' ? 'Georgia,"Times New Roman",serif' : 'system-ui,-apple-system,Roboto,sans-serif';
    st.textContent = 'html,body{background:' + cfg.bg + '!important;margin:0}body{color:' + cfg.ink + '}#nb-reader{max-width:680px;margin:0 auto;padding:18px 20px 90px;font:' + cfg.size + 'px/1.7 ' + ff + ';color:' + cfg.ink + '}' +
      '#nb-reader h1{font-size:1.5em;line-height:1.25;margin:.6em 0 .5em}#nb-reader h2,#nb-reader h3,#nb-reader h4{line-height:1.3;margin:1.4em 0 .4em}#nb-reader p{margin:0 0 1.05em}' +
      '#nb-reader img{max-width:100%;height:auto;border-radius:10px;margin:.6em 0}#nb-reader blockquote{margin:1em 0;padding-left:14px;border-left:3px solid ' + cfg.acc + ';opacity:.9}' +
      '#nb-reader pre{overflow:auto;background:rgba(127,127,127,.15);padding:10px;border-radius:8px;font-size:.8em}#nb-rb{position:sticky;top:0;display:flex;gap:8px;justify-content:flex-end;padding:8px 0;background:' + cfg.bg + '}' +
      '#nb-rb button{border:1px solid rgba(127,127,127,.4);background:none;color:' + cfg.ink + ';border-radius:10px;padding:7px 12px;font:600 13px system-ui}';
    doc.head.appendChild(st);
    var box = doc.createElement('div'); box.id = 'nb-reader';
    var bar = doc.createElement('div'); bar.id = 'nb-rb';
    var mk = function (t, f) { var b = doc.createElement('button'); b.textContent = t; b.onclick = f; bar.appendChild(b); };
    var size = cfg.size;
    mk('A−', function () { size = Math.max(12, size - 2); box.style.fontSize = size + 'px'; });
    mk('A+', function () { size = Math.min(40, size + 2); box.style.fontSize = size + 'px'; });
    mk('Exit reader', function () { location.reload(); });
    box.appendChild(bar);
    var h1 = doc.createElement('h1'); h1.textContent = title; box.appendChild(h1);
    for (i = 0; i < out.length; i++) {
      var o = out[i], tg = o.tagName.toLowerCase(), e;
      if (tg === 'img') { if (!o.src) continue; e = doc.createElement('img'); e.src = o.src; }
      else if (tg === 'ul' || tg === 'ol') { e = doc.createElement(tg); var lis = o.querySelectorAll('li'); for (j = 0; j < lis.length; j++) { var li = doc.createElement('li'); li.textContent = lis[j].textContent.trim(); e.appendChild(li); } }
      else { var tx = (o.textContent || '').trim(); if (!tx) continue; e = doc.createElement(tg); e.textContent = tx; }
      box.appendChild(e);
    }
    box.id = 'nb-reader'; doc.body.appendChild(box); window.scrollTo(0, 0);
  } catch (e) { }
}
function readerScript() {
  const th = { paper: ['#fffdf8', '#222222'], sepia: ['#f4ecd8', '#3b2f1e'], night: ['#1c1a24', '#e6e2f2'] }[S.readerTheme] || ['#fffdf8', '#222222'];
  const acc = getComputedStyle(document.documentElement).getPropertyValue('--acc2').trim() || '#f0642f';
  return '(' + readerRun.toString() + ')(' + JSON.stringify({ bg: th[0], ink: th[1], font: S.readerFont, size: S.readerSize, acc: acc }) + ')';
}

/* ---------- welcome animation ---------- */
function splashRun(replay) {
  const el = $('#splash');
  el.hidden = false;
  if (replay) { setBodyMode(true); A.chrome('full', 0); }
  el.onclick = () => Splash.skip();
  Splash.run({ style: S.splashStyle, sound: S.splashSound, vol: S.splashVol }, splashEnd);
}
function splashEnd() {
  const el = $('#splash');
  el.classList.add('out');
  setTimeout(() => { el.hidden = true; }, 600);
  if (!panel) { setBodyMode(false); A.chrome('bar', lastBarH || 130); requestAnimationFrame(() => reportBar(true)); }
}

/* ---------- actions ---------- */
function bookmarkCurrent() {
  const t = curTab();
  if (!t || isHomeUrl(t.url)) { toast('Open a page first'); return; }
  const i = BM.findIndex(b => b.url === t.url);
  if (i >= 0) { BM.splice(i, 1); saveBM(); toast('Bookmark removed'); }
  else { BM.unshift({ id: uid(), title: t.title || hostOf(t.url), url: t.url, pin: false, ts: Date.now() }); saveBM(); toast('Bookmarked'); }
}
function exportData() {
  const txt = JSON.stringify({ app: 'NerdyBrowser', v: 1, settings: S, bookmarks: BM }, null, 1);
  A.shareText(txt);
}
async function importData() {
  const txt = await modal({ title: 'Import', text: 'Paste text you exported from NerdyBrowser.', textarea: true, ok: 'Import' });
  if (!txt) return;
  try {
    const o = JSON.parse(txt);
    if (o.bookmarks && Array.isArray(o.bookmarks)) {
      const have = new Set(BM.map(b => b.url));
      o.bookmarks.forEach(b => { if (b && b.url && !have.has(b.url)) BM.push({ id: uid(), title: String(b.title || b.url), url: String(b.url), pin: !!b.pin, ts: Date.now() }); });
      saveBM();
    }
    if (o.settings && typeof o.settings === 'object') { S = Object.assign({}, DEF, o.settings); saveSettings(); applyTheme(); applyLayout(); stripSig = ''; renderBars(); }
    toast('Imported'); renderPanel(true);
  } catch (e) { toast('That text could not be read'); }
}

async function act(a, el) {
  const t = curTab();
  const d = el.dataset;
  switch (a) {
    case 'back': A.back(); break;
    case 'fwd': A.forward(); break;
    case 'reload': A.reload(); break;
    case 'home': A.go(homeUrl()); break;
    case 'newtab': closePanel(); A.newTab(homeUrl(), false); setTimeout(() => $('#url').focus(), 200); break;
    case 'tabs': case 'layout': case 'menu': case 'shield': case 'settings': case 'about': case 'bookmarks': case 'history': case 'zoom': openPanel(a); break;
    case 'close': closePanel(); break;
    case 'clearurl': $('#url').value = ''; $('#url').focus(); break;
    case 'chip': A.selectTab(+d.id); break;
    case 'chipx': A.closeTab(+d.id); break;
    case 'closetab': if (t) A.closeTab(t.id); closePanel(); break;
    case 'tabpick': A.selectTab(+d.id); closePanel(); break;
    case 'tabclose': A.closeTab(+d.id); break;
    case 'tabmove': A.moveTab(+d.id, +d.d); break;
    case 'tabdup': A.dupTab(+d.id); break;
    case 'dupcur': if (t) A.dupTab(t.id); closePanel(); toast('Tab duplicated'); break;
    case 'swappanes': A.swapPanes(0, 1); break;
    case 'rotatepanes': A.rotatePanes(); break;
    case 'resetsizes': S.customRects = null; if (S.layout === 'custom') S.layout = S.basePreset || 'cols2'; saveSettings(); applyLayout(); renderPanel(true); break;
    case 'refresh': { if (!t) break; const i = REFRESH_STEPS.indexOf(t.refresh || 0); const n = REFRESH_STEPS[(i + 1) % REFRESH_STEPS.length]; A.tabRefresh(t.id, n); closePanel(); toast(n ? 'Refreshing this tab every ' + fmtSec(n) : 'Auto refresh off'); break; }
    case 'rotate': { ORIENT = ORIENT === 'auto' ? 'landscape' : ORIENT === 'landscape' ? 'portrait' : 'auto'; A.orient(ORIENT); closePanel(); toast('Screen: ' + ORIENT); break; }
    case 'immersive': { if (t && !t.desktop) A.tabFlag(t.id, 'desktop', true); ORIENT = 'landscape'; A.orient('landscape'); closePanel(); A.fullscreen(true); toast('Immersive desktop. Tap the round button to leave.', 3000); break; }
    case 'phonebars': setS('alwaysFull', !S.alwaysFull, true); closePanel(); toast(S.alwaysFull ? 'Phone bars hidden. Swipe from the edge to peek.' : 'Phone bars shown'); break;
    case 'vpn': openPanel('vpn'); break;
    case 'vpnconnect': A.vpnConnect(); break;
    case 'vpndisconnect': A.vpnDisconnect(); break;
    case 'vpnsave': { const v = ($('#vpncfg').value || '').trim(); if (v.indexOf('[Interface]') < 0) { toast('That does not look like a WireGuard config'); break; } A.vpnSave(v); $('#vpncfg').value = ''; break; }
    case 'vpnclear': if (await modal({ title: 'Remove the VPN config?', ok: 'Remove', danger: true })) A.vpnClear(); break;
    case 'closeall': if (await modal({ title: 'Close all tabs?', ok: 'Close all', danger: true })) { A.closeAll(); closePanel(); } break;
    case 'bookmark': bookmarkCurrent(); closePanel(); break;
    case 'bmadd': bookmarkCurrent(); renderPanel(true); break;
    case 'bmopen': { const b = BM.find(x => x.id === d.id); if (b) { A.go(b.url); closePanel(); } break; }
    case 'bmpin': { const b = BM.find(x => x.id === d.id); if (b) { b.pin = !b.pin; saveBM(); renderPanel(true); } break; }
    case 'bmedit': { const b = BM.find(x => x.id === d.id); if (!b) break; const v = await modal({ title: 'Rename bookmark', input: true, value: b.title, ok: 'Save' }); if (v && v.trim()) { b.title = v.trim(); saveBM(); renderPanel(true); } break; }
    case 'bmdel': BM = BM.filter(x => x.id !== d.id); saveBM(); renderPanel(true); break;
    case 'urlopen': A.go(d.u); closePanel(); break;
    case 'find': closePanel(); findOn = true; renderBars(); setTimeout(() => $('#findq').focus(), 120); break;
    case 'findnext': A.findNext(true); break;
    case 'findprev': A.findNext(false); break;
    case 'findclose': closeFind(); break;
    case 'reader': closePanel(); A.runScript(readerScript()); break;
    case 'share': A.share(); closePanel(); break;
    case 'copylink': A.copyLink(); closePanel(); break;
    case 'desktop': if (t) A.tabFlag(t.id, 'desktop', !t.desktop); closePanel(); break;
    case 'dark': if (t) A.tabFlag(t.id, 'dark', !t.dark); closePanel(); break;
    case 'tjs': if (t) A.tabFlag(t.id, 'js', !t.js); closePanel(); toast(t && t.js ? 'JavaScript off for this tab' : 'JavaScript on for this tab'); break;
    case 'timg': if (t) A.tabFlag(t.id, 'images', !t.images); closePanel(); break;
    case 'fullscreen': closePanel(); A.fullscreen(true); toast('Tap the round button to come back', 2600); break;
    case 'print': closePanel(); A.print(); break;
    case 'downloads': openPanel('downloads'); break;
    case 'sysdownloads': A.downloads(); break;
    case 'dlopen': A.downloadOpen(+d.id); break;
    case 'dlrm': A.downloadRemove(+d.id); setTimeout(() => { loadDL(); if (panel === 'downloads') renderPanel(true); }, 250); break;
    case 'burn': if (await modal({ title: 'Burn everything?', text: 'Closes all tabs and wipes cookies, site data, cache and history. Your bookmarks and settings stay.', ok: 'Burn', danger: true })) { HIST = []; closePanel(); A.burn(); toast('Burning…'); } break;
    case 'exit': A.exit(); break;
    case 'setlayout': S.basePreset = d.v; S.customRects = null; setS('layout', d.v); break;
    case 'tog': setS(d.k, !S[d.k]); break;
    case 'seg': setS(d.k, d.v); break;
    case 'theme': setS('theme', d.v); break;
    case 'accentreset': setS('accent', ''); break;
    case 'zoomd': {
      const host = t ? hostOf(t.url) : '';
      if (!host) { S.pageZoom = Math.max(50, Math.min(250, S.pageZoom + (+d.d || 0))); if (+d.d === 0) S.pageZoom = 100; }
      else {
        S.siteZoom = Object.assign({}, S.siteZoom);
        if (+d.d === 0) delete S.siteZoom[host]; else S.siteZoom[host] = Math.max(50, Math.min(300, siteZoom(host) + (+d.d)));
      }
      saveSettings(); renderPanel(true); break;
    }
    case 'siteshield': {
      const h = d.h, list = S.siteAllow.slice();
      const i = list.indexOf(h);
      if (i >= 0) list.splice(i, 1); else list.push(h);
      S.siteAllow = list; saveSettings(); A.reload(); renderPanel(true); break;
    }
    case 'splashplay': closePanel(); splashRun(true); break;
    case 'clearcookies': A.clearData('cookies'); break;
    case 'clearcache': A.clearData('cache'); break;
    case 'clearhist': HIST = []; saveHist(); toast('History cleared'); if (panel) renderPanel(true); break;
    case 'export': exportData(); break;
    case 'import': importData(); break;
    case 'resetset': if (await modal({ title: 'Reset all settings?', text: 'Bookmarks are kept.', ok: 'Reset', danger: true })) { S = Object.assign({}, DEF); saveSettings(); applyTheme(); applyLayout(); stripSig = ''; renderBars(); renderPanel(true); toast('Settings reset'); } break;
  }
}
function closeFind() { findOn = false; A.findClose(); $('#findq').value = ''; $('#findc').textContent = ''; renderBars(); }

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (el) act(el.dataset.act, el);
});
document.addEventListener('input', e => {
  const x = e.target;
  if (x.matches('[data-rng]')) { const rv = x.parentElement.querySelector('.rv'); if (rv) rv.textContent = x.value + (x.dataset.unit || ''); }
  else if (x.id === 'bmq') { bmQ = x.value; renderPanel(true); const i = $('#bmq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'hiq') { hiQ = x.value; renderPanel(true); const i = $('#hiq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'findq') A.find(x.value);
  else if (x.matches('[data-col]')) { S.accent = x.value; applyTheme(); saveSettings(); }
  else if (x.id === 'url') $('#clearUrl').hidden = !x.value;
});
document.addEventListener('change', e => {
  const x = e.target;
  if (x.matches('[data-rng]')) setS(x.dataset.k, +x.value);
  else if (x.matches('[data-txt]')) setS(x.dataset.k, x.value.trim(), true);
  else if (x.matches('[data-sel]')) setS(x.dataset.k, x.value);
  else if (x.matches('[data-list]')) setS(x.dataset.k, Array.from(new Set(x.value.split(/\n|,/).map(s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '')).filter(Boolean))), true);
  else if (x.matches('[data-col]')) setS('accent', x.value, true);
  else if (x.dataset.act === 'panesel') A.assignPane(+x.value, +x.dataset.p);
});
document.addEventListener('toggle', e => {
  const d = e.target;
  if (d.matches && d.matches('details[data-sec]')) { if (d.open) openSecs.add(d.dataset.sec); else openSecs.delete(d.dataset.sec); }
}, true);
const urlIn = $('#url');
urlIn.addEventListener('focus', () => {
  urlFocused = true; const t = curTab();
  urlIn.value = t && t.url ? t.url : '';
  setTimeout(() => urlIn.select(), 30);
  $('#clearUrl').hidden = !urlIn.value;
});
urlIn.addEventListener('blur', () => { urlFocused = false; $('#clearUrl').hidden = true; renderBars(); });
urlIn.addEventListener('keydown', e => {
  if (e.key === 'Enter') { const v = urlIn.value; urlIn.blur(); A.go(resolve(v)); }
});
$('#findq').addEventListener('keydown', e => { if (e.key === 'Enter') A.findNext(true); });

/* ---------- callbacks from the app ---------- */
window.NB = {
  state(s) {
    T = s;
    const d = (s.total || 0) - lastTotal;
    if (d > 0) { STATS.blocked += d; clearTimeout(statT); statT = setTimeout(() => Store.set('stats', STATS), 2500); }
    lastTotal = s.total || 0;
    renderBars();
    softRender();
  },
  found(i, c) { $('#findc').textContent = c ? (i + 1) + '/' + c : '0/0'; },
  event(n, v) { if (n === 'fs' && !v) { setBodyMode(false); } },
  open(text) { closePanel(); A.newTab(resolve(text), false); },
  back() {
    if (modalEl) { modalEl.remove(); modalEl = null; return; }
    if (panel) closePanel();
  },
  closeFind() { closeFind(); },
  visit(url, title) {
    if (!S.saveHistory) return;
    HIST = HIST.filter(h => h.u !== url);
    HIST.unshift({ u: url, t: title || '', ts: Date.now() });
    if (HIST.length > 500) HIST.length = 500;
    saveHist();
  },
  rects(r) { S.layout = 'custom'; S.customRects = r; saveSettings(); if (panel === 'layout') renderPanel(true); },
  vpn(o) { VPN = o || VPN; $('#vpnb').hidden = !VPN.up; if (panel === 'vpn') renderPanel(true); },
  afterBurn() { mirrorAll(); lastTotal = 0; toast('Burned. Clean slate.'); },
};

/* ---------- boot ---------- */
function boot() {
  initIcons();
  applyTheme();
  mirrorAll();
  A.settings(JSON.stringify(S));
  A.ready();
  applyLayout();
  try { T = JSON.parse(A.state()); if (!T.tabs) T = { tabs: [], panes: [], active: 0, layout: 'single', total: 0 }; } catch (e) { }
  renderBars();
  if (S.splash) splashRun(false);
  else { $('#splash').hidden = true; setBodyMode(false); A.chrome('bar', 130); requestAnimationFrame(() => reportBar(true)); }
}
boot();
