'use strict';
/* ===== NerdyBrowser · main: state sync, toolbar, events, splash, reader, boot ===== */
let T = { tabs: [], panes: [], active: 0, layout: 'single', total: 0 };
let IMM = false, IMMPREV = 'auto', ORIENT = 'auto', panelMode = null, DLH = {}, DLTOT = 0, DLSPD = [], DLACTIVE = false, DLWATCH = 0;
function setHtml(el, html) { if (el._h !== html) { el._h = html; el.innerHTML = html; } }
let FAV = Store.get('fav', {}), favT = 0;
const favOf = u => { const h = u ? hostOf(u) : ''; return h && FAV[h] && /^data:image\/png;base64,[A-Za-z0-9+\/=]+$/.test(FAV[h]) ? FAV[h] : ''; };
let panel = null, findOn = false, lastBarH = 0, lastTotal = 0, stripSig = '', lastActive = -1, statT = 0, urlFocused = false;

function curTab() { return T.tabs.find(t => t.id === T.panes[T.active]) || T.tabs[0] || null; }

/* ---------- toolbar rendering ---------- */
function initIcons() {
  $('#bBack').innerHTML = ic('back', 22); $('#bFwd').innerHTML = ic('fwd', 22); $('#bHome').innerHTML = ic('home', 21);
  $('#bNew').innerHTML = ic('plus', 22); $('#bLay').innerHTML = ic('panes', 21); $('#bMenu').innerHTML = ic('menu', 22);
  $('#fp').innerHTML = ic('up', 18); $('#fn').innerHTML = ic('down', 18); $('#fx').innerHTML = ic('x', 18); $('#clearUrl').innerHTML = ic('x', 15);
}
function renderBars() {
  const t = curTab();
  $('#bBack').disabled = !(t && t.back);
  $('#bFwd').disabled = !(t && t.fwd);
  const loading = !!(t && t.loading);
  setHtml($('#reloadBtn'), ic(loading ? 'x' : 'reload', 21));
  const pg = $('#prog i');
  pg.style.width = loading ? Math.max(8, t.progress) + '%' : '0';
  pg.style.opacity = loading ? 1 : 0;
  if (!urlFocused) $('#url').value = t && t.url ? niceUrl(t.url) : '';
  const secure = t && /^https:/.test(t.url || ''), plain = t && /^http:/.test(t.url || '');
  const li = $('#lockIc');
  li.className = 'li' + (plain ? ' bad' : '');
  setHtml(li, t && t.url ? ic(secure ? 'lock' : 'unlock', 16) : ic('search', 16));
  const sb = $('#shieldBtn');
  setHtml(sb, ic('shield', 22) + (t && t.blocked ? '<span class="cnt">' + (t.blocked > 99 ? '99+' : t.blocked) + '</span>' : ''));
  sb.style.opacity = t && t.url && t.shield === false ? '.4' : '1';
  setHtml($('#bTabs'), '<span style="border:2px solid currentColor;border-radius:7px;min-width:22px;height:22px;display:grid;place-items:center;padding:0 3px">' + T.tabs.length + '</span>');
  $('#rowB').hidden = !S.optRow || !!S.pcMode;
  if (S.pcMode) {
    setHtml($('#pcBack'), ic('back', 20)); setHtml($('#pcFwd'), ic('fwd', 20)); setHtml($('#pcHome'), ic('home', 19)); setHtml($('#pcNew'), ic('plus', 18));
    $('#pcBack').disabled = !(t && t.back); $('#pcFwd').disabled = !(t && t.fwd);
  }
  $('#pcNew').hidden = !S.pcMode;
  setHtml($('#splitBtn'), ic('layout', 17));
  setHtml($('#bFsA'), ic('full', 21)); $('#bFsA').hidden = !S.fsBtnAddr;
  setHtml($('#bFsB'), ic('full', 21)); $('#bFsB').hidden = !S.fsBtnRow;
  setHtml($('#stripFs'), ic('full', 16)); $('#stripFs').hidden = !S.fsBtnStrip;
  setHtml($('#rowTog'), ic(S.optRow ? 'up' : 'down', 17));
  const strip = $('#strip');
  strip.style.display = S.tabStrip ? '' : 'none';
  const multi = T.panes.length > 1, act = T.panes[T.active];
  const html = T.tabs.map(x => {
    const pi = T.panes.indexOf(x.id);
    return '<div class="chip' + (x.id === act ? ' act' : '') + '" data-act="chip" data-id="' + x.id + '">' + (favOf(x.url) ? '<span class="lt fv"><img src="' + favOf(x.url) + '" alt=""></span>' : '<span class="lt">' + esc((x.url ? hostOf(x.url) : 'N')[0] || 'N') + '</span>') + '<span class="tt">' + esc(x.title || 'New tab') + '</span>' +
      (multi && pi >= 0 ? '<span class="pn">' + (pi + 1) + '</span>' : '') + '<button class="x" data-act="chipx" data-id="' + x.id + '" aria-label="Close tab">' + ic('x', 13) + '</button></div>';
  }).join('');
  if (html !== stripSig) {
    stripSig = html; strip.innerHTML = html;
    if (act !== lastActive) { const a = $('.chip.act', strip); if (a) strip.scrollLeft = Math.max(0, a.offsetLeft - 40); }
  }
  lastActive = act;
  $('#vpnb').hidden = !T.vpn;
  $('#findbar').hidden = !findOn;
  requestAnimationFrame(() => reportBar(false));
}
function reportBar(force) {
  if (panel) return;
  const h = Math.ceil($('#bars').getBoundingClientRect().height);
  if (h > 0 && (force || h !== lastBarH)) { lastBarH = h; A.chrome('bar', h); }
}

/* ---------- panels ---------- */
function setBodyMode(full) {
  document.body.classList.toggle('full', full);
  document.body.classList.toggle('bar', !full);
}
function openPanel(name) {
  if (!PANELS[name]) return;
  if (name === 'shield') { try { shieldStats = JSON.parse(A.stats()); } catch (e) { } }
  if (name === 'vpn') { try { VPN = JSON.parse(A.vpnInfo()); } catch (e) { } }
  if (name === 'downloads') loadDL();
  const was = panel, mode = PANELS[name].sheet ? 'sheet' : 'full';
  panel = name;
  $('#sheet').hidden = false;
  setBodyMode(true);
  if (!was || mode !== panelMode) { panelMode = mode; A.chrome(mode, 0); }
  renderPanel(false);
}
function renderPanel(keep) {
  if (!panel) return;
  const P = PANELS[panel], el = $('#panel'), sc = keep ? el.scrollTop : 0;
  el.className = P.sheet ? '' : 'page';
  el.innerHTML = P.html();
  if (P.mount) P.mount();
  el.scrollTop = sc;
}
function closePanel() {
  if (!panel) return;
  panel = null;
  panelMode = null;
  $('#sheet').hidden = true;
  setBodyMode(false);
  A.chrome('bar', lastBarH || 130);
  requestAnimationFrame(() => reportBar(true));
}
function loadDL() {
  let arr = [];
  try { arr = JSON.parse(A.downloadsList()); } catch (e) { }
  const now = Date.now();
  let tot = 0, act = 0;
  arr.forEach(d => {
    const h = DLH[d.id];
    d.speed = 0;
    if (d.status === 2) {
      act++;
      if (d.sm) d.speed = d.spd || 0;
      else if (h && now > h.t) { const inst = Math.max(0, (d.got - h.got) / ((now - h.t) / 1000)); d.speed = h.speed ? h.speed * 0.6 + inst * 0.4 : inst; }
      tot += d.speed;
    }
    DLH[d.id] = { t: now, got: d.got, speed: d.speed };
  });
  DL = arr; DLTOT = tot; DLACTIVE = act > 0;
  DLSPD.push(tot); if (DLSPD.length > 40) DLSPD.shift();
  const c = $('#dlchip');
  if (DLACTIVE) { c.hidden = false; setHtml(c, ic('download', 13) + ' ' + dlSize(DLTOT) + '/s'); } else { c.hidden = true; DLSPD = []; }
}
setInterval(() => {
  if (panel === 'downloads' && !modalEl) { dlRefresh(); }
  else if (DLACTIVE || Date.now() < DLWATCH) loadDL();
}, 1500);
const softRender = debounce(() => { if (panel && ['tabs', 'layout', 'shield', 'menu'].includes(panel) && !document.activeElement.matches('input,select,textarea')) renderPanel(true); }, 160);

/* ---------- settings changes ---------- */
function setS(k, v, keepPanel) {
  if (k === 'ratio' && S.layout === 'custom') { S.layout = S.basePreset || 'cols2'; S.customRects = null; }
  S[k] = v;
  saveSettings();
  if (['theme', 'accent', 'toolbarPos', 'density', 'uiStyle'].includes(k)) applyTheme();
  if (k === 'layout' || k === 'ratio') applyLayout();
  if (['tabStrip', 'density', 'toolbarPos', 'uiStyle', 'fsBtnAddr', 'fsBtnRow', 'fsBtnStrip'].includes(k)) { stripSig = ''; renderBars(); }
  if (panel && !keepPanel) renderPanel(true);
}

/* ---------- reader mode ---------- */
function readerRun(cfg) {
  try {
    if (document.getElementById('nb-reader')) { location.reload(); return; }
    var all = document.querySelectorAll('article,main,[role=main],section,div');
    var sc = [], max = 0, i, j;
    for (i = 0; i < all.length; i++) {
      var el = all[i], ps = el.querySelectorAll('p'), s = 0;
      for (j = 0; j < ps.length; j++) { var l = (ps[j].textContent || '').trim().length; if (l > 60) s += l; }
      s -= el.querySelectorAll('a').length * 20;
      if (el.tagName === 'ARTICLE') s *= 1.3;
      sc.push([el, s]); if (s > max) max = s;
    }
    var best = null, bl = 1e12;
    for (i = 0; i < sc.length; i++) { if (sc[i][1] >= max * 0.7 && sc[i][1] > 200) { var tl = sc[i][0].textContent.length; if (tl < bl) { bl = tl; best = sc[i][0]; } } }
    if (!best) {
      var n = document.createElement('div'); n.textContent = 'NerdyBrowser: no article found on this page';
      n.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);background:#222;color:#fff;padding:10px 16px;border-radius:20px;z-index:2147483647;font:14px sans-serif';
      document.body.appendChild(n); setTimeout(function () { n.remove(); }, 2500); return;
    }
    var clone = best.cloneNode(true);
    var junk = clone.querySelectorAll('script,style,nav,aside,footer,form,iframe,button,noscript,[class*=share],[class*=social],[class*=comment],[class*=related],[class*=newsletter],[class*=promo],[class*=advert]');
    for (i = 0; i < junk.length; i++) junk[i].remove();
    var title = document.title;
    var nodes = clone.querySelectorAll('h1,h2,h3,h4,p,ul,ol,blockquote,pre,img'), out = [];
    for (i = 0; i < nodes.length; i++) {
      var d = nodes[i];
      if (d.parentElement && d.parentElement.closest('blockquote,ul,ol,pre,p,h1,h2,h3,h4')) continue;
      out.push(d);
    }
    var doc = document;
    doc.head.querySelectorAll('style,link[rel=stylesheet]').forEach(function (x) { x.remove(); });
    doc.body.removeAttribute('style'); doc.body.className = ''; doc.body.innerHTML = '';
    var st = doc.createElement('style');
    var ff = cfg.font === 'serif' ? 'Georgia,"Times New Roman",serif' : 'system-ui,-apple-system,Roboto,sans-serif';
    st.textContent = 'html,body{background:' + cfg.bg + '!important;margin:0}body{color:' + cfg.ink + '}#nb-reader{max-width:680px;margin:0 auto;padding:18px 20px 90px;font:' + cfg.size + 'px/1.7 ' + ff + ';color:' + cfg.ink + '}' +
      '#nb-reader h1{font-size:1.5em;line-height:1.25;margin:.6em 0 .5em}#nb-reader h2,#nb-reader h3,#nb-reader h4{line-height:1.3;margin:1.4em 0 .4em}#nb-reader p{margin:0 0 1.05em}' +
      '#nb-reader img{max-width:100%;height:auto;border-radius:10px;margin:.6em 0}#nb-reader blockquote{margin:1em 0;padding-left:14px;border-left:3px solid ' + cfg.acc + ';opacity:.9}' +
      '#nb-reader pre{overflow:auto;background:rgba(127,127,127,.15);padding:10px;border-radius:8px;font-size:.8em}#nb-rb{position:sticky;top:0;display:flex;gap:8px;justify-content:flex-end;padding:8px 0;background:' + cfg.bg + '}' +
      '#nb-rb button{border:1px solid rgba(127,127,127,.4);background:none;color:' + cfg.ink + ';border-radius:10px;padding:7px 12px;font:600 13px system-ui}';
    doc.head.appendChild(st);
    var box = doc.createElement('div'); box.id = 'nb-reader';
    var bar = doc.createElement('div'); bar.id = 'nb-rb';
    var mk = function (t, f) { var b = doc.createElement('button'); b.textContent = t; b.onclick = f; bar.appendChild(b); };
    var size = cfg.size;
    mk('A−', function () { size = Math.max(12, size - 2); box.style.fontSize = size + 'px'; });
    mk('A+', function () { size = Math.min(40, size + 2); box.style.fontSize = size + 'px'; });
    mk('Exit reader', function () { location.reload(); });
    box.appendChild(bar);
    var h1 = doc.createElement('h1'); h1.textContent = title; box.appendChild(h1);
    for (i = 0; i < out.length; i++) {
      var o = out[i], tg = o.tagName.toLowerCase(), e;
      if (tg === 'img') { if (!o.src) continue; e = doc.createElement('img'); e.src = o.src; }
      else if (tg === 'ul' || tg === 'ol') { e = doc.createElement(tg); var lis = o.querySelectorAll('li'); for (j = 0; j < lis.length; j++) { var li = doc.createElement('li'); li.textContent = lis[j].textContent.trim(); e.appendChild(li); } }
      else { var tx = (o.textContent || '').trim(); if (!tx) continue; e = doc.createElement(tg); e.textContent = tx; }
      box.appendChild(e);
    }
    box.id = 'nb-reader'; doc.body.appendChild(box); window.scrollTo(0, 0);
  } catch (e) { }
}
function readerScript() {
  const th = { paper: ['#fffdf8', '#222222'], sepia: ['#f4ecd8', '#3b2f1e'], night: ['#1c1a24', '#e6e2f2'] }[S.readerTheme] || ['#fffdf8', '#222222'];
  const acc = getComputedStyle(document.documentElement).getPropertyValue('--acc2').trim() || '#f0642f';
  return '(' + readerRun.toString() + ')(' + JSON.stringify({ bg: th[0], ink: th[1], font: S.readerFont, size: S.readerSize, acc: acc }) + ')';
}

/* ---------- welcome animation ---------- */
function splashRun(replay) {
  const el = $('#splash');
  el.hidden = false;
  if (replay) { setBodyMode(true); A.chrome('full', 0); }
  el.onclick = () => Splash.skip();
  Splash.run({ style: S.splashStyle, sound: S.splashSound, vol: S.splashVol }, splashEnd);
}
function splashEnd() {
  const el = $('#splash');
  el.classList.add('out');
  setTimeout(() => { el.hidden = true; }, 600);
  if (!panel) { setBodyMode(false); A.chrome('bar', lastBarH || 130); requestAnimationFrame(() => reportBar(true)); }
}

/* ---------- actions ---------- */
function bookmarkCurrent() {
  const t = curTab();
  if (!t || isHomeUrl(t.url)) { toast('Open a page first'); return; }
  const i = BM.findIndex(b => b.url === t.url);
  if (i >= 0) { BM.splice(i, 1); saveBM(); toast('Bookmark removed'); }
  else { BM.unshift({ id: uid(), title: t.title || hostOf(t.url), url: t.url, pin: false, ts: Date.now() }); saveBM(); toast('Bookmarked'); }
}
function exportData() {
  const txt = JSON.stringify({ app: 'NerdyBrowser', v: 1, settings: S, bookmarks: BM }, null, 1);
  A.shareText(txt);
}
async function pickLimit(id) {
  const global = !id;
  const cur = global ? (+S.dlGlobal || 0) : Math.round(((DL.find(x => x.id === id) || {}).limit || 0) / 1024);
  const opts = [0, 100, 250, 500, 1024, 2048, 5120].map(k => ({ label: (k ? (k >= 1024 ? (k / 1024) + ' MB/s' : k + ' KB/s') : 'No limit (full speed)') + (k === cur ? '  ✓' : ''), v: k }));
  opts.push({ label: 'Custom…', v: -1 });
  let v = await choose({ title: global ? 'Limit all downloads together' : 'Speed limit for this file', text: global ? 'The total speed is shared between everything that is downloading.' : 'This file will never use more than this, even if you have more speed.', options: opts });
  if (v === null) return;
  if (v === -1) {
    const t = await modal({ title: 'Custom limit', text: 'Type KB per second. 1000 is about 1 MB/s. 0 means no limit.', input: true, value: String(cur || 500), ok: 'Set' });
    if (t === null) return;
    v = Math.max(0, parseInt(t, 10) || 0);
  }
  if (global) { S.dlGlobal = String(v); saveSettings(); } else A.downloadLimit(id, v);
  toast(v ? 'Limit: ' + (v >= 1024 ? (v / 1024).toFixed(1) + ' MB/s' : v + ' KB/s') : 'No limit');
  setTimeout(() => dlRefresh(), 250);
}
function choose(o) {
  return new Promise(res => {
    const m = modalEl = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = '<div class="mbox"><h3>' + esc(o.title || '') + '</h3>' + (o.text ? '<p style="word-break:break-all">' + esc(o.text) + '</p>' : '') +
      '<div style="display:grid;gap:8px;margin-top:10px">' + o.options.map((x, i) => '<button class="btn' + (i === 0 ? ' pri' : '') + '" data-c="' + i + '" style="justify-content:center">' + esc(x.label) + '</button>').join('') + '<button class="btn" data-c="-1" style="justify-content:center">Cancel</button></div></div>';
    document.body.appendChild(m);
    const done = v => { m.remove(); modalEl = null; res(v); };
    m.addEventListener('click', e => {
      const b = e.target.closest('[data-c]');
      if (b) { const i = +b.dataset.c; done(i < 0 ? null : o.options[i].v); } else if (e.target === m) done(null);
    });
  });
}
const decEnt = s => String(s).replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
/* reads bookmarks from: Netscape HTML (Chrome, Firefox, Edge, Brave, Opera exports), Chrome / Firefox JSON, CSV, or plain lists of links */
function parseBookmarks(txt) {
  const out = [], seen = new Set();
  const add = (t, u) => {
    u = decEnt((u || '').trim());
    if (!/^https?:\/\//i.test(u) || seen.has(u) || out.length >= 3000) return;
    seen.add(u);
    t = decEnt(String(t || '').replace(/<[^>]+>/g, '')).trim().slice(0, 200);
    out.push({ title: t || hostOf(u) || u, url: u });
  };
  const s = String(txt || '').trim();
  if (s[0] === '{' || s[0] === '[') {
    try {
      const j = JSON.parse(s);
      (function walk(n) {
        if (!n) return;
        if (Array.isArray(n)) { n.forEach(walk); return; }
        if (typeof n === 'object') {
          const u = n.url || n.uri;
          if (typeof u === 'string') add(n.name || n.title, u);
          Object.keys(n).forEach(k => { if (n[k] && typeof n[k] === 'object') walk(n[k]); });
        }
      })(j);
      return out;
    } catch (e) { }
  }
  if (/<a\s/i.test(s)) {
    const re = /<a\s[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(s))) add(m[2], m[1]);
    return out;
  }
  s.split(/\r?\n/).forEach(line => {
    const m = line.match(/(https?:\/\/[^\s,"';]+)/);
    if (m) add(line.replace(m[1], '').replace(/[,"';]+/g, ' ').trim(), m[1]);
  });
  return out;
}
function importBookmarkText(txt) {
  const list = parseBookmarks(txt);
  if (!list.length) return 0;
  const have = new Set(BM.map(b => b.url));
  let n = 0;
  list.forEach(b => { if (!have.has(b.url)) { BM.push({ id: uid(), title: b.title, url: b.url, pin: false, ts: Date.now() - n }); have.add(b.url); n++; } });
  saveBM();
  return n;
}
async function importData() {
  const txt = await modal({ title: 'Import', text: 'Paste text you exported from NerdyBrowser.', textarea: true, ok: 'Import' });
  if (!txt) return;
  try {
    const o = JSON.parse(txt);
    if (o.bookmarks && Array.isArray(o.bookmarks)) {
      const have = new Set(BM.map(b => b.url));
      o.bookmarks.forEach(b => { if (b && b.url && !have.has(b.url)) BM.push({ id: uid(), title: String(b.title || b.url), url: String(b.url), pin: !!b.pin, ts: Date.now() }); });
      saveBM();
    }
    if (o.settings && typeof o.settings === 'object') { S = Object.assign({}, DEF, o.settings); saveSettings(); applyTheme(); applyLayout(); stripSig = ''; renderBars(); }
    toast('Imported'); renderPanel(true);
  } catch (e) { toast('That text could not be read'); }
}

async function act(a, el) {
  const t = curTab();
  const d = el.dataset;
  switch (a) {
    case 'back': A.back(); break;
    case 'fwd': A.forward(); break;
    case 'reload': A.reload(); break;
    case 'home': A.go(homeUrl()); break;
    case 'newtab': closePanel(); A.newTab(homeUrl(), false); setTimeout(() => $('#url').focus(), 200); break;
    case 'tabs': case 'layout': case 'menu': case 'shield': case 'settings': case 'about': case 'bookmarks': case 'history': case 'zoom': openPanel(a); break;
    case 'close': closePanel(); break;
    case 'clearurl': $('#url').value = ''; $('#url').focus(); break;
    case 'chip': A.selectTab(+d.id); break;
    case 'chipx': A.closeTab(+d.id); break;
    case 'closetab': if (t) A.closeTab(t.id); closePanel(); break;
    case 'tabpick': A.selectTab(+d.id); closePanel(); break;
    case 'tabclose': A.closeTab(+d.id); break;
    case 'tabmove': A.moveTab(+d.id, +d.d); break;
    case 'tabdup': A.dupTab(+d.id); break;
    case 'dupcur': if (t) A.dupTab(t.id); closePanel(); toast('Tab duplicated'); break;
    case 'swappanes': A.swapPanes(0, 1); break;
    case 'rotatepanes': A.rotatePanes(); break;
    case 'resetsizes': S.customRects = null; if (S.layout === 'custom') S.layout = S.basePreset || 'cols2'; saveSettings(); applyLayout(); renderPanel(true); break;
    case 'refresh': { if (!t) break; const i = REFRESH_STEPS.indexOf(t.refresh || 0); const n = REFRESH_STEPS[(i + 1) % REFRESH_STEPS.length]; A.tabRefresh(t.id, n); closePanel(); toast(n ? 'Refreshing this tab every ' + fmtSec(n) : 'Auto refresh off'); break; }
    case 'rotate': { ORIENT = ORIENT === 'auto' ? 'sensor' : ORIENT === 'sensor' ? 'landscape' : ORIENT === 'landscape' ? 'portrait' : 'auto'; A.orient(ORIENT); closePanel(); toast('Screen: ' + ORIENT); break; }
    case 'split': openPanel('split'); break;
    case 'qlayout': S.basePreset = d.v; S.customRects = null; setS('layout', d.v); closePanel(); break;
    case 'wssave': { await saveWorkspace(); break; }
    case 'wsopen': { const w = (S.workspaces || []).find(x => x.id === d.id); if (w) openWS(w); break; }
    case 'wsapp': { const w = (S.workspaces || []).find(x => x.id === d.id); if (w) { A.pinWorkspace(w.id, w.name); toast('Adding to home screen…'); } break; }
    case 'wsren': { const w = (S.workspaces || []).find(x => x.id === d.id); if (!w) break; const v = await modal({ title: 'Rename workspace', input: true, value: w.name, ok: 'Save' }); if (v && v.trim()) { w.name = v.trim(); saveSettings(); renderPanel(true); } break; }
    case 'wsdel': { const w = (S.workspaces || []).find(x => x.id === d.id); if (w && await modal({ title: 'Delete "' + w.name + '"?', text: 'The saved set of pages is removed. Home screen icons for it stop working.', ok: 'Delete', danger: true })) { S.workspaces = S.workspaces.filter(x => x.id !== d.id); saveSettings(); renderPanel(true); } break; }
    case 'wsupd': { const w = (S.workspaces || []).find(x => x.id === d.id); if (w) { Object.assign(w, wsSnapshot()); saveSettings(); renderPanel(true); toast('Workspace updated'); } break; }
    case 'pctoggle': closePanel(); setPC(!S.pcMode); break;
    case 'reopen': A.reopenTab(); closePanel(); break;
    case 'reopenat': A.reopenAt(+d.i); closePanel(); break;
    case 'closed': case 'keys': case 'cmd': if (a === 'cmd') cmQ = ''; openPanel(a); break;
    case 'clearclosed': A.clearClosed(); renderPanel(true); break;
    case 'cmdrun': { const c = d.c; closePanel(); setTimeout(() => act(c, { dataset: {} }), 60); break; }
    case 'immersive': { if (t && !t.desktop) A.tabFlag(t.id, 'desktop', true); if (!IMM) IMMPREV = ORIENT === 'landscape' ? 'auto' : ORIENT; IMM = true; ORIENT = 'landscape'; A.orient('landscape'); closePanel(); A.fullscreen(true); toast('Immersive desktop. Leave with the round button or Back; the screen goes back to auto-rotate by itself.', 3200); break; }
    case 'phonebars': setS('alwaysFull', !S.alwaysFull, true); closePanel(); toast(S.alwaysFull ? 'Phone bars hidden. Swipe from the edge to peek.' : 'Phone bars shown'); break;
    case 'vpn': openPanel('vpn'); break;
    case 'vpnauto': A.vpnAutoSetup(); break;
    case 'ipcheck': closePanel(); A.newTab('https://www.cloudflare.com/cdn-cgi/trace', false); break;
    case 'rowtog': S.optRow = !S.optRow; saveSettings(); renderBars(); break;
    case 'pick': closePanel(); A.pickElement(); toast('Tap the thing to hide', 2200); break;
    case 'media': closePanel(); A.mediaPage(); break;
    case 'vpnwarp': toast('Creating your free config...'); A.vpnWarpDraft(); break;
    case 'vpnown': {
      const ep = ($('#vpnep').value || '').trim(), sk = ($('#vpnsk').value || '').trim();
      let r = {}; try { r = JSON.parse(A.vpnOwnDraft(ep, sk, '')); } catch (e) { }
      if (r.error || !r.cfg) { toast(r.error || 'Could not create it', 3200); break; }
      VPNPEER = r.peer; VPNDRAFT = r.cfg; renderPanel(true);
      toast(r.needsKey ? 'Created. Now add the server key (see below).' : 'Created. Check it, then tap Save and use.', 3200); break; }
    case 'vpnshow': { const c = A.vpnSaved(); if (!c) { toast('Nothing saved yet'); break; } VPNDRAFT = c; renderPanel(true); break; }
    case 'vpncopy': { const c = ($('#vpncfg').value || '').trim() || A.vpnSaved(); if (!c) { toast('Nothing to copy'); break; } A.copy(c); break; }
    case 'vpnshare': { const c = ($('#vpncfg').value || '').trim() || A.vpnSaved(); if (!c) { toast('Nothing to share'); break; } A.shareText(c); break; }
    case 'vpnpeer': A.copy(VPNPEER); break;
    case 'vpnscript': A.copy(WG_SCRIPT); toast('Script copied. Paste it into your server\'s console.', 3200); break;
    case 'dlfilter': dlFilter = d.v; renderPanel(true); break;
    case 'dlretry': A.downloadRetry(+d.id); DLWATCH = Date.now() + 20000; setTimeout(() => dlRefresh(), 400); break;
    case 'dlclear': DL.filter(x => x.status === 8).forEach(x => A.downloadRemove(x.id)); setTimeout(() => dlRefresh(), 350); break;
    case 'vpnconnect': A.vpnConnect(); break;
    case 'vpndisconnect': A.vpnDisconnect(); break;
    case 'vpnsave': { const v = ($('#vpncfg').value || '').trim(); if (v.indexOf('[Interface]') < 0) { toast('That does not look like a WireGuard config'); break; } if (v.indexOf('PASTE_SERVER_PUBLIC_KEY_HERE') >= 0) { toast('Replace PASTE_SERVER_PUBLIC_KEY_HERE with your server\'s public key first', 3200); break; } A.vpnSave(v); $('#vpncfg').value = ''; VPNDRAFT = ''; VPNPEER = ''; break; }
    case 'vpnclear': if (await modal({ title: 'Remove the VPN config?', ok: 'Remove', danger: true })) A.vpnClear(); break;
    case 'closeall': if (await modal({ title: 'Close all tabs?', ok: 'Close all', danger: true })) { A.closeAll(); closePanel(); } break;
    case 'bookmark': bookmarkCurrent(); closePanel(); break;
    case 'bmadd': bookmarkCurrent(); renderPanel(true); break;
    case 'bmopen': { const b = BM.find(x => x.id === d.id); if (b) { A.go(b.url); closePanel(); } break; }
    case 'bmapp': { const b = BM.find(x => x.id === d.id); if (b) { A.pinApp(b.title || hostOf(b.url), b.url); toast('Confirm on the pop-up to add it to your home screen', 3200); } break; }
    case 'addapp': { const t = curTab(); closePanel(); if (!t || isHomeUrl(t.url)) { toast('Open a website first'); break; } A.pinApp(t.title || hostOf(t.url), t.url); toast('Confirm on the pop-up to add it to your home screen', 3200); break; }
    case 'bmpin': { const b = BM.find(x => x.id === d.id); if (b) { b.pin = !b.pin; saveBM(); renderPanel(true); } break; }
    case 'bmedit': { const b = BM.find(x => x.id === d.id); if (!b) break; const v = await modal({ title: 'Rename bookmark', input: true, value: b.title, ok: 'Save' }); if (v && v.trim()) { b.title = v.trim(); saveBM(); renderPanel(true); } break; }
    case 'bmdel': BM = BM.filter(x => x.id !== d.id); saveBM(); renderPanel(true); break;
    case 'urlopen': A.go(d.u); closePanel(); break;
    case 'find': closePanel(); findOn = true; renderBars(); setTimeout(() => $('#findq').focus(), 120); break;
    case 'findnext': A.findNext(true); break;
    case 'findprev': A.findNext(false); break;
    case 'findclose': closeFind(); break;
    case 'reader': closePanel(); A.runScript(readerScript()); break;
    case 'share': A.share(); closePanel(); break;
    case 'copylink': A.copyLink(); closePanel(); break;
    case 'desktop': if (t) A.tabFlag(t.id, 'desktop', !t.desktop); closePanel(); break;
    case 'dark': if (t) A.tabFlag(t.id, 'dark', !t.dark); closePanel(); break;
    case 'tjs': if (t) A.tabFlag(t.id, 'js', !t.js); closePanel(); toast(t && t.js ? 'JavaScript off for this tab' : 'JavaScript on for this tab'); break;
    case 'timg': if (t) A.tabFlag(t.id, 'images', !t.images); closePanel(); break;
    case 'fullscreen': closePanel(); A.fullscreen(true); toast('Full screen. Tap Exit on the floating bar to come back', 2600); break;
    case 'fsmode': closePanel(); A.fullscreen(!T.fs); if (!T.fs) toast('Full screen. Tap Exit on the floating bar to come back', 2600); break;
    case 'print': closePanel(); A.print(); break;
    case 'downloads': openPanel('downloads'); break;
    case 'sysdownloads': A.downloads(); break;
    case 'dlopen': A.downloadOpen(+d.id); break;
    case 'dlview': dlPreview(+d.id); break;
    case 'dlviewmode': S.dlView = d.v; saveSettings(); DLSIG = ''; renderPanel(true); break;
    case 'dlpause': A.downloadPause(+d.id); setTimeout(() => dlRefresh(), 250); break;
    case 'dlresume': A.downloadResume(+d.id); DLWATCH = Date.now() + 20000; setTimeout(() => dlRefresh(), 250); break;
    case 'dlpauseall': A.downloadsAll(true); setTimeout(() => dlRefresh(), 300); break;
    case 'dlresumeall': A.downloadsAll(false); DLWATCH = Date.now() + 20000; setTimeout(() => dlRefresh(), 300); break;
    case 'dlspeed': pickLimit(+d.id); break;
    case 'dlmore': {
      const x = DL.find(q => q.id === +d.id); if (!x) break;
      const o = [];
      if (x.url) { o.push({ label: 'Copy link', v: 'copy' }); o.push({ label: 'Share link', v: 'share' }); }
      if (dlCanPrev(x)) o.push({ label: x.status === 8 ? 'Preview' : 'Preview so far', v: 'preview' });
      if (x.status === 8) o.push({ label: 'Open file', v: 'open' });
      if (x.sm && x.status !== 8 && x.status !== 16) { o.push({ label: x.st === 3 ? 'Resume' : 'Pause', v: x.st === 3 ? 'resume' : 'pause' }); o.push({ label: 'Speed limit…', v: 'speed' }); }
      if (x.status === 16) o.push({ label: 'Try again', v: 'retry' });
      o.push({ label: x.status === 8 ? 'Remove from list' : 'Cancel and remove', v: 'rm' });
      choose({ title: x.title || 'Download', text: x.url || '', options: o }).then(v => {
        if (!v) return;
        if (v === 'copy') { A.copy(x.url); toast('Link copied'); }
        else if (v === 'share') A.shareText(x.url);
        else if (v === 'open') A.downloadOpen(x.id);
        else if (v === 'preview') dlPreview(x.id);
        else if (v === 'pause') act('dlpause', { dataset: { id: x.id } });
        else if (v === 'resume') act('dlresume', { dataset: { id: x.id } });
        else if (v === 'speed') pickLimit(x.id);
        else if (v === 'retry') act('dlretry', { dataset: { id: x.id } });
        else if (v === 'rm') act('dlrm', { dataset: { id: x.id } });
      });
      break; }
    case 'tortoggle': { const on = /9050|9150/.test(S.proxy || ''); S.proxy = on ? '' : 'socks5://127.0.0.1:9050'; saveSettings(); toast(on ? 'Tor off' : 'Tor on. Open the Orbot app and press Start first.', 3200); renderPanel(true); break; }
    case 'dlglobal': pickLimit(0); break;
    case 'dlrm': A.downloadRemove(+d.id); setTimeout(() => dlRefresh(), 250); break;
    case 'burn': if (await modal({ title: 'Burn everything?', text: 'Closes all tabs and wipes cookies, site data, cache and history. Your bookmarks and settings stay.', ok: 'Burn', danger: true })) { HIST = []; closePanel(); A.burn(); toast('Burning…'); } break;
    case 'exit': A.exit(); break;
    case 'setlayout': S.basePreset = d.v; S.customRects = null; setS('layout', d.v); break;
    case 'tog': setS(d.k, !S[d.k]); break;
    case 'seg': setS(d.k, d.v); break;
    case 'theme': setS('theme', d.v); break;
    case 'accentreset': setS('accent', ''); break;
    case 'zoomd': {
      const host = t ? hostOf(t.url) : '';
      if (!host) { S.pageZoom = Math.max(50, Math.min(250, S.pageZoom + (+d.d || 0))); if (+d.d === 0) S.pageZoom = 100; }
      else {
        S.siteZoom = Object.assign({}, S.siteZoom);
        if (+d.d === 0) delete S.siteZoom[host]; else S.siteZoom[host] = Math.max(50, Math.min(300, siteZoom(host) + (+d.d)));
      }
      saveSettings(); renderPanel(true); break;
    }
    case 'siteshield': {
      const h = d.h, list = S.siteAllow.slice();
      const i = list.indexOf(h);
      if (i >= 0) list.splice(i, 1); else list.push(h);
      S.siteAllow = list; saveSettings(); A.reload(); renderPanel(true); break;
    }
    case 'splashplay': closePanel(); splashRun(true); break;
    case 'clearcookies': A.clearData('cookies'); break;
    case 'clearcache': A.clearData('cache'); break;
    case 'clearhist': HIST = []; saveHist(); toast('History cleared'); if (panel) renderPanel(true); break;
    case 'bmimport': {
      const c = await choose({ title: 'Import bookmarks', text: 'Bring bookmarks from another browser or app. Works with the bookmarks file exported from Chrome, Firefox, Edge, Brave or Opera (HTML), their JSON backups, CSV, or a plain list of links.', options: [{ label: 'Pick a file…', v: 'file' }, { label: 'Paste links or text', v: 'paste' }] });
      if (c === 'file') A.pickImportFile();
      else if (c === 'paste') { const t = await modal({ title: 'Paste bookmarks', text: 'Paste an exported bookmarks file or a list of links.', textarea: true, ok: 'Import' }); if (t) { const n = importBookmarkText(t); toast(n ? n + ' bookmarks added' : 'No links found'); renderPanel(true); } }
      break;
    }
    case 'extopen': closePanel(); A.openExternal(); break;
    case 'export': exportData(); break;
    case 'import': importData(); break;
    case 'resetset': if (await modal({ title: 'Reset all settings?', text: 'Bookmarks are kept.', ok: 'Reset', danger: true })) { S = Object.assign({}, DEF); saveSettings(); applyTheme(); applyLayout(); stripSig = ''; renderBars(); renderPanel(true); toast('Settings reset'); } break;
  }
}
function closeFind() { findOn = false; A.findClose(); $('#findq').value = ''; $('#findc').textContent = ''; renderBars(); }

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (el) act(el.dataset.act, el);
});
document.addEventListener('input', e => {
  const x = e.target;
  if (x.matches('[data-rng]')) { const rv = x.parentElement.querySelector('.rv'); if (rv) rv.textContent = x.value + (x.dataset.unit || ''); }
  else if (x.id === 'bmq') { bmQ = x.value; renderPanel(true); const i = $('#bmq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'dlq') { dlQ = x.value; renderPanel(true); const i = $('#dlq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'cmq') { cmQ = x.value; renderPanel(true); const i = $('#cmq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'hiq') { hiQ = x.value; renderPanel(true); const i = $('#hiq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  else if (x.id === 'findq') A.find(x.value);
  else if (x.matches('[data-col]')) { S.accent = x.value; applyTheme(); saveSettings(); }
  else if (x.id === 'url') $('#clearUrl').hidden = !x.value;
});
document.addEventListener('change', e => {
  const x = e.target;
  if (x.matches('[data-rng]')) setS(x.dataset.k, +x.value);
  else if (x.matches('[data-txt]')) setS(x.dataset.k, x.value.trim(), true);
  else if (x.matches('[data-sel]')) setS(x.dataset.k, x.value);
  else if (x.matches('[data-list]') && x.dataset.k === 'hideSelectors') setS('hideSelectors', Array.from(new Set(x.value.split(/\n/).map(v => v.trim()).filter(Boolean))), true);
  else if (x.matches('[data-list]')) setS(x.dataset.k, Array.from(new Set(x.value.split(/\n|,/).map(s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '')).filter(Boolean))), true);
  else if (x.matches('[data-col]')) setS('accent', x.value, true);
  else if (x.dataset.act === 'panesel') A.assignPane(+x.value, +x.dataset.p);
});
document.addEventListener('toggle', e => {
  const d = e.target;
  if (d.matches && d.matches('details[data-sec]')) { if (d.open) openSecs.add(d.dataset.sec); else openSecs.delete(d.dataset.sec); }
}, true);
const urlIn = $('#url');
urlIn.addEventListener('focus', () => {
  urlFocused = true; const t = curTab();
  urlIn.value = t && t.url ? t.url : '';
  setTimeout(() => urlIn.select(), 30);
  $('#clearUrl').hidden = !urlIn.value;
});
urlIn.addEventListener('blur', () => { urlFocused = false; $('#clearUrl').hidden = true; renderBars(); });
urlIn.addEventListener('keydown', e => {
  if (e.key === 'Enter') { const v = urlIn.value; urlIn.blur(); A.go(resolve(v)); }
});
$('#findq').addEventListener('keydown', e => { if (e.key === 'Enter') A.findNext(true); });

/* ---------- callbacks from the app ---------- */
window.NB = {
  state(s) {
    T = s;
    const d = (s.total || 0) - lastTotal;
    if (d > 0) { STATS.blocked += d; clearTimeout(statT); statT = setTimeout(() => Store.set('stats', STATS), 2500); }
    lastTotal = s.total || 0;
    renderBars();
    softRender();
  },
  act(name) { if (PANELS[name]) openPanel(name); },
  goText(v) { A.go(resolve(String(v || ''))); },
  found(i, c) { $('#findc').textContent = c ? (i + 1) + '/' + c : '0/0'; },
  event(n, v) { if (n === 'fs' && !v) { setBodyMode(false); if (IMM) { IMM = false; ORIENT = IMMPREV; A.orient(ORIENT); } } if (n === 'dl') { DLWATCH = Date.now() + 25000; } },
  importFile(text) {
    const t = String(text || '');
    if (t.trim()[0] === '{' && t.indexOf('"app"') > -1 && t.indexOf('NerdyBrowser') > -1) { try { const o = JSON.parse(t); if (o.bookmarks) importBookmarkText(JSON.stringify(o.bookmarks)); if (o.settings) { S = Object.assign({}, DEF, o.settings); saveSettings(); applyTheme(); applyLayout(); stripSig = ''; renderBars(); } toast('Backup restored'); renderPanel(true); return; } catch (e) { } }
    const n = importBookmarkText(t);
    toast(n ? n + ' bookmarks added' : 'No bookmarks found in that file', 2600);
    if (panel === 'bookmarks') renderPanel(true);
  },
  async shared(text) {
    const c = await choose({ title: 'Link from another app', text: text, options: [{ label: 'Open it', v: 'open' }, { label: 'Save as bookmark', v: 'bm' }] });
    if (c === 'open') { closePanel(); A.newTab(resolve(text), false); }
    else if (c === 'bm') { const u = resolve(text); if (/^https?:/.test(u) && !isBookmarked(u)) { BM.unshift({ id: uid(), title: hostOf(u) || u, url: u, pin: false, ts: Date.now() }); saveBM(); } toast('Bookmark saved'); }
  },
  hideSel(host, sel) {
    const rule = (host ? host.replace(/^www\./, '') + '##' : '') + sel;
    if (!S.hideSelectors.includes(rule)) { S.hideSelectors = S.hideSelectors.concat([rule]); saveSettings(); }
    toast('Hidden on ' + (host || 'this site') + '. Undo in Settings → Shield → My own hide rules.', 3200);
  },
  open(text) { closePanel(); A.newTab(resolve(text), false); },
  back() {
    if (modalEl) { modalEl.remove(); modalEl = null; return; }
    if (panel) closePanel();
  },
  closeFind() { closeFind(); },
  visit(url, title) {
    if (!S.saveHistory) return;
    HIST = HIST.filter(h => h.u !== url);
    HIST.unshift({ u: url, t: title || '', ts: Date.now() });
    if (HIST.length > 500) HIST.length = 500;
    saveHist();
  },
  rects(r) { S.layout = 'custom'; S.customRects = r; saveSettings(); if (panel === 'layout') renderPanel(true); },
  vpn(o) { VPN = o || VPN; $('#vpnb').hidden = !VPN.up; if (panel === 'vpn') renderPanel(true); },
  vpnDraft(cfg, msg) { VPNDRAFT = cfg || ''; VPNPEER = ''; if (panel === 'vpn') renderPanel(true); toast(msg || 'Config created', 3200); },
  afterBurn() { mirrorAll(); lastTotal = 0; toast('Burned. Clean slate.'); },
};

/* ---------- gestures: swipe the address bar to switch tabs ---------- */
function switchTab(d) {
  if (T.tabs.length < 2) return;
  const cur = curTab();
  let i = T.tabs.findIndex(t => cur && t.id === cur.id);
  i = (i + d + T.tabs.length) % T.tabs.length;
  A.selectTab(T.tabs[i].id);
  toast('Tab ' + (i + 1) + ' of ' + T.tabs.length, 900);
}
(function () {
  let sx = 0, sy = 0, t0 = 0, ok = false;
  const el = $('#rowA');
  el.addEventListener('touchstart', e => { if (e.touches.length !== 1 || !S.swipeTabs) { ok = false; return; } sx = e.touches[0].clientX; sy = e.touches[0].clientY; t0 = Date.now(); ok = true; }, { passive: true });
  el.addEventListener('touchend', e => {
    if (!ok) return; ok = false;
    const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 70 && Math.abs(dy) < 45 && Date.now() - t0 < 600 && document.activeElement !== $('#url')) switchTab(dx < 0 ? 1 : -1);
  }, { passive: true });
})();

/* ---------- boot ---------- */
let PCPREV = null;
function wsSnapshot() {
  const ids = T.tabs.map(t => t.id);
  return { layout: S.layout, rects: S.layout === 'custom' ? S.customRects : null, ratio: S.ratio, tabs: T.tabs.map(t => ({ u: t.url || '', d: !!t.desktop })), panes: T.panes.map(id => ids.indexOf(id)) };
}
async function saveWorkspace() {
  const hosts = T.panes.map(id => { const t = T.tabs.find(x => x.id === id); return t && t.url ? hostOf(t.url) : ''; }).filter(Boolean);
  const v = await modal({ title: 'Save workspace', text: 'Saves every open tab and how they are laid out. Open it any time, or put it on your home screen.', input: true, value: hosts.slice(0, 3).join(' + ') || 'My workspace', ok: 'Save' });
  if (!v || !v.trim()) return;
  const w = Object.assign({ id: 'w' + uid(), name: v.trim().slice(0, 40) }, wsSnapshot());
  S.workspaces = (S.workspaces || []).concat([w]); saveSettings(); renderPanel(true); toast('Workspace saved');
}
function openWS(w) {
  closePanel();
  S.layout = w.layout || 'single';
  if (S.layout !== 'custom') S.basePreset = S.layout;
  S.customRects = w.rects || null; if (w.ratio) S.ratio = w.ratio;
  saveSettings(); applyLayout();
  setTimeout(() => A.openWorkspace(JSON.stringify(w.tabs || []), JSON.stringify(w.panes || [])), 120);
  toast('Opened ' + w.name, 1600);
}
NB.openWorkspaceId = function (id) { const w = (S.workspaces || []).find(x => x.id === id); if (w) openWS(w); else toast('That workspace was deleted'); };
NB.favicon = function (h, url) {
  h = String(h || '').replace(/^www\./, '');
  if (!h || FAV[h] === url) return;
  FAV[h] = url; clearTimeout(favT); favT = setTimeout(() => { try { Store.set('fav', FAV); } catch (e) { } }, 1500);
  stripSig = ''; renderBars(); if (panel === 'tabs') renderPanel(true);
};
/* hold a tab, then slide it left or right to move it */
(function () {
  const strip = document.getElementById('strip');
  let timer = 0, drag = null, pend = null;
  const chips = () => Array.prototype.slice.call(strip.querySelectorAll('.chip'));
  strip.addEventListener('pointerdown', e => {
    const c = e.target.closest('.chip'); if (!c || e.target.closest('.x')) return;
    pend = { x: e.clientX, y: e.clientY };
    clearTimeout(timer);
    timer = setTimeout(() => {
      drag = { c, id: +c.dataset.id, x0: pend.x, idx: chips().indexOf(c), sl0: strip.scrollLeft, pid: e.pointerId };
      c.classList.add('dragging'); strip.style.overflowX = 'hidden';
      try { c.setPointerCapture(e.pointerId); } catch (x) { }
      if (navigator.vibrate) navigator.vibrate(14);
    }, 360);
  });
  document.addEventListener('pointermove', e => {
    if (!drag) { if (pend && timer && Math.abs(e.clientX - pend.x) + Math.abs(e.clientY - pend.y) > 9) { clearTimeout(timer); timer = 0; } return; }
    e.preventDefault();
    const r = strip.getBoundingClientRect();
    if (e.clientX > r.right - 36) strip.scrollLeft += 8; else if (e.clientX < r.left + 36) strip.scrollLeft -= 8;
    drag.c.style.transform = 'translateX(' + (e.clientX - drag.x0 + strip.scrollLeft - drag.sl0) + 'px)';
  }, { passive: false });
  const end = () => {
    clearTimeout(timer); timer = 0; pend = null;
    if (!drag) return;
    const d = drag; drag = null;
    const cr = d.c.getBoundingClientRect(), cx = cr.left + cr.width / 2;
    const others = chips().filter(x => x !== d.c);
    let ni = 0; others.forEach(o => { const q = o.getBoundingClientRect(); if (q.left + q.width / 2 < cx) ni++; });
    d.c.classList.remove('dragging'); d.c.style.transform = ''; strip.style.overflowX = '';
    if (ni !== d.idx) { stripSig = ''; A.moveTab(d.id, ni - d.idx); }
  };
  document.addEventListener('pointerup', end);
  document.addEventListener('pointercancel', end);
})();
function applyPC() {
  document.body.classList.toggle('pc', !!S.pcMode);
  const sb = $('#pcNav'); if (sb) sb.hidden = !S.pcMode;
}
function setPC(on) {
  if (on === !!S.pcMode) return;
  if (on) {
    PCPREV = { orient: ORIENT, full: S.alwaysFull, row: S.optRow };
    S.pcPrev = PCPREV;
    S.pcMode = true; S.alwaysFull = true; S.tabStrip = true; S.optRow = false;
    ORIENT = 'landscape'; A.orient('landscape');
  } else {
    const p = S.pcPrev || PCPREV || {};
    S.pcMode = false; S.alwaysFull = p.full === undefined ? true : p.full; S.optRow = !!p.row;
    ORIENT = p.orient && p.orient !== 'landscape' ? p.orient : 'auto'; A.orient(ORIENT);
  }
  saveSettings(); applyPC(); stripSig = ''; renderBars();
  toast(on ? 'PC mode on. Sites open like on a computer. Keyboard shortcuts work (Ctrl+/ for the list).' : 'PC mode off', 3000);
}
function focusUrl() { A.focusChrome(); closePanel(); const u = $('#url'); setTimeout(() => { u.focus(); u.select(); }, 60); }
const SHORT_ACT = { newtab: 1, closetab: 1, reload: 1, back: 1, fwd: 1, home: 1, bookmark: 1, history: 1, downloads: 1, settings: 1, tabs: 1, print: 1, bookmarks: 1, keys: 1, cmd: 1, split: 1 };
NB.shortcut = function (n) {
  const t = curTab();
  if (n === 'cmd') cmQ = '';
  if (SHORT_ACT[n]) { act(n, { dataset: {} }); return; }
  if (n === 'reopen') A.reopenTab();
  else if (n === 'focus') focusUrl();
  else if (n === 'find') { closePanel(); findOn = true; renderBars(); A.focusChrome(); setTimeout(() => $('#findq').focus(), 120); }
  else if (n === 'findnext' || n === 'findprev') { if (!findOn) { findOn = true; renderBars(); } A.findNext(n === 'findnext'); }
  else if (n === 'nexttab') A.cycleTab(1);
  else if (n === 'prevtab') A.cycleTab(-1);
  else if (/^tab\d$/.test(n)) A.selectIndex(+n[3]);
  else if (n === 'zoomin' || n === 'zoomout' || n === 'zoomreset') {
    act('zoomd', { dataset: { d: n === 'zoomin' ? '10' : n === 'zoomout' ? '-10' : '0' } });
    const h = t ? hostOf(t.url) : ''; toast('Zoom ' + (h ? siteZoom(h) : S.pageZoom) + '%', 900);
  }
  else if (n === 'fs') { A.fullscreen(!T.fs); }
};
function boot() {
  initIcons();
  applyTheme();
  mirrorAll();
  A.settings(JSON.stringify(S));
  A.ready();
  applyLayout();
  try { T = JSON.parse(A.state()); if (!T.tabs) T = { tabs: [], panes: [], active: 0, layout: 'single', total: 0 }; } catch (e) { }
  applyPC();
  if (S.pcMode) { ORIENT = 'landscape'; A.orient('landscape'); }
  renderBars();
  if (S.splash) splashRun(false);
  else { $('#splash').hidden = true; setBodyMode(false); A.chrome('bar', 130); requestAnimationFrame(() => reportBar(true)); }
}
boot();

document.addEventListener('input', e => { if (e.target && e.target.id === 'vpncfg') VPNDRAFT = e.target.value; });
