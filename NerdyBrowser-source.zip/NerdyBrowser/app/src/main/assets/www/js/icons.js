'use strict';
/* tiny stroke icon set (24x24) */
const ICONS = {
  back: 'M15 18l-6-6 6-6', fwd: 'M9 18l6-6-6-6', up: 'M6 15l6-6 6 6', down: 'M6 9l6 6 6-6',
  reload: 'M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5', x: 'M18 6L6 18M6 6l12 12',
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', plus: 'M12 5v14M5 12h14',
  star: 'M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z',
  tabs: 'M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z',
  menu: 'M12 5.5h.01M12 12h.01M12 18.5h.01',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  lock: 'M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3', unlock: 'M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 6.8-1.2',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5',
  layout: 'M3 4h18v16H3zM12 4v16M12 12h9', panes: 'M4 4h7v16H4zM13 4h7v7h-7zM13 13h7v7h-7z',
  reader: 'M4 5h16M4 10h16M4 15h10M4 20h7',
  share: 'M12 3v12M8 7l4-4 4 4M5 13v7h14v-7',
  link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
  desktop: 'M3 5h18v11H3zM8 21h8M12 16v5', code: 'M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14',
  image: 'M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M8.5 9.5h.01',
  zoom: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5M8 11h6M11 8v6',
  sliders: 'M4 7h9M17 7h3M4 17h3M11 17h9M15 4v6M9 14v6',
  bookmark: 'M6 3h12v18l-6-4-6 4z', history: 'M3 12a9 9 0 1 0 3-6.7M3 4v5h5M12 7v5l3 2',
  download: 'M12 3v12M7 11l5 5 5-5M5 21h14', full: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  flame: 'M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z',
  info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5h.01',
  exit: 'M9 4H5v16h4M16 8l4 4-4 4M20 12H9', check: 'M5 12l5 5 9-10',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13', edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  moon: 'M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z', pin: 'M12 17v5M8 3h8l-1 7 3 3H6l3-3z',
  eyeoff: 'M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.9 5.1A9.8 9.8 0 0 1 12 5c5 0 9 4 10 7a13 13 0 0 1-3 4M6.1 6.1A13 13 0 0 0 2 12c1 3 5 7 10 7a9.7 9.7 0 0 0 4-.9',
  heart: 'M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  copy: 'M9 9h11v11H9zM5 15V4h11', swap: 'M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7',
  book: 'M4 5c3-1 6-1 8 1 2-2 5-2 8-1v14c-3-1-6-1-8 1-2-2-5-2-8-1z',
  target: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
  vgrid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  vlist: 'M3 5h4v4H3zM10 6h11M10 8.5h7M3 15h4v4H3zM10 16h11M10 18.5h7',
  vcompact: 'M3 5.5h18M3 10h18M3 14.5h18M3 19h18',
  vtiles: 'M3 3h5v5H3zM9.5 3h5v5h-5zM16 3h5v5h-5zM3 9.5h5v5H3zM9.5 9.5h5v5h-5zM16 9.5h5v5h-5zM3 16h5v5H3zM9.5 16h5v5h-5zM16 16h5v5h-5z',
  vlarge: 'M3 4h18v11H3zM3 18.5h12M3 21h8',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z', pause: 'M8 5v14M16 5v14', play: 'M7 4l13 8-13 8z', gauge: 'M4 18a9 9 0 1 1 16 0M12 18l4-6', wifi: 'M2 9a15 15 0 0 1 20 0M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.01',
};
function ic(name, size, sw) {
  const d = ICONS[name] || '';
  const heavy = name === 'menu' ? 3.4 : (sw || 2);
  return '<svg class="ic" width="' + (size || 20) + '" height="' + (size || 20) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + heavy + '" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
}
