'use strict';
/* ===== NerdyBrowser · panels: menu, tabs, layouts, bookmarks, history, shield, settings ===== */
const icf = (n, s) => ic(n, s).replace('fill="none"', 'fill="currentColor"');
const head = (title, extra, sub) => '<div class="ph"><h2>' + esc(title) + (sub ? '<div class="sub">' + esc(sub) + '</div>' : '') + '</h2>' + (extra || '') + '<button class="ib" data-act="close" aria-label="Close">' + ic('x') + '</button></div>';

/* ---------- quick menu ---------- */
function menuHTML() {
  const t = curTab(), pageless = !t || isHomeUrl(t.url);
  const bm = t && !pageless && isBookmarked(t.url);
  const tile = (act, icon, label, on, cls) => '<button class="mt' + (on ? ' on' : '') + (cls ? ' ' + cls : '') + '" data-act="' + act + '">' + (icon === 'starfill' ? icf('star', 22) : ic(icon, 22)) + '<span>' + label + '</span></button>';
  return '<div class="grab"></div><div class="mgrid">' +
    tile('newtab', 'plus', 'New tab') + tile('closetab', 'x', 'Close tab') +
    tile('bookmark', bm ? 'starfill' : 'star', bm ? 'Bookmarked' : 'Bookmark', bm) + tile('bookmarks', 'bookmark', 'Bookmarks') +
    tile('find', 'search', 'Find in page') + tile('reader', 'reader', 'Reader mode') +
    tile('share', 'share', 'Share') + tile('copylink', 'link', 'Copy link') +
    tile('desktop', 'desktop', 'Desktop site', t && t.desktop) + tile('dark', 'moon', 'Dark page', t && t.dark) +
    tile('tjs', 'code', 'JavaScript', t && t.js) + tile('timg', 'image', 'Images', t && t.images) +
    tile('zoom', 'zoom', 'Zoom') + tile('layout', 'layout', 'Layouts') +
    tile('tabs', 'tabs', 'All tabs') + tile('fullscreen', 'full', 'Full screen') +
    tile('print', 'download', 'Print / PDF') + tile('history', 'history', 'History') +
    tile('downloads', 'download', 'Downloads') + tile('settings', 'sliders', 'Settings') +
    tile('burn', 'flame', 'Burn all', false, 'warn') + tile('about', 'info', 'About') +
    tile('exit', 'exit', 'Exit') + '</div>';
}

/* ---------- zoom ---------- */
function siteZoom(host) { return (S.siteZoom && S.siteZoom[host]) || S.pageZoom || 100; }
function zoomHTML() {
  const t = curTab(), host = t ? hostOf(t.url) : '';
  const z = host ? siteZoom(host) : S.pageZoom;
  return '<div class="grab"></div>' + head('Zoom', '', host ? 'Remembered for ' + host : 'Default for every page') +
    '<div class="card"><div class="row2"><button class="btn" data-act="zoomd" data-d="-10">' + ic('zoom', 16) + ' −</button><div class="grow big" style="text-align:center;font-size:34px">' + z + '%</div><button class="btn" data-act="zoomd" data-d="10">' + ic('zoom', 16) + ' +</button></div>' +
    '<div class="row2" style="margin-top:12px"><button class="btn grow" data-act="zoomd" data-d="0">Reset</button></div></div>' +
    '<div class="card"><h3>Text size</h3><input type="range" min="60" max="220" step="10" value="' + S.textZoom + '" data-k="textZoom" data-rng><div class="xs mute">' + S.textZoom + '% · applies to every page</div></div>';
}

/* ---------- tabs ---------- */
function tabsHTML() {
  const cards = T.tabs.map(t => {
    const pi = T.panes.indexOf(t.id), act = T.panes[T.active] === t.id;
    return '<div class="tcard' + (act ? ' act' : '') + '" data-act="tabpick" data-id="' + t.id + '"><b>' + esc(t.title || 'New tab') + '</b><small>' + esc(t.url ? hostOf(t.url) : 'New tab') + '</small>' +
      (T.panes.length > 1 && pi >= 0 ? '<span class="pn">pane ' + (pi + 1) + '</span>' : '') +
      '<button class="x" data-act="tabclose" data-id="' + t.id + '" aria-label="Close tab">' + ic('x', 16) + '</button></div>';
  }).join('');
  return head('Tabs (' + T.tabs.length + ')', '<button class="btn" data-act="newtab">' + ic('plus', 14) + ' New</button><button class="btn" data-act="closeall">Close all</button>') +
    '<div class="tgrid">' + cards + '</div>';
}

/* ---------- layouts ---------- */
function layoutHTML() {
  const opts = T.tabs.map(t => '<option value="' + t.id + '">' + esc((t.title || 'New tab').slice(0, 40)) + '</option>').join('');
  const sels = T.panes.map((id, i) => '<div class="row2" style="margin-bottom:8px"><b style="width:78px;font-size:13px;white-space:nowrap">Pane ' + (i + 1) + (i === T.active ? ' ●' : '') + '</b><select class="sel" data-act="panesel" data-p="' + i + '">' +
    opts.replace('value="' + id + '"', 'value="' + id + '" selected') + '</select></div>').join('');
  return head('Layouts', '', 'Choose how many pages are on screen') +
    '<div class="lgrid">' + LAYOUTS.map(l => '<button class="lopt' + (S.layout === l[0] ? ' on' : '') + '" data-act="setlayout" data-v="' + l[0] + '">' + layoutSvg(l[0]) + '<span>' + l[1] + '</span></button>').join('') + '</div>' +
    '<div class="card"><h3>Size and spacing</h3><div class="lbl" style="margin-top:0">Main pane size · ' + S.ratio + '%</div><input type="range" min="30" max="70" step="5" value="' + S.ratio + '" data-k="ratio" data-rng>' +
    '<div class="lbl">Gap between panes · ' + S.gap + ' px</div><input type="range" min="0" max="12" step="1" value="' + S.gap + '" data-k="gap" data-rng></div>' +
    (T.panes.length > 1 ? '<div class="card"><h3>What is in each pane</h3>' + sels + '<div class="xs mute">Tap a page to make its pane active. The active pane has the coloured border and is the one the address bar controls. Long-press a link and choose <b>Open in other pane</b>.</div></div>' : '<div class="card sm mute">Pick a layout with more than one pane to see two or more pages at the same time.</div>');
}

/* ---------- bookmarks ---------- */
let bmQ = '';
function bookmarksHTML() {
  const q = bmQ.toLowerCase();
  const list = BM.filter(b => !q || b.title.toLowerCase().includes(q) || b.url.toLowerCase().includes(q)).sort((a, b) => (b.pin - a.pin) || (b.ts - a.ts));
  const rows = list.map(b => '<div class="li2"><button class="lt" data-act="bmopen" data-id="' + b.id + '" style="border:0">' + esc((hostOf(b.url) || b.title || '?')[0]) + '</button>' +
    '<button class="tx" data-act="bmopen" data-id="' + b.id + '" style="border:0;background:none;padding:0"><b>' + esc(b.title) + '</b><span>' + esc(niceUrl(b.url)) + '</span></button>' +
    '<button class="ib sm" data-act="bmpin" data-id="' + b.id + '" style="' + (b.pin ? 'color:var(--acc2)' : '') + '" aria-label="Show on new tab page">' + (b.pin ? icf('pin', 17) : ic('pin', 17)) + '</button>' +
    '<button class="ib sm" data-act="bmedit" data-id="' + b.id + '" aria-label="Edit">' + ic('edit', 17) + '</button>' +
    '<button class="ib sm" data-act="bmdel" data-id="' + b.id + '" aria-label="Delete">' + ic('trash', 17) + '</button></div>').join('');
  return head('Bookmarks', '<button class="btn" data-act="bmadd">' + ic('star', 14) + ' Add page</button>') +
    '<input class="search" id="bmq" type="text" placeholder="Search bookmarks" value="' + esc(bmQ) + '">' +
    (rows || '<div class="empty">No bookmarks yet.<br>Open a page and tap Bookmark in the menu.</div>') +
    '<div class="card sm mute">The pin shows a bookmark as a shortcut on the New tab page.</div>';
}

/* ---------- history ---------- */
let hiQ = '';
function historyHTML() {
  if (!S.saveHistory) return head('History') + '<div class="empty">History is <b>off</b>, so nothing about the pages you visit is saved. That is the private default.</div><div style="text-align:center"><button class="btn" data-act="tog" data-k="saveHistory">Turn history on</button></div>';
  const q = hiQ.toLowerCase();
  const list = HIST.filter(h => !q || h.t.toLowerCase().includes(q) || h.u.toLowerCase().includes(q)).slice(0, 150);
  const rows = list.map(h => '<button class="li2" data-act="urlopen" data-u="' + esc(h.u) + '" style="width:100%;border-left:0;border-right:0;border-top:0;background:none"><span class="lt">' + esc((hostOf(h.u) || '?')[0]) + '</span><span class="tx"><b>' + esc(h.t || hostOf(h.u)) + '</b><span>' + esc(niceUrl(h.u)) + '</span></span></button>').join('');
  return head('History', '<button class="btn warn" data-act="clearhist">' + ic('trash', 14) + ' Clear</button>') + '<input class="search" id="hiq" type="text" placeholder="Search history" value="' + esc(hiQ) + '">' + (rows || '<div class="empty">Nothing here yet.</div>');
}

/* ---------- shield ---------- */
let shieldStats = { hosts: {}, page: 0, total: 0 };
function shieldHTML() {
  const t = curTab(), host = t && !isHomeUrl(t.url) ? hostOf(t.url) : '';
  const on = !host || !S.siteAllow.includes(host);
  const hosts = Object.entries(shieldStats.hosts || {}).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const max = hosts.length ? hosts[0][1] : 1;
  return head('Shield', '', host ? host : 'New tab') +
    '<div class="card"><div class="row2"><div class="grow"><div class="big">' + (t ? t.blocked : 0) + '</div><div class="sm mute">blocked on this page</div></div>' +
    '<div style="text-align:right"><div style="font-size:24px;font-weight:700">' + STATS.blocked + '</div><div class="xs mute">since ' + new Date(STATS.since).toLocaleDateString() + '</div></div></div>' +
    (host ? '<div class="srow" style="margin-top:8px"><div class="tx"><b>Shield on for ' + esc(host) + '</b><span>Turn off only if this site breaks. It also switches off the privacy script here.</span></div><button class="sw' + (on ? ' on' : '') + '" data-act="siteshield" data-h="' + esc(host) + '"></button></div>' : '') + '</div>' +
    '<div class="card"><h3>Blocking level</h3><div class="seg">' + [['off', 'Off'], ['standard', 'Standard'], ['strict', 'Strict'], ['ultra', 'Ultra']].map(o => '<button class="' + (S.shield === o[0] ? 'on' : '') + '" data-act="seg" data-k="shield" data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>' +
    '<div class="xs mute" style="margin-top:8px">Standard stops known ad and tracker domains. Strict adds tracking URL patterns on other sites. Ultra also blocks every third-party script and frame, which is the safest and the most likely to break pages.</div></div>' +
    '<div class="card"><h3>Blocked on this page</h3>' + (hosts.length ? hosts.map(h => '<div class="xs" style="margin-top:8px"><div class="row2"><span class="grow" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(h[0]) + '</span><b>' + h[1] + '</b></div><div class="bar2"><i style="width:' + Math.max(6, h[1] / max * 100) + '%"></i></div></div>').join('') : '<div class="sm mute">Nothing blocked here yet.</div>') + '</div>' +
    '<div class="card"><h3>Also on</h3><div class="wrap gap6">' + [['HTTPS-only', S.httpsOnly], ['Popups: ' + S.popups, S.popups !== 'allow'], ['Fingerprint shield', S.spoof], ['WebRTC off', S.noWebrtc], ['No 3rd-party cookies', S.cookies !== 'all'], ['Clean links', S.stripParams], ['Cookie banners hidden', S.consent]].map(c => '<span class="chip2" style="' + (c[1] ? '' : 'opacity:.4;text-decoration:line-through') + '">' + esc(c[0]) + '</span>').join('') + '</div></div>';
}

/* ---------- settings ---------- */
const FONTS_R = [['serif', 'Serif'], ['sans', 'Sans']];
const SCHEMA = [
  { id: 'look', icon: 'sliders', title: 'Look and feel', items: [
    { t: 'themes' },
    { k: 'accent', t: 'color', label: 'Custom accent colour', desc: 'Overrides the theme colour. Reset to use the theme again.' },
    { k: 'toolbarPos', t: 'seg', label: 'Toolbar position', opts: [['top', 'Top'], ['bottom', 'Bottom (thumb reach)']] },
    { k: 'density', t: 'seg', label: 'Toolbar size', opts: [['normal', 'Roomy'], ['compact', 'Compact']] },
    { k: 'tabStrip', t: 'toggle', label: 'Show tab strip', desc: 'Small tabs under the address bar.' },
    { k: 'splash', t: 'toggle', label: 'Welcome animation' },
    { k: 'splashStyle', t: 'seg', label: 'Welcome style', opts: [['draw', 'Shield draws'], ['orbit', 'Orbit'], ['pulse', 'Pulse']] },
    { t: 'btn', label: 'Replay welcome', act: 'splashplay' },
  ] },
  { id: 'lay', icon: 'layout', title: 'Layouts, zoom and pages', items: [
    { t: 'btn', label: 'Choose a layout…', act: 'layout' },
    { k: 'ratio', t: 'range', label: 'Main pane size', min: 30, max: 70, step: 5, unit: '%' },
    { k: 'gap', t: 'range', label: 'Gap between panes', min: 0, max: 12, step: 1, unit: ' px' },
    { k: 'textZoom', t: 'range', label: 'Text size', min: 60, max: 220, step: 10, unit: '%' },
    { k: 'pageZoom', t: 'range', label: 'Default page zoom', min: 50, max: 250, step: 10, unit: '%', desc: 'Per-site zoom is in Menu → Zoom.' },
    { k: 'forceZoom', t: 'toggle', label: 'Allow pinch-zoom on every page', desc: 'Even on sites that try to lock zoom.' },
    { k: 'desktopDefault', t: 'toggle', label: 'Desktop sites by default' },
    { k: 'darkPages', t: 'seg', label: 'Dark pages', opts: [['off', 'Off'], ['auto', 'With dark theme'], ['on', 'Always']] },
    { k: 'readerTheme', t: 'seg', label: 'Reader mode colours', opts: [['paper', 'Paper'], ['sepia', 'Sepia'], ['night', 'Night']] },
    { k: 'readerFont', t: 'seg', label: 'Reader mode font', opts: FONTS_R },
    { k: 'readerSize', t: 'range', label: 'Reader mode text', min: 14, max: 30, step: 1, unit: ' px' },
  ] },
  { id: 'shield', icon: 'shield', title: 'Shield: ads, trackers, popups', items: [
    { k: 'shield', t: 'seg', label: 'Blocking level', opts: [['off', 'Off'], ['standard', 'Standard'], ['strict', 'Strict'], ['ultra', 'Ultra']], desc: 'Ultra blocks all third-party scripts and frames. Safest, but some sites break. Turn the shield off per site from the shield button.' },
    { k: 'popups', t: 'seg', label: 'Popups and new windows', opts: [['block', 'Block all'], ['gesture', 'Only if I tap'], ['allow', 'Allow']] },
    { k: 'blockDialogs', t: 'toggle', label: 'Block alert / confirm boxes', desc: 'Stops fake "you won" and "virus found" boxes. (After 3 on one page they are blocked anyway.)' },
    { k: 'cosmetic', t: 'toggle', label: 'Hide empty ad slots and frames' },
    { k: 'consent', t: 'toggle', label: 'Hide cookie and consent banners' },
    { k: 'stripParams', t: 'toggle', label: 'Clean tracking out of links', desc: 'Removes utm_*, fbclid, gclid and similar from addresses.' },
    { k: 'blockExternal', t: 'toggle', label: 'Block links that open other apps', desc: 'mailto and tel links still ask you first.' },
    { k: 'blockAutoplay', t: 'toggle', label: 'Block autoplay of video and sound' },
    { k: 'customBlock', t: 'list', label: 'My own blocked domains', desc: 'One per line, like ads.example.com. Subdomains are blocked too.' },
    { k: 'siteAllow', t: 'list', label: 'Sites where the shield is off', desc: 'One per line. Normally managed from the shield button.' },
  ] },
  { id: 'priv', icon: 'lock', title: 'Privacy and security', items: [
    { k: 'httpsOnly', t: 'toggle', label: 'HTTPS only', desc: 'Upgrades every link to a secure connection. If a site has none, you are asked before using plain HTTP.' },
    { k: 'cookies', t: 'seg', label: 'Cookies', opts: [['all', 'Allow all'], ['first', 'No third-party'], ['none', 'None']] },
    { k: 'spoof', t: 'toggle', label: 'Fingerprint shield', desc: 'Makes the phone look less unique (hardware, language, canvas).' },
    { k: 'noWebrtc', t: 'toggle', label: 'Block WebRTC', desc: 'Stops sites finding your real network address. Video calls in the browser will not work while on.' },
    { k: 'noBeacon', t: 'toggle', label: 'Block tracking beacons' },
    { k: 'gpc', t: 'toggle', label: 'Send Do-Not-Track and Global Privacy Control' },
    { k: 'referrer', t: 'seg', label: 'Tell sites where I came from', opts: [['default', 'Normal'], ['origin', 'Site only'], ['none', 'Never']] },
    { k: 'safeBrowsing', t: 'toggle', label: 'Google Safe Browsing', desc: 'Warns about dangerous sites, but sends small hashes of addresses to Google. Off by default to keep the app silent.' },
    { k: 'js', t: 'toggle', label: 'JavaScript on for new tabs', desc: 'Switch it off per tab from the menu for the safest reading.' },
    { k: 'images', t: 'toggle', label: 'Load images in new tabs' },
    { k: 'ua', t: 'seg', label: 'Browser identity', opts: [['default', 'Standard'], ['custom', 'Custom']] },
    { k: 'customUA', t: 'text', label: 'Custom identity string', ph: 'Mozilla/5.0 …' },
    { t: 'info', text: 'Camera, microphone and location are always refused for every site. The app only holds the internet permission.' },
  ] },
  { id: 'data', icon: 'flame', title: 'Data and history', items: [
    { k: 'wipeExit', t: 'toggle', label: 'Wipe cookies and site data when I close the app', desc: 'Your bookmarks and settings are kept.' },
    { k: 'noCache', t: 'toggle', label: 'Never store page cache', desc: 'A little slower, leaves less behind.' },
    { k: 'saveHistory', t: 'toggle', label: 'Save history on this phone', desc: 'Off by default.' },
    { k: 'restoreTabs', t: 'toggle', label: 'Reopen my tabs next time', desc: 'Off by default.' },
    { t: 'btn', label: 'Clear cookies', act: 'clearcookies' },
    { t: 'btn', label: 'Clear cache', act: 'clearcache' },
    { t: 'btn', label: 'Clear history', act: 'clearhist' },
    { t: 'btn', label: 'Burn everything now', act: 'burn', cls: 'warn' },
  ] },
  { id: 'search', icon: 'search', title: 'Search and home', items: [
    { k: 'engine', t: 'select', label: 'Search engine', opts: Object.keys(ENGINES).map(k => [k, ENGINES[k][0]]) },
    { k: 'customEngine', t: 'text', label: 'My own search address', ph: 'https://example.com/?q=%s', desc: 'Use %s where the search words go. Used when the engine above is "My own".' },
    { k: 'home', t: 'text', label: 'Home page', ph: 'Blank = the NerdyBrowser start page', desc: 'Opens with the home button.' },
    { k: 'ntDial', t: 'toggle', label: 'Show shortcuts on the start page' },
    { k: 'ntStats', t: 'toggle', label: 'Show the "blocked so far" counter' },
    { k: 'ntTips', t: 'toggle', label: 'Show a privacy tip' },
    { k: 'ntStyle', t: 'seg', label: 'Start page style', opts: [['glow', 'Glow'], ['plain', 'Plain'], ['grid', 'Dotted']] },
    { k: 'ntName', t: 'text', label: 'Name on the start page greeting', ph: 'Optional' },
  ] },
  { id: 'dev', icon: 'eyeoff', title: 'Device', items: [
    { k: 'secure', t: 'toggle', label: 'Hide from screenshots and app switcher', desc: 'Blocks screenshots too, so leave it off when you want to take one.' },
    { k: 'appLock', t: 'toggle', label: 'Ask for my phone unlock to open', desc: 'Uses your fingerprint, face, PIN or pattern. Needs a screen lock set on the phone.' },
    { k: 'keepScreen', t: 'toggle', label: 'Keep screen on while browsing' },
    { k: 'askDownload', t: 'toggle', label: 'Ask before downloading' },
    { t: 'btn', label: 'Open Downloads', act: 'downloads' },
  ] },
  { id: 'bk', icon: 'copy', title: 'Backup and reset', items: [
    { t: 'btn', label: 'Export bookmarks and settings', act: 'export' },
    { t: 'btn', label: 'Import from pasted text', act: 'import' },
    { t: 'btn', label: 'Reset all settings', act: 'resetset', cls: 'warn' },
  ] },
];
const openSecs = new Set(['look']);

function settingRow(it) {
  const v = S[it.k];
  const tx = '<div class="tx"><b>' + esc(it.label || '') + '</b>' + (it.desc ? '<span>' + esc(it.desc) + '</span>' : '') + '</div>';
  switch (it.t) {
    case 'toggle': return '<div class="srow">' + tx + '<button class="sw' + (v ? ' on' : '') + '" data-act="tog" data-k="' + it.k + '" aria-label="' + esc(it.label) + '"></button></div>';
    case 'seg': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<div class="seg">' + it.opts.map(o => '<button class="' + (v === o[0] ? 'on' : '') + '" data-act="seg" data-k="' + it.k + '" data-v="' + o[0] + '">' + esc(o[1]) + '</button>').join('') + '</div></div>';
    case 'range': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<input type="range" min="' + it.min + '" max="' + it.max + '" step="' + it.step + '" value="' + v + '" data-k="' + it.k + '" data-rng data-unit="' + esc(it.unit || '') + '"><div class="xs mute rv">' + v + (it.unit || '') + '</div></div>';
    case 'text': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<input class="tin" type="text" value="' + esc(v) + '" placeholder="' + esc(it.ph || '') + '" data-k="' + it.k + '" data-txt autocomplete="off" spellcheck="false"></div>';
    case 'list': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<textarea class="tarea" data-k="' + it.k + '" data-list spellcheck="false" autocomplete="off">' + esc((v || []).join('\n')) + '</textarea></div>';
    case 'select': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<select class="sel" style="margin-top:8px" data-k="' + it.k + '" data-sel>' + it.opts.map(o => '<option value="' + o[0] + '"' + (v === o[0] ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select></div>';
    case 'color': return '<div class="srow">' + tx + '<div class="row2"><input type="color" value="' + (/^#[0-9a-f]{6}$/i.test(v || '') ? v : '#f0642f') + '" data-k="' + it.k + '" data-col style="width:44px;height:34px;border:0;background:none;padding:0"><button class="btn" data-act="accentreset">Reset</button></div></div>';
    case 'btn': return '<div style="padding:6px 0"><button class="btn ' + (it.cls || '') + '" data-act="' + it.act + '" style="width:100%;justify-content:center">' + esc(it.label) + '</button></div>';
    case 'info': return '<div class="xs mute" style="padding:10px 0;line-height:1.5">' + esc(it.text) + '</div>';
    case 'themes': return '<div class="lbl" style="margin-top:4px">Colour theme</div><div class="tsw-grid">' + Object.keys(THEMES).map(k => { const t = THEMES[k]; return '<button class="tsw' + (S.theme === k ? ' on' : '') + '" data-act="theme" data-v="' + k + '" style="--a:' + t.a + ';--b:' + t.b + ';--c:' + t.c + ';--tx:' + t.t + '"><i></i><b>' + t.n + '</b></button>'; }).join('') + '</div>';
  }
  return '';
}
function settingsHTML() {
  return head('Settings', '', 'Everything is saved on this phone only') + SCHEMA.map(sec =>
    '<details class="sec" data-sec="' + sec.id + '"' + (openSecs.has(sec.id) ? ' open' : '') + '><summary><span class="ico">' + ic(sec.icon, 16) + '</span>' + esc(sec.title) + '<span class="chev">' + ic('down', 18) + '</span></summary><div class="in">' + sec.items.map(settingRow).join('') + '</div></details>').join('') +
    '<div class="card sm mute" style="text-align:center">NerdyBrowser 1.0 · no account, no analytics, no tracking</div>';
}

/* ---------- which panel is which ---------- */
const PANELS = {
  menu: { sheet: true, html: menuHTML },
  zoom: { sheet: true, html: zoomHTML },
  tabs: { html: tabsHTML },
  layout: { html: layoutHTML },
  bookmarks: { html: bookmarksHTML },
  history: { html: historyHTML },
  shield: { html: shieldHTML },
  settings: { html: settingsHTML },
  about: { html: aboutHTML, mount: aboutMount },
};
