'use strict';
/* ===== NerdyBrowser · panels: menu, tabs, layouts, bookmarks, history, shield, settings ===== */
const icf = (n, s) => ic(n, s).replace('fill="none"', 'fill="currentColor"');
const head = (title, extra, sub) => '<div class="ph"><h2>' + esc(title) + (sub ? '<div class="sub">' + esc(sub) + '</div>' : '') + '</h2>' + (extra || '') + '<button class="ib" data-act="close" aria-label="Close">' + ic('x') + '</button></div>';

/* ---------- quick menu ---------- */
const REFRESH_STEPS = [0, 5, 15, 30, 60, 300];
const fmtSec = n => (n >= 60 ? (n / 60) + ' min' : n + ' s');
function menuHTML() {
  const t = curTab(), pageless = !t || isHomeUrl(t.url);
  const bm = t && !pageless && isBookmarked(t.url);
  const tile = (act, icon, label, on, cls) => '<button class="mt' + (on ? ' on' : '') + (cls ? ' ' + cls : '') + '" data-act="' + act + '">' + (icon === 'starfill' ? icf('star', 22) : ic(icon, 22)) + '<span>' + label + '</span></button>';
  const group = (title, tint, tiles) => '<div class="mg g-' + tint + '"><div class="mgt">' + title + '</div><div class="mgrid">' + tiles + '</div></div>';
  const host = pageless ? 'Start page' : hostOf(t.url);
  const title = pageless ? 'NerdyBrowser' : (t.title || host);
  const quick = (act, icon, label, on) => '<button class="mq' + (on ? ' on' : '') + '" data-act="' + act + '" aria-label="' + label + '">' + (icon === 'starfill' ? icf('star', 20) : ic(icon, 20)) + '<span>' + label + '</span></button>';
  return '<div class="grab"></div>' +
    '<div class="mhead"><div class="mfav">' + esc((host || 'N').replace(/^www\./, '').charAt(0).toUpperCase()) + '</div><div class="mhi"><b>' + esc(title) + '</b><small>' + esc(host) + ' · ' + (STATS.blocked || 0).toLocaleString() + ' blocked so far</small></div></div>' +
    '<div class="mquick">' + quick('back', 'back', 'Back') + quick('fwd', 'fwd', 'Forward') + quick('reload', 'reload', 'Reload') + quick('bookmark', bm ? 'starfill' : 'star', bm ? 'Saved' : 'Save', bm) + quick('share', 'share', 'Share') + '</div>' +
    group('This page', 'a',
      tile('newtab', 'plus', 'New tab') + tile('dupcur', 'copy', 'Duplicate') + tile('closetab', 'x', 'Close tab') + tile('find', 'search', 'Find in page') +
      tile('reader', 'reader', 'Reader mode') + tile('pick', 'target', 'Hide element') + tile('copylink', 'link', 'Copy link') + tile('extopen', 'exit', 'Open in other app') +
      tile('addapp', 'layout', 'Add to home screen') + tile('print', 'download', 'Print / PDF') + tile('media', 'image', 'Save media') + tile('refresh', 'reload', t && t.refresh ? 'Refresh ' + fmtSec(t.refresh) : 'Auto refresh', t && t.refresh)) +
    group('View', 'b',
      tile('pctoggle', 'desktop', S.pcMode ? 'PC mode: ON' : 'PC mode', S.pcMode) + tile('desktop', 'desktop', 'Desktop site', t && t.desktop) + tile('dark', 'moon', 'Dark page', t && t.dark) + tile('tjs', 'code', 'JavaScript', t && t.js) + tile('timg', 'image', 'Images', t && t.images) +
      tile('zoom', 'zoom', 'Zoom') + tile('layout', 'layout', 'Layouts') + tile('fullscreen', 'full', 'Full screen') + tile('phonebars', 'eyeoff', S.alwaysFull ? 'Phone bars hidden' : 'Hide phone bars', S.alwaysFull) +
      tile('rotate', 'swap', 'Rotate: ' + ORIENT) + tile('immersive', 'bolt', 'Immersive desktop') + tile('tabs', 'tabs', 'All tabs')) +
    group('Library', 'c', tile('closed', 'history', 'Closed tabs') + tile('bookmarks', 'bookmark', 'Bookmarks') + tile('downloads', 'download', 'Downloads') + tile('history', 'history', 'History')) +
    group('Privacy and app', 'd',
      tile('vpn', 'lock', VPN.up ? 'VPN on' : 'VPN', VPN.up) + tile('shield', 'shield', 'Shield') + tile('settings', 'sliders', 'Settings') + tile('cmd', 'search', 'Command palette') + tile('keys', 'code', 'Shortcuts') + tile('about', 'info', 'About') +
      tile('burn', 'flame', 'Burn all', false, 'warn') + tile('exit', 'exit', 'Exit'));
}

/* ---------- keyboard shortcuts, closed tabs, command palette ---------- */
const SHORTCUTS = [
  ['Tabs', [['Ctrl + T', 'New tab'], ['Ctrl + W', 'Close tab'], ['Ctrl + Shift + T', 'Reopen closed tab'], ['Ctrl + Tab / PgDn', 'Next tab'], ['Ctrl + Shift + Tab / PgUp', 'Previous tab'], ['Ctrl + 1 … 8', 'Go to tab 1 … 8'], ['Ctrl + 9', 'Last tab'], ['Ctrl + Shift + A', 'All tabs']]],
  ['Page', [['Ctrl + L / K / E, Alt + D, F6', 'Address bar'], ['Ctrl + R, F5', 'Reload'], ['Alt + Left / Right', 'Back / Forward'], ['Alt + Home', 'Home'], ['Ctrl + F', 'Find in page'], ['Ctrl + G / F3', 'Next match'], ['Ctrl + Shift + G / Shift + F3', 'Previous match'], ['Ctrl + P', 'Print / PDF']]],
  ['View', [['Ctrl + Plus / Minus / 0', 'Zoom in / out / reset'], ['F11', 'Hide or show phone bars']]],
  ['Library', [['Ctrl + D', 'Bookmark this page'], ['Ctrl + Shift + O', 'Bookmarks'], ['Ctrl + H', 'History'], ['Ctrl + J', 'Downloads'], ['Ctrl + ,', 'Settings']]],
  ['Power', [['Ctrl + Shift + P', 'Command palette: type to find any action'], ['Ctrl + /', 'This list']]],
];
function keysHTML() {
  return head('Keyboard shortcuts', '', 'Work with a Bluetooth or USB keyboard, in normal and PC mode') +
    SHORTCUTS.map(g => '<div class="card"><h3>' + g[0] + '</h3>' + g[1].map(r => '<div class="row2" style="padding:5px 0;gap:10px"><kbd style="flex:none;padding:3px 8px;border-radius:8px;background:var(--soft);border:1px solid var(--line);font:600 12px ui-monospace,monospace">' + esc(r[0]) + '</kbd><span class="grow xs" style="text-align:right">' + esc(r[1]) + '</span></div>').join('') + '</div>').join('') +
    '<div class="card sm mute">Tip: on a phone without a keyboard you get the same things from the Menu. Closed tabs: Menu > Closed tabs.</div>';
}
let CLOSED = [];
function closedHTML() {
  try { CLOSED = JSON.parse(A.closedJson()); } catch (e) { CLOSED = []; }
  const rows = CLOSED.map((c, i) => '<button class="li2" data-act="reopenat" data-i="' + i + '" style="width:100%;border-left:0;border-right:0;border-top:0;background:none"><span class="lt">' + esc((hostOf(c.url) || '?')[0]) + '</span><span class="tx"><b>' + esc(c.title || hostOf(c.url)) + '</b><span>' + esc(niceUrl(c.url)) + '</span></span></button>').join('');
  return head('Closed tabs', CLOSED.length ? '<button class="btn warn" data-act="clearclosed">' + ic('trash', 14) + ' Clear</button>' : '') + (rows || '<div class="empty">No closed tabs yet. Close a tab and it shows up here (Ctrl+Shift+T brings back the last one).</div>');
}
const CMDS = [
  ['New tab', 'newtab'], ['Close tab', 'closetab'], ['Reopen closed tab', 'reopen'], ['Closed tabs', 'closed'], ['All tabs', 'tabs'], ['Duplicate tab', 'dupcur'],
  ['Reload', 'reload'], ['Back', 'back'], ['Forward', 'fwd'], ['Home', 'home'], ['Find in page', 'find'], ['Bookmark this page', 'bookmark'], ['Bookmarks', 'bookmarks'],
  ['History', 'history'], ['Downloads', 'downloads'], ['Save media on page', 'media'], ['Reader mode', 'reader'], ['Print / PDF', 'print'], ['Share', 'share'], ['Copy link', 'copylink'],
  ['Desktop site (this tab)', 'desktop'], ['PC mode on / off', 'pctoggle'], ['Dark page', 'dark'], ['Zoom', 'zoom'], ['Layouts', 'layout'], ['Full screen', 'fullscreen'],
  ['Hide or show phone bars', 'phonebars'], ['Rotate screen', 'rotate'], ['Shield', 'shield'], ['VPN', 'vpn'], ['Settings', 'settings'], ['Keyboard shortcuts', 'keys'], ['About', 'about'], ['Burn all', 'burn'],
];
let cmQ = '';
function cmdHTML() {
  const q = cmQ.toLowerCase().trim();
  const list = CMDS.filter(c => !q || c[0].toLowerCase().includes(q)).slice(0, 14);
  return head('Command palette') + '<input class="search" id="cmq" type="text" placeholder="Type what you want to do" autocomplete="off" value="' + esc(cmQ) + '">' +
    list.map(c => '<button class="li2" data-act="cmdrun" data-c="' + c[1] + '" style="width:100%;border-left:0;border-right:0;border-top:0;background:none"><span class="tx"><b>' + esc(c[0]) + '</b></span></button>').join('') +
    (q && /^(https?:\/\/|[\w-]+\.[a-z]{2,})/i.test(q) ? '<button class="li2" data-act="urlopen" data-u="' + esc(cmQ.trim()) + '" style="width:100%;background:none"><span class="tx"><b>Go to ' + esc(cmQ.trim()) + '</b></span></button>' : '') +
    (!list.length && !q ? '' : '');
}

/* ---------- zoom ---------- */
function siteZoom(host) { return (S.siteZoom && S.siteZoom[host]) || S.pageZoom || 100; }
function zoomHTML() {
  const t = curTab(), host = t ? hostOf(t.url) : '';
  const z = host ? siteZoom(host) : S.pageZoom;
  return '<div class="grab"></div>' + head('Zoom', '', host ? 'Remembered for ' + host : 'Default for every page') +
    '<div class="card"><div class="row2"><button class="btn" data-act="zoomd" data-d="-10">' + ic('zoom', 16) + ' −</button><div class="grow big" style="text-align:center;font-size:34px">' + z + '%</div><button class="btn" data-act="zoomd" data-d="10">' + ic('zoom', 16) + ' +</button></div>' +
    '<div class="row2" style="margin-top:12px"><button class="btn grow" data-act="zoomd" data-d="0">Reset</button></div></div>' +
    '<div class="card"><h3>Text size</h3><input type="range" min="60" max="220" step="10" value="' + S.textZoom + '" data-k="textZoom" data-rng><div class="xs mute">' + S.textZoom + '% · applies to every page</div></div>';
}

/* ---------- tabs ---------- */
function tabsHTML() {
  const cards = T.tabs.map(t => {
    const pi = T.panes.indexOf(t.id), act = T.panes[T.active] === t.id;
    return '<div class="tcard' + (act ? ' act' : '') + '" data-act="tabpick" data-id="' + t.id + '"><b>' + esc(t.title || 'New tab') + '</b><small>' + esc(t.url ? hostOf(t.url) : 'New tab') + '</small>' +
      (T.panes.length > 1 && pi >= 0 ? '<span class="pn">pane ' + (pi + 1) + '</span>' : '') +
      '<button class="x" data-act="tabclose" data-id="' + t.id + '" aria-label="Close tab">' + ic('x', 16) + '</button>' +
      '<span class="tm"><button data-act="tabmove" data-id="' + t.id + '" data-d="-1" aria-label="Move left">' + ic('back', 15) + '</button><button data-act="tabmove" data-id="' + t.id + '" data-d="1" aria-label="Move right">' + ic('fwd', 15) + '</button><button data-act="tabdup" data-id="' + t.id + '" aria-label="Duplicate">' + ic('copy', 15) + '</button></span></div>';
  }).join('');
  return head('Tabs (' + T.tabs.length + ')', '<button class="btn" data-act="newtab">' + ic('plus', 14) + ' New</button><button class="btn" data-act="closeall">Close all</button>') +
    '<div class="tgrid">' + cards + '</div>';
}

/* ---------- layouts ---------- */
function layoutHTML() {
  const opts = T.tabs.map(t => '<option value="' + t.id + '">' + esc((t.title || 'New tab').slice(0, 40)) + '</option>').join('');
  const sels = T.panes.map((id, i) => '<div class="row2" style="margin-bottom:8px"><b style="width:78px;font-size:13px;white-space:nowrap">Pane ' + (i + 1) + (i === T.active ? ' ●' : '') + '</b><select class="sel" data-act="panesel" data-p="' + i + '">' +
    opts.replace('value="' + id + '"', 'value="' + id + '" selected') + '</select></div>').join('');
  return head('Layouts', '', 'Choose how many pages are on screen') +
    '<div class="lgrid">' + LAYOUTS.map(l => '<button class="lopt' + (S.layout === l[0] ? ' on' : '') + '" data-act="setlayout" data-v="' + l[0] + '">' + layoutSvg(l[0]) + '<span>' + l[1] + '</span></button>').join('') + '</div>' +
    '<div class="card"><h3>Size and spacing</h3><div class="lbl" style="margin-top:0">Main pane size · ' + S.ratio + '%</div><input type="range" min="30" max="70" step="5" value="' + S.ratio + '" data-k="ratio" data-rng>' +
    '<div class="lbl">Gap between panes · ' + S.gap + ' px</div><input type="range" min="0" max="12" step="1" value="' + S.gap + '" data-k="gap" data-rng></div>' +
    (T.panes.length > 1 ? '<div class="card"><h3>Arrange</h3><div class="wrap gap"><button class="btn" data-act="swappanes">' + ic('swap', 15) + ' Swap 1 and 2</button>' + (T.panes.length > 2 ? '<button class="btn" data-act="rotatepanes">' + ic('reload', 15) + ' Rotate panes</button>' : '') + '<button class="btn" data-act="resetsizes">Reset sizes</button></div><div class="xs mute" style="margin-top:8px">' + (S.layout === 'custom' ? 'Custom sizes in use. ' : '') + 'Drag the thin handles between panes on the page to resize them. Your sizes are remembered.</div></div><div class="card"><h3>What is in each pane</h3>' + sels + '<div class="xs mute">Tap a page to make its pane active. The active pane has the coloured border and is the one the address bar controls. Long-press a link and choose <b>Open in other pane</b>.</div></div>' : '<div class="card sm mute">Pick a layout with more than one pane to see two or more pages at the same time.</div>');
}

/* ---------- bookmarks ---------- */
let bmQ = '';
function bookmarksHTML() {
  const q = bmQ.toLowerCase();
  const list = BM.filter(b => !q || b.title.toLowerCase().includes(q) || b.url.toLowerCase().includes(q)).sort((a, b) => (b.pin - a.pin) || (b.ts - a.ts));
  const rows = list.map(b => '<div class="li2"><button class="lt" data-act="bmopen" data-id="' + b.id + '" style="border:0">' + esc((hostOf(b.url) || b.title || '?')[0]) + '</button>' +
    '<button class="tx" data-act="bmopen" data-id="' + b.id + '" style="border:0;background:none;padding:0"><b>' + esc(b.title) + '</b><span>' + esc(niceUrl(b.url)) + '</span></button>' +
    '<button class="ib sm" data-act="bmapp" data-id="' + b.id + '" aria-label="Add to home screen as an app">' + ic('desktop', 17) + '</button>' +
    '<button class="ib sm" data-act="bmpin" data-id="' + b.id + '" style="' + (b.pin ? 'color:var(--acc2)' : '') + '" aria-label="Show on new tab page">' + (b.pin ? icf('pin', 17) : ic('pin', 17)) + '</button>' +
    '<button class="ib sm" data-act="bmedit" data-id="' + b.id + '" aria-label="Edit">' + ic('edit', 17) + '</button>' +
    '<button class="ib sm" data-act="bmdel" data-id="' + b.id + '" aria-label="Delete">' + ic('trash', 17) + '</button></div>').join('');
  return head('Bookmarks', '<button class="btn" data-act="bmimport">' + ic('download', 14) + ' Import</button><button class="btn" data-act="bmadd">' + ic('star', 14) + ' Add</button>') +
    '<input class="search" id="bmq" type="text" placeholder="Search bookmarks" value="' + esc(bmQ) + '">' +
    (rows || '<div class="empty">No bookmarks yet.<br>Open a page and tap Bookmark in the menu.</div>') +
    '<div class="card sm mute">The pin shows a bookmark as a shortcut on the New tab page. The screen icon adds it to your phone home screen as an app: it opens straight into that site, full screen, with no browser bars (Back leaves it).</div>';
}

/* ---------- history ---------- */
let hiQ = '';
function historyHTML() {
  if (!S.saveHistory) return head('History') + '<div class="empty">History is <b>off</b>, so nothing about the pages you visit is saved. That is the private default.</div><div style="text-align:center"><button class="btn" data-act="tog" data-k="saveHistory">Turn history on</button></div>';
  const q = hiQ.toLowerCase();
  const list = HIST.filter(h => !q || h.t.toLowerCase().includes(q) || h.u.toLowerCase().includes(q)).slice(0, 150);
  const rows = list.map(h => '<button class="li2" data-act="urlopen" data-u="' + esc(h.u) + '" style="width:100%;border-left:0;border-right:0;border-top:0;background:none"><span class="lt">' + esc((hostOf(h.u) || '?')[0]) + '</span><span class="tx"><b>' + esc(h.t || hostOf(h.u)) + '</b><span>' + esc(niceUrl(h.u)) + '</span></span></button>').join('');
  return head('History', '<button class="btn warn" data-act="clearhist">' + ic('trash', 14) + ' Clear</button>') + '<input class="search" id="hiq" type="text" placeholder="Search history" value="' + esc(hiQ) + '">' + (rows || '<div class="empty">Nothing here yet.</div>');
}

/* ---------- shield ---------- */
let shieldStats = { hosts: {}, page: 0, total: 0 };
function shieldHTML() {
  const t = curTab(), host = t && !isHomeUrl(t.url) ? hostOf(t.url) : '';
  const on = !host || !S.siteAllow.includes(host);
  const hosts = Object.entries(shieldStats.hosts || {}).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const max = hosts.length ? hosts[0][1] : 1;
  return head('Shield', '', host ? host : 'New tab') +
    '<div class="card"><div class="row2"><div class="grow"><div class="big">' + (t ? t.blocked : 0) + '</div><div class="sm mute">blocked on this page</div></div>' +
    '<div style="text-align:right"><div style="font-size:24px;font-weight:700">' + STATS.blocked + '</div><div class="xs mute">since ' + new Date(STATS.since).toLocaleDateString() + '</div></div></div>' +
    (host ? '<div class="srow" style="margin-top:8px"><div class="tx"><b>Shield on for ' + esc(host) + '</b><span>Turn off only if this site breaks. It also switches off the privacy script here.</span></div><button class="sw' + (on ? ' on' : '') + '" data-act="siteshield" data-h="' + esc(host) + '"></button></div>' : '') + '</div>' +
    '<div class="card"><h3>Blocking level</h3><div class="seg">' + [['off', 'Off'], ['standard', 'Standard'], ['strict', 'Strict'], ['ultra', 'Ultra']].map(o => '<button class="' + (S.shield === o[0] ? 'on' : '') + '" data-act="seg" data-k="shield" data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>' +
    '<div class="xs mute" style="margin-top:8px">Standard stops known ad and tracker domains. Strict adds tracking URL patterns on other sites. Ultra also blocks every third-party script and frame, which is the safest and the most likely to break pages.</div></div>' +
    '<div class="card"><h3>Blocked on this page</h3>' + (hosts.length ? hosts.map(h => '<div class="xs" style="margin-top:8px"><div class="row2"><span class="grow" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(h[0]) + '</span><b>' + h[1] + '</b></div><div class="bar2"><i style="width:' + Math.max(6, h[1] / max * 100) + '%"></i></div></div>').join('') : '<div class="sm mute">Nothing blocked here yet.</div>') + '</div>' +
    '<div class="card"><h3>Also on</h3><div class="wrap gap6">' + [['HTTPS-only', S.httpsOnly], ['Popups: ' + S.popups, S.popups !== 'allow'], ['Fingerprint shield', S.spoof], ['WebRTC off', S.noWebrtc], ['No 3rd-party cookies', S.cookies !== 'all'], ['Clean links', S.stripParams], ['Cookie banners hidden', S.consent]].map(c => '<span class="chip2" style="' + (c[1] ? '' : 'opacity:.4;text-decoration:line-through') + '">' + esc(c[0]) + '</span>').join('') + '</div></div>';
}

/* ---------- settings ---------- */
const FONTS_R = [['serif', 'Serif'], ['sans', 'Sans']];
const SCHEMA = [
  { id: 'look', icon: 'sliders', title: 'Look and feel', items: [
    { t: 'themes' },
    { k: 'accent', t: 'color', label: 'Custom accent colour', desc: 'Overrides the theme colour. Reset to use the theme again.' },
    { k: 'toolbarPos', t: 'seg', label: 'Toolbar position', opts: [['top', 'Top'], ['bottom', 'Bottom (thumb reach)']] },
    { k: 'uiStyle', t: 'seg', label: 'Interface style', opts: [['classic', 'Classic'], ['glass', 'Glass'], ['island', 'Island'], ['neon', 'Neon']] },
    { k: 'density', t: 'seg', label: 'Toolbar size', opts: [['normal', 'Roomy'], ['compact', 'Compact']] },
    { k: 'tabStrip', t: 'toggle', label: 'Show tab strip', desc: 'Small tabs under the address bar. On by default.' },
    { k: 'optRow', t: 'toggle', label: 'Show the options row', desc: 'The row with back, forward, home, new tab, layouts and tabs. You can also tap the small arrow left of the tabs to show or hide it.' },
    { k: 'swipeTabs', t: 'toggle', label: 'Swipe the address bar to switch tabs', desc: 'Swipe left or right on the address bar, like Chrome and Firefox.' },
    { k: 'edgeSwipe', t: 'toggle', label: 'Edge swipe: back and forward', desc: 'Swipe in from the left edge to go back, from the right edge to go forward.' },
    { k: 'edgeSize', t: 'range', label: 'Edge swipe zone width', min: 12, max: 48, step: 4, unit: ' dp' },
    { k: 'pullRefresh', t: 'toggle', label: 'Pull down to refresh', desc: 'Drag a page down from the very top to reload it.' },
    { k: 'alwaysFull', t: 'toggle', label: 'Always full screen', desc: 'Hides the phone\'s status bar and navigation buttons. Swipe from the edge to peek at them. Turn off to see them always.' },
    { k: 'autoHide', t: 'toggle', label: 'Auto-hide the toolbar while scrolling', desc: 'The address bar and tab row slide away as you scroll down and come back as you scroll up.' },
    { k: 'cutout', t: 'toggle', label: 'Fill the area around the camera notch in full screen' },
    { k: 'splash', t: 'toggle', label: 'Welcome animation' },
    { k: 'splashStyle', t: 'seg', label: 'Welcome style', opts: [['clean', 'Clean'], ['warp', 'Warp'], ['draw', 'Cinematic'], ['orbit', 'Network'], ['pulse', 'Radar']] },
    { k: 'splashSound', t: 'toggle', label: 'Welcome sound', desc: 'A short intro soundtrack, made inside the app. Uses your media volume.' },
    { k: 'splashVol', t: 'range', label: 'Welcome sound volume', min: 10, max: 100, step: 5, unit: '%' },
    { t: 'btn', label: 'Replay welcome', act: 'splashplay' },
  ] },
  { id: 'lay', icon: 'layout', title: 'Layouts, zoom and pages', items: [
    { t: 'btn', label: 'Choose a layout…', act: 'layout' },
    { k: 'ratio', t: 'range', label: 'Main pane size', min: 30, max: 70, step: 5, unit: '%' },
    { k: 'gap', t: 'range', label: 'Gap between panes', min: 0, max: 12, step: 1, unit: ' px' },
    { k: 'textZoom', t: 'range', label: 'Text size', min: 60, max: 220, step: 10, unit: '%' },
    { k: 'pageZoom', t: 'range', label: 'Default page zoom', min: 50, max: 250, step: 10, unit: '%', desc: 'Per-site zoom is in Menu → Zoom.' },
    { k: 'forceZoom', t: 'toggle', label: 'Allow pinch-zoom on every page', desc: 'Even on sites that try to lock zoom.' },
    { t: 'btn', label: 'PC mode: turn on or off', act: 'pctoggle', desc: 'Opens every site like on a computer: desktop layout, full screen (phone bars hidden, landscape), one slim address bar with Back, Forward and Home, and a tab strip. Turn it off and everything goes back as it was.' },
    { k: 'desktopDefault', t: 'toggle', label: 'Desktop sites by default' },
    { k: 'desktopWidth', t: 'range', label: 'Desktop page width', min: 900, max: 1920, step: 20, unit: ' px', desc: 'How wide the page thinks the screen is in desktop mode. Wider shows more, smaller.' },
    { k: 'darkPages', t: 'seg', label: 'Dark pages', opts: [['off', 'Off'], ['auto', 'With dark theme'], ['on', 'Always']] },
    { k: 'readerTheme', t: 'seg', label: 'Reader mode colours', opts: [['paper', 'Paper'], ['sepia', 'Sepia'], ['night', 'Night']] },
    { k: 'readerFont', t: 'seg', label: 'Reader mode font', opts: FONTS_R },
    { k: 'readerSize', t: 'range', label: 'Reader mode text', min: 14, max: 30, step: 1, unit: ' px' },
  ] },
  { id: 'shield', icon: 'shield', title: 'Shield: ads, trackers, popups', items: [
    { k: 'shield', t: 'seg', label: 'Blocking level', opts: [['off', 'Off'], ['standard', 'Standard'], ['strict', 'Strict'], ['ultra', 'Ultra']], desc: 'Ultra blocks all third-party scripts and frames. Safest, but some sites break. Turn the shield off per site from the shield button.' },
    { k: 'popups', t: 'seg', label: 'Popups and new windows', opts: [['block', 'Block all'], ['gesture', 'Only if I tap'], ['allow', 'Allow']] },
    { k: 'blockDialogs', t: 'toggle', label: 'Block alert / confirm boxes', desc: 'Stops fake "you won" and "virus found" boxes. (After 3 on one page they are blocked anyway.)' },
    { k: 'videoAds', t: 'toggle', label: 'Skip video ads (YouTube)', desc: 'Removes ad data from the player and skips any ad that still starts. Best effort: YouTube keeps changing its tricks.' },
    { k: 'ytCinema', t: 'toggle', label: 'YouTube Cinema (new YouTube look)', desc: 'Shows YouTube as a Netflix-style app: featured carousel, rows, a numbered Top 10, a Shorts row, bottom tabs (Home, Shorts, Subs, Search) and a style sheet (rows or grid, accent colour, hide Shorts). The Classic button gives normal YouTube back at any time.' },
    { k: 'cosmetic', t: 'toggle', label: 'Hide empty ad slots and frames' },
    { k: 'hideSelectors', t: 'list', label: 'My own hide rules', desc: 'One per line. Use host##selector for one site (like example.com##.popup) or just a selector for every site. Menu → Hide element adds these for you.' },
    { k: 'consent', t: 'toggle', label: 'Hide cookie and consent banners' },
    { k: 'stripParams', t: 'toggle', label: 'Clean tracking out of links', desc: 'Removes utm_*, fbclid, gclid and similar from addresses.' },
    { k: 'blockExternal', t: 'toggle', label: 'Block links that open other apps', desc: 'mailto and tel links still ask you first.' },
    { k: 'blockAutoplay', t: 'toggle', label: 'Block autoplay of video and sound' },
    { k: 'customBlock', t: 'list', label: 'My own blocked domains', desc: 'One per line, like ads.example.com. Subdomains are blocked too.' },
    { k: 'appCompat', t: 'toggle', label: 'Web-app mode (Spotify, Netflix, WhatsApp Web…)', desc: 'On music, video and chat sites the ad and tracker blocking stays on, but the things that break playback and login are relaxed: fingerprint shield, WebRTC block, 3rd-party cookie block, autoplay block and Ultra-level script blocking. Spotify always stays on the phone layout (its player only plays there); WhatsApp Web opens in desktop layout.' },
    { k: 'compatSites', t: 'list', label: 'My own web-app sites', desc: 'One per line, like example.com. Same relaxed mode as above, ads still blocked. Use this when a site breaks but you still want ad blocking (the shield-off list turns everything off).' },
    { k: 'siteAllow', t: 'list', label: 'Sites where the shield is off', desc: 'One per line. Normally managed from the shield button.' },
  ] },
  { id: 'priv', icon: 'lock', title: 'Privacy and security', items: [
    { k: 'chromeLook', t: 'toggle', label: 'Look like Chrome to websites', desc: 'Hides the "app browser" marks and your phone model. Needed for Google, Microsoft and Apple sign-in, and it makes you less unique.' },
    { k: 'signinCompat', t: 'toggle', label: 'Sign-in compatibility', desc: 'Leaves Google, Microsoft, Apple and Yahoo sign-in pages untouched (no blocking, no spoofing) so adding your accounts works.' },
    { k: 'httpsOnly', t: 'toggle', label: 'HTTPS only', desc: 'Upgrades every link to a secure connection. If a site has none, you are asked before using plain HTTP.' },
    { k: 'cookies', t: 'seg', label: 'Cookies', opts: [['all', 'Allow all'], ['first', 'No third-party'], ['none', 'None']] },
    { k: 'spoof', t: 'toggle', label: 'Fingerprint shield', desc: 'Makes the phone look less unique (hardware, language, canvas).' },
    { k: 'noWebrtc', t: 'toggle', label: 'Block WebRTC', desc: 'Stops sites finding your real network address. Video calls in the browser will not work while on.' },
    { k: 'noBeacon', t: 'toggle', label: 'Block tracking beacons' },
    { k: 'gpc', t: 'toggle', label: 'Send Do-Not-Track and Global Privacy Control' },
    { k: 'referrer', t: 'seg', label: 'Tell sites where I came from', opts: [['default', 'Normal'], ['origin', 'Site only'], ['none', 'Never']] },
    { k: 'safeBrowsing', t: 'toggle', label: 'Google Safe Browsing', desc: 'Warns about dangerous sites, but sends small hashes of addresses to Google. Off by default to keep the app silent.' },
    { k: 'js', t: 'toggle', label: 'JavaScript on for new tabs', desc: 'Switch it off per tab from the menu for the safest reading.' },
    { k: 'images', t: 'toggle', label: 'Load images in new tabs' },
    { k: 'ua', t: 'seg', label: 'Browser identity', opts: [['default', 'Standard'], ['custom', 'Custom']] },
    { k: 'customUA', t: 'text', label: 'Custom identity string', ph: 'Mozilla/5.0 …' },
    { t: 'info', text: 'Camera, microphone and location are always refused for every site. The app only holds the internet permission. The only thing allowed is protected-media (DRM) playback, so Spotify and Netflix can play; it shares no personal data.' },
  ] },
  { id: 'data', icon: 'flame', title: 'Data and history', items: [
    { k: 'wipeExit', t: 'toggle', label: 'Clean up when I close the app', desc: 'Clears leftovers each time the app closes. Bookmarks and settings are always kept.' },
    { k: 'keepLogins', t: 'toggle', label: 'Stay signed in to my accounts', desc: 'Keeps cookies and site data across restarts so your logins last. Turn off to wipe them on close. The Burn button always wipes everything.' },
    { k: 'noCache', t: 'toggle', label: 'Never store page cache', desc: 'A little slower, leaves less behind.' },
    { k: 'saveHistory', t: 'toggle', label: 'Save history on this phone', desc: 'Off by default.' },
    { k: 'restoreTabs', t: 'toggle', label: 'Reopen my tabs next time', desc: 'Off by default.' },
    { k: 'sleepTabs', t: 'toggle', label: 'Pause tabs that are not on screen', desc: 'Keeps the app light and fast. Background tabs stop working until you bring them back. On by default.' },
    { t: 'btn', label: 'Clear cookies', act: 'clearcookies' },
    { t: 'btn', label: 'Clear cache', act: 'clearcache' },
    { t: 'btn', label: 'Clear history', act: 'clearhist' },
    { t: 'btn', label: 'Burn everything now', act: 'burn', cls: 'warn' },
  ] },
  { id: 'search', icon: 'search', title: 'Search and home', items: [
    { k: 'engine', t: 'select', label: 'Search engine', opts: Object.keys(ENGINES).map(k => [k, ENGINES[k][0]]) },
    { k: 'customEngine', t: 'text', label: 'My own search address', ph: 'https://example.com/?q=%s', desc: 'Use %s where the search words go. Used when the engine above is "My own".' },
    { k: 'home', t: 'text', label: 'Home page', ph: 'Blank = the NerdyBrowser start page', desc: 'Opens with the home button.' },
    { k: 'ntDial', t: 'toggle', label: 'Show shortcuts on the start page' },
    { k: 'ntStats', t: 'toggle', label: 'Show the "blocked so far" counter' },
    { k: 'ntTips', t: 'toggle', label: 'Show a privacy tip' },
    { k: 'ntStyle', t: 'seg', label: 'Start page style', opts: [['glow', 'Glow'], ['plain', 'Plain'], ['grid', 'Dotted']] },
    { k: 'ntName', t: 'text', label: 'Name on the start page greeting', ph: 'Optional' },
  ] },
  { id: 'vpn', icon: 'lock', title: 'VPN and proxy', items: [
    { t: 'btn', label: 'Open VPN settings', act: 'vpn' },
    { k: 'vpnKill', t: 'toggle', label: 'Block browsing if the VPN drops' },
    { k: 'vpnAuto', t: 'toggle', label: 'Connect the VPN when the app starts' },
  ] },
  { id: 'dev', icon: 'eyeoff', title: 'Device', items: [
    { k: 'secure', t: 'toggle', label: 'Hide from screenshots and app switcher', desc: 'Blocks screenshots too, so leave it off when you want to take one.' },
    { k: 'appLock', t: 'toggle', label: 'Ask for my phone unlock to open', desc: 'Uses your fingerprint, face, PIN or pattern. Needs a screen lock set on the phone.' },
    { k: 'keepScreen', t: 'toggle', label: 'Keep screen on while browsing' },
    { k: 'askDownload', t: 'toggle', label: 'Ask before downloading' },
    { k: 'dlSort', t: 'toggle', label: 'Sort downloads into folders by type', desc: 'Videos, Audio, Images, Documents, Archives, Apps inside Downloads/NerdyBrowser.' },
    { k: 'dlWifiOnly', t: 'toggle', label: 'Download only on Wi-Fi' },
    { k: 'dlMedia', t: 'toggle', label: 'Media downloader', desc: 'Finds pictures, videos and embedded players on a page and lets you pick quality and size. Turn off to stop it reading page data.' },
    { k: 'dlButtons', t: 'toggle', label: 'Show floating Save button', desc: 'One small round button appears when a page has a big picture or a video. Tap it to see the list; drag it if it covers something. Long-press a picture also works, and Menu > Media on page always works.' },
    { t: 'btn', label: 'Open Downloads', act: 'downloads' },
    { t: 'btn', label: 'Open the phone\'s Files app for downloads', act: 'sysdownloads' },
  ] },
  { id: 'bk', icon: 'copy', title: 'Backup and reset', items: [
    { t: 'btn', label: 'Export bookmarks and settings', act: 'export' },
    { t: 'btn', label: 'Import from pasted text', act: 'import' },
    { t: 'btn', label: 'Reset all settings', act: 'resetset', cls: 'warn' },
  ] },
];
const openSecs = new Set(['look']);

function settingRow(it) {
  const v = S[it.k];
  const tx = '<div class="tx"><b>' + esc(it.label || '') + '</b>' + (it.desc ? '<span>' + esc(it.desc) + '</span>' : '') + '</div>';
  switch (it.t) {
    case 'toggle': return '<div class="srow">' + tx + '<button class="sw' + (v ? ' on' : '') + '" data-act="tog" data-k="' + it.k + '" aria-label="' + esc(it.label) + '"></button></div>';
    case 'seg': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<div class="seg">' + it.opts.map(o => '<button class="' + (v === o[0] ? 'on' : '') + '" data-act="seg" data-k="' + it.k + '" data-v="' + o[0] + '">' + esc(o[1]) + '</button>').join('') + '</div></div>';
    case 'range': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<input type="range" min="' + it.min + '" max="' + it.max + '" step="' + it.step + '" value="' + v + '" data-k="' + it.k + '" data-rng data-unit="' + esc(it.unit || '') + '"><div class="xs mute rv">' + v + (it.unit || '') + '</div></div>';
    case 'text': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<input class="tin" type="text" value="' + esc(v) + '" placeholder="' + esc(it.ph || '') + '" data-k="' + it.k + '" data-txt autocomplete="off" spellcheck="false"></div>';
    case 'list': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<textarea class="tarea" data-k="' + it.k + '" data-list spellcheck="false" autocomplete="off">' + esc((v || []).join('\n')) + '</textarea></div>';
    case 'select': return '<div class="set" style="padding:10px 0;border-bottom:1px solid var(--line)">' + tx + '<select class="sel" style="margin-top:8px" data-k="' + it.k + '" data-sel>' + it.opts.map(o => '<option value="' + o[0] + '"' + (v === o[0] ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select></div>';
    case 'color': return '<div class="srow">' + tx + '<div class="row2"><input type="color" value="' + (/^#[0-9a-f]{6}$/i.test(v || '') ? v : '#f0642f') + '" data-k="' + it.k + '" data-col style="width:44px;height:34px;border:0;background:none;padding:0"><button class="btn" data-act="accentreset">Reset</button></div></div>';
    case 'btn': return '<div style="padding:6px 0"><button class="btn ' + (it.cls || '') + '" data-act="' + it.act + '" style="width:100%;justify-content:center">' + esc(it.label) + '</button></div>';
    case 'info': return '<div class="xs mute" style="padding:10px 0;line-height:1.5">' + esc(it.text) + '</div>';
    case 'themes': return '<div class="lbl" style="margin-top:4px">Colour theme</div><div class="tsw-grid">' + Object.keys(THEMES).map(k => { const t = THEMES[k]; return '<button class="tsw' + (S.theme === k ? ' on' : '') + '" data-act="theme" data-v="' + k + '" style="--a:' + t.a + ';--b:' + t.b + ';--c:' + t.c + ';--tx:' + t.t + '"><i></i><b>' + t.n + '</b></button>'; }).join('') + '</div>';
  }
  return '';
}
function settingsHTML() {
  return head('Settings', '', 'Everything is saved on this phone only') + SCHEMA.map(sec =>
    '<details class="sec" data-sec="' + sec.id + '"' + (openSecs.has(sec.id) ? ' open' : '') + '><summary><span class="ico">' + ic(sec.icon, 16) + '</span>' + esc(sec.title) + '<span class="chev">' + ic('down', 18) + '</span></summary><div class="in">' + sec.items.map(settingRow).join('') + '</div></details>').join('') +
    '<div class="card sm mute" style="text-align:center">NerdyBrowser 1.0.4 (build 5) · no account, no analytics, no tracking</div>';
}


/* ---------- downloads (smart: sorted by type, live speed, ETA) ---------- */
let DL = [], dlFilter = 'All', dlQ = '';
const dlSize = b => (b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : b < 1073741824 ? (b / 1048576).toFixed(1) + ' MB' : (b / 1073741824).toFixed(2) + ' GB');
const dlEta = sec => (!isFinite(sec) || sec <= 0) ? '' : sec < 60 ? Math.round(sec) + ' s' : sec < 3600 ? Math.round(sec / 60) + ' min' : (sec / 3600).toFixed(1) + ' h';
function catOf(d) {
  const n = (d.title || '').toLowerCase(), m = (d.mime || '').toLowerCase();
  if (m.startsWith('video/') || /\.(mp4|mkv|webm|avi|mov|3gp|m4v|flv)$/.test(n)) return 'Videos';
  if (m.startsWith('audio/') || /\.(mp3|m4a|aac|wav|flac|ogg|opus|wma)$/.test(n)) return 'Audio';
  if (m.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|bmp|svg|heic|avif)$/.test(n)) return 'Images';
  if (/\.apk$/.test(n)) return 'Apps';
  if (/\.(zip|rar|7z|tar|gz|bz2|xz)$/.test(n) || m.includes('zip')) return 'Archives';
  if (/\.(pdf|doc|docx|xls|xlsx|csv|ppt|pptx|txt|epub|md|json|rtf)$/.test(n) || m.startsWith('text/') || m.includes('pdf')) return 'Documents';
  return 'Other';
}
const DL_CATS = ['Videos', 'Audio', 'Images', 'Documents', 'Archives', 'Apps', 'Other'];
function sparkSvg(arr) {
  if (arr.length < 2) return '';
  const max = Math.max.apply(null, arr.concat([1])), w = 300, h = 34;
  const pts = arr.map((v, i) => (i / (arr.length - 1) * w).toFixed(1) + ',' + (h - 2 - v / max * (h - 6)).toFixed(1)).join(' ');
  return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none"><polyline points="' + pts + '" fill="none" stroke="var(--acc2)" stroke-width="2" stroke-linejoin="round"/></svg>';
}
function dlRow(d) {
  const run = d.status === 2 || d.status === 1 || d.status === 4, ok = d.status === 8, bad = d.status === 16;
  const pct = d.total > 0 ? Math.min(100, Math.round(d.got / d.total * 100)) : 0;
  const ext = ((d.title || '').split('.').pop() || '?').slice(0, 4);
  let sub;
  if (ok) sub = dlSize(d.total || d.got) + ' · done';
  else if (bad) sub = 'Failed';
  else if (d.status === 4) sub = 'Paused (waiting for network)';
  else if (d.status === 1) sub = 'Waiting…';
  else {
    const eta = d.speed > 0 && d.total > 0 ? dlEta((d.total - d.got) / d.speed) : '';
    sub = (d.total > 0 ? dlSize(d.got) + ' of ' + dlSize(d.total) + ' · ' + pct + '%' : dlSize(d.got)) + (d.speed > 0 ? ' · ' + dlSize(d.speed) + '/s' : '') + (eta ? ' · ' + eta + ' left' : '');
  }
  return '<div class="li2"><button class="lt" data-act="dlopen" data-id="' + d.id + '" style="border:0;font-size:11px">' + esc(ext) + '</button>' +
    '<button class="tx" data-act="dlopen" data-id="' + d.id + '" style="border:0;background:none;padding:0"><b>' + esc(d.title || 'download') + '</b><span>' + esc(sub) + '</span>' +
    (run ? '<div class="bar2"><i style="width:' + (d.total > 0 ? pct : 30) + '%"></i></div>' : '') + '</button>' +
    (bad ? '<button class="ib sm" data-act="dlretry" data-id="' + d.id + '" aria-label="Retry">' + ic('reload', 17) + '</button>' : '') +
    '<button class="ib sm" data-act="dlrm" data-id="' + d.id + '" aria-label="Remove">' + ic(run ? 'x' : 'trash', 17) + '</button></div>';
}
function downloadsHTML() {
  DL.forEach(d => { d.cat = catOf(d); });
  const q = dlQ.toLowerCase();
  const list = DL.filter(d => (dlFilter === 'All' || d.cat === dlFilter) && (!q || (d.title || '').toLowerCase().includes(q)));
  const active = DL.filter(d => d.status === 2);
  const counts = {}; DL.forEach(d => { counts[d.cat] = (counts[d.cat] || 0) + 1; });
  const chips = ['All'].concat(DL_CATS.filter(c => counts[c])).map(c => '<button class="fchip' + (dlFilter === c ? ' on' : '') + '" data-act="dlfilter" data-v="' + c + '">' + c + (c === 'All' ? ' ' + DL.length : ' ' + counts[c]) + '</button>').join('');
  let body = '';
  const sorted = list.slice().sort((a, b) => ((b.status === 2) - (a.status === 2)) || (b.ts - a.ts));
  if (dlFilter === 'All') {
    const running = sorted.filter(d => d.status === 2 || d.status === 1 || d.status === 4);
    if (running.length) body += '<div class="gh">In progress</div>' + running.map(dlRow).join('');
    DL_CATS.forEach(c => { const g = sorted.filter(d => d.cat === c && !(d.status === 2 || d.status === 1 || d.status === 4)); if (g.length) body += '<div class="gh">' + c + ' · ' + g.length + '</div>' + g.map(dlRow).join(''); });
  } else body = sorted.map(dlRow).join('');
  const done = DL.filter(d => d.status === 8).length;
  return head('Downloads', '<button class="btn" data-act="dlclear"' + (done ? '' : ' disabled') + '>Clear done</button>', DL.length + ' files · sorted by type into Downloads/NerdyBrowser') +
    (active.length ? '<div class="card"><div class="row2"><div class="grow"><div style="font-size:26px;font-weight:700;color:var(--acc2)">' + dlSize(DLTOT) + '/s</div><div class="xs mute">' + active.length + ' downloading</div></div></div>' + sparkSvg(DLSPD) + '</div>' : '') +
    '<input class="search" id="dlq" type="text" placeholder="Search downloads" value="' + esc(dlQ) + '">' +
    '<div class="fchips">' + chips + '</div>' +
    (body || '<div class="empty">No downloads yet.<br>Files you download show up here, sorted by type, with live speed. Tap one to open it.</div>');
}

/* ---------- VPN ---------- */
let VPN = { has: false, up: false, msg: '', endpoint: '', address: '' };
const WG_SCRIPT = "#!/bin/bash\n# NerdyBrowser: makes a WireGuard server on a fresh Ubuntu/Debian VPS and prints your phone's config.\n# Run as root. Also open UDP port 51820 in your hosting company's firewall.\nset -e\n[ \"$(id -u)\" = 0 ] || { echo \"Run this as root (sudo -i)\"; exit 1; }\nPORT=51820\napt-get update -y >/dev/null && apt-get install -y wireguard curl >/dev/null\numask 077; mkdir -p /etc/wireguard; cd /etc/wireguard\nIFACE=$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i==\"dev\"){print $(i+1); exit}}')\nIP=$(curl -4 -s https://ifconfig.me || curl -4 -s https://api.ipify.org)\nwg genkey | tee server.key | wg pubkey > server.pub\nwg genkey | tee phone.key | wg pubkey > phone.pub\nwg genpsk > phone.psk\ncat > wg0.conf <<CONF\n[Interface]\nAddress = 10.66.66.1/24\nListenPort = $PORT\nPrivateKey = $(cat server.key)\nPostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE\nPostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o $IFACE -j MASQUERADE\n\n[Peer]\nPublicKey = $(cat phone.pub)\nPresharedKey = $(cat phone.psk)\nAllowedIPs = 10.66.66.2/32\nCONF\necho 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-wg.conf\nsysctl -p /etc/sysctl.d/99-wg.conf >/dev/null\ncommand -v ufw >/dev/null && ufw allow $PORT/udp >/dev/null 2>&1 || true\nsystemctl enable --now wg-quick@wg0 >/dev/null\necho\necho \"=== COPY EVERYTHING BETWEEN THE LINES INTO NerdyBrowser > VPN > Advanced ===\"\ncat <<CLIENT\n[Interface]\nPrivateKey = $(cat phone.key)\nAddress = 10.66.66.2/32\nDNS = 1.1.1.1, 1.0.0.1\nMTU = 1380\n\n[Peer]\nPublicKey = $(cat server.pub)\nPresharedKey = $(cat phone.psk)\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = $IP:$PORT\nPersistentKeepalive = 25\nCLIENT\necho \"=== END ===\"\n";
let VPNDRAFT = '', VPNPEER = '';
function vpnHTML() {
  const on = VPN.up, busy = /Connecting|Setting up|Disconnecting/.test(VPN.msg || '');
  return head('VPN', '', 'Hide your IP in one tap') +
    '<div class="card" style="text-align:center"><div style="font-size:15px;color:var(--mute)">' + (on ? 'Your real IP is hidden from websites' : 'Your real IP is visible right now') + '</div>' +
    '<button class="vbig' + (on ? ' on' : '') + '" data-act="' + (on ? 'vpndisconnect' : 'vpnauto') + '"' + (busy ? ' disabled' : '') + '>' + ic('shield', 36) + '<b>' + (busy ? 'Please wait' : on ? 'Protected' : 'Turn on') + '</b></button>' +
    '<div class="xs mute" style="min-height:18px">' + esc(VPN.msg || (VPN.has ? 'Ready to connect' : 'First time it sets itself up. Free, no account, nothing to type.')) + '</div></div>' +
    '<div class="card"><div class="srow"><div class="tx"><b>Connect automatically when the app starts</b><span>You will see Android\'s one-time permission box the first time.</span></div><button class="sw' + (S.vpnAuto ? ' on' : '') + '" data-act="tog" data-k="vpnAuto"></button></div>' +
    '<div class="srow"><div class="tx"><b>Kill switch</b><span>Nothing loads unless the VPN is connected.</span></div><button class="sw' + (S.vpnKill ? ' on' : '') + '" data-act="tog" data-k="vpnKill"></button></div></div>' +
    '<div class="card"><h3>Check that it works</h3><div class="xs mute">Opens a Cloudflare page. When the tunnel is on, it shows warp=on and an address that is not yours.</div><div style="margin-top:10px"><button class="btn" data-act="ipcheck">' + ic('globe', 15) + ' Check my IP</button></div></div>' +
    '<div class="card sm mute"><b style="color:var(--ink)">How it works</b><br>The free Cloudflare WARP service (the same one behind the 1.1.1.1 app) gives this phone a private tunnel. Only NerdyBrowser\'s traffic uses it; the rest of the phone is untouched. Websites then see Cloudflare\'s address instead of yours, and your internet provider can no longer see which sites you visit. You are trusting Cloudflare in place of your provider. This is not Tor.</div>' +
    '<details class="sec"><summary><b>Advanced: use my own VPN or proxy</b><span class="chev">' + ic('down', 18) + '</span></summary><div class="in">' +
    '<div class="xs mute">Paste a WireGuard config (starts with [Interface]) from Proton VPN, Mullvad, IVPN or your own server. It replaces the free tunnel and is kept only in this app\'s private storage.</div>' +
    '<textarea class="tarea" id="vpncfg" spellcheck="false" autocomplete="off" placeholder="[Interface]&#10;PrivateKey = ...&#10;Address = ...&#10;&#10;[Peer]&#10;PublicKey = ...&#10;Endpoint = ...">' + esc(VPNDRAFT) + '</textarea>' +
    '<div class="row2 wrap gap" style="margin-top:8px"><button class="btn" data-act="vpncopy">Copy</button><button class="btn" data-act="vpnshare">Share</button>' + (VPN.has ? '<button class="btn" data-act="vpnshow">Show my saved config</button>' : '') + '</div>' +
    '<div class="card" style="margin-top:12px"><h3>Create a config for me</h3>' +
    '<div class="xs mute">No config yet? Make one here. The keys are created on this phone. Nothing is saved until you tap Save and use.</div>' +
    '<div style="margin-top:10px"><button class="btn pri" data-act="vpnwarp">Create free config (Cloudflare WARP)</button></div>' +
    '<div class="lbl">Or for my own server</div>' +
    '<input class="tin" id="vpnep" type="text" placeholder="Server address, like 203.0.113.5:51820" autocomplete="off" spellcheck="false">' +
    '<input class="tin" id="vpnsk" type="text" placeholder="Server public key (empty if you do not have it yet)" autocomplete="off" spellcheck="false" style="margin-top:8px">' +
    '<div style="margin-top:10px"><button class="btn" data-act="vpnown">Create config for my server</button></div>' +
    (VPNPEER ? '<div class="xs mute" style="margin-top:10px">Add this block to your server\'s wg0.conf (then restart WireGuard), and put the server\'s public key into the config above.</div><pre class="xs" style="white-space:pre-wrap;word-break:break-all;user-select:text">' + esc(VPNPEER) + '</pre><button class="btn" data-act="vpnpeer">Copy server block</button>' : '') +
    '<div class="lbl">No server at all?</div><div class="xs mute">WireGuard needs a server somewhere. A small cloud server (Ubuntu) is enough. Open its console, paste this script, and it prints a finished config to paste above. Also open UDP port 51820 in the host\'s firewall.</div>' +
    '<div style="margin-top:8px"><button class="btn" data-act="vpnscript">Copy server setup script</button></div></div>' +
    '<div class="row2 wrap gap" style="margin-top:10px"><button class="btn pri" data-act="vpnsave">Save and use</button>' + (VPN.has ? '<button class="btn warn" data-act="vpnclear">Remove tunnel</button>' : '') + '</div>' +
    '<div class="lbl">Proxy instead (for Tor, install Orbot)</div><input class="tin" type="text" value="' + esc(S.proxy || '') + '" placeholder="socks5://127.0.0.1:9050" data-k="proxy" data-txt autocomplete="off" spellcheck="false"></div></details>';
}

/* ---------- which panel is which ---------- */
const PANELS = {
  menu: { sheet: true, html: menuHTML },
  zoom: { sheet: true, html: zoomHTML },
  tabs: { html: tabsHTML },
  layout: { html: layoutHTML },
  bookmarks: { html: bookmarksHTML },
  history: { html: historyHTML },
  shield: { html: shieldHTML },
  settings: { html: settingsHTML },
  about: { html: aboutHTML, mount: aboutMount },
  downloads: { html: downloadsHTML },
  vpn: { html: vpnHTML },
  keys: { html: keysHTML },
  closed: { html: closedHTML },
  cmd: { html: cmdHTML, mount: () => setTimeout(() => { const i = $('#cmq'); if (i) i.focus(); }, 60) },
};
