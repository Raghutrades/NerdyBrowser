'use strict';
/* ===== NerdyBrowser · welcome: particle animation + a sound track made live (no audio files) ===== */
const Splash = (function () {
  const DUR = 4700;
  let raf = 0, actx = null, master = null, running = false, cb = null, t0 = 0, targets = null, parts = [], style = 'draw', cx = 0, cy = 0, W = 0, H = 0, lockDone = false, boomDone = false, timers = [];
  const cv = () => $('#spc');
  const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim() || '#f0642f';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---- target points: sample the logo outline ---- */
  function sampleTargets() {
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 120 120');
    svg.style.cssText = 'position:absolute;left:-999px;top:0;width:120px;height:120px;visibility:hidden';
    const defs = ['M60 10 L100 24 V58 C100 84 82 102 60 110 C38 102 20 84 20 58 V24 Z', 'M38 58h44', 'M60 36v44', 'M60 36c-12 10-12 34 0 44', 'M60 36c12 10 12 34 0 44'];
    const els = defs.map(d => { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); svg.appendChild(p); return p; });
    const c = document.createElementNS(NS, 'circle'); c.setAttribute('cx', 60); c.setAttribute('cy', 58); c.setAttribute('r', 22); svg.appendChild(c); els.push(c);
    document.body.appendChild(svg);
    const pts = [];
    els.forEach((e, k) => {
      const L = e.getTotalLength(), step = k === 0 ? 3.1 : 3.4;
      for (let d = 0; d < L; d += step) { const q = e.getPointAtLength(d); pts.push([q.x, q.y]); }
    });
    svg.remove();
    return pts;
  }

  function setup() {
    const c = cv(), dpr = Math.min(2, window.devicePixelRatio || 1);
    W = window.innerWidth; H = window.innerHeight;
    c.width = W * dpr; c.height = H * dpr;
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const r = $('#splogo').getBoundingClientRect(), f = r.width / 120;
    cx = r.left + r.width / 2; cy = r.top + r.height / 2;
    if (!targets) targets = sampleTargets();
    const cols = [css('--acc2'), css('--acc'), css('--acc2')];
    const R = Math.max(W, H);
    parts = targets.map((t, i) => {
      const a = Math.random() * Math.PI * 2, rr = R * (0.55 + Math.random() * 0.6);
      return { tx: r.left + t[0] * f, ty: r.top + t[1] * f, sx: cx + Math.cos(a) * rr, sy: cy + Math.sin(a) * rr, d: Math.random() * (style === 'orbit' ? 0.7 : 0.45), sw: (Math.random() - 0.5) * 2, c: cols[i % 3], r: 1.2 + Math.random() * 1.9, ang: Math.atan2(t[1] - 58, t[0] - 60) };
    });
    return g;
  }

  function pos(p, t, dur) {
    const u = clamp((t - p.d - 0.12) / dur, 0, 1), e = 1 - Math.pow(1 - u, 3);
    const vx = p.tx - p.sx, vy = p.ty - p.sy, L = Math.hypot(vx, vy) || 1;
    const off = Math.sin(u * Math.PI) * p.sw * 46;
    return [p.sx + vx * e - vy / L * off, p.sy + vy * e + vx / L * off, u];
  }

  function frame(now) {
    if (!running) return;
    const t = Math.max(0, (now - t0) / 1000), g = cv().getContext('2d');
    g.clearRect(0, 0, W, H);
    const accent = css('--acc2');
    if (!lockDone && t >= 1.65) { lockDone = true; $('#splash').classList.add('lock'); }
    if (!boomDone && t >= 1.65) { boomDone = true; $('#splash').classList.add('boom'); }
    $('#spb').style.width = clamp((now - t0) / DUR * 100, 0, 100) + '%';

    if (style === 'draw') {
      for (let k = 0; k < 3; k++) { /* faint radar rings at the start */
        const rt = (t - k * 0.35) * 0.9; if (rt > 0 && rt < 1) { g.globalAlpha = (1 - rt) * 0.25; g.strokeStyle = accent; g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, rt * Math.max(W, H) * 0.5, 0, 7); g.stroke(); }
      }
      parts.forEach(p => {
        const q = pos(p, t, 1.15);
        g.globalAlpha = (0.3 + 0.7 * q[2]) * clamp(1 - (t - 1.85) / 0.7, 0, 1);
        g.fillStyle = p.c; g.beginPath(); g.arc(q[0], q[1], p.r + (1 - q[2]) * 1.2, 0, 7); g.fill();
      });
      if (t > 1.65 && t < 2.8) {
        const k = (t - 1.65) / 1.15;
        g.globalAlpha = (1 - k) * 0.9; g.strokeStyle = accent; g.lineWidth = 4 * (1 - k) + 0.5;
        g.beginPath(); g.arc(cx, cy, k * Math.max(W, H) * 0.85, 0, 7); g.stroke();
        g.globalAlpha = (1 - k) * 0.35; g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, k * Math.max(W, H) * 0.6, 0, 7); g.stroke();
      }
    } else if (style === 'orbit') {
      const fade = clamp(1 - (t - 4.0) / 0.55, 0, 1), P = parts.map(p => pos(p, t, 1.5));
      g.lineWidth = 1; g.strokeStyle = accent;
      for (let i = 0; i < parts.length; i += 1) {
        for (let j = i + 1; j < Math.min(parts.length, i + 7); j++) {
          const dx = P[i][0] - P[j][0], dy = P[i][1] - P[j][1], d2 = dx * dx + dy * dy;
          if (d2 < 2400 * (1 + clamp(t - 1, 0, 1))) { g.globalAlpha = (1 - d2 / 3600) * 0.5 * Math.min(P[i][2], P[j][2]) * fade; g.beginPath(); g.moveTo(P[i][0], P[i][1]); g.lineTo(P[j][0], P[j][1]); g.stroke(); }
        }
      }
      parts.forEach((p, i) => { g.globalAlpha = (0.35 + 0.65 * P[i][2]) * fade; g.fillStyle = p.c; g.beginPath(); g.arc(P[i][0], P[i][1], p.r, 0, 7); g.fill(); });
      if (t > 1.5) for (let k = 0; k < 3; k++) {
        const a = t * (1.6 + k * 0.45) + k * 2.1, rr = 92 + k * 26;
        g.globalAlpha = clamp((t - 1.5) / 0.5, 0, 1) * fade; g.fillStyle = k === 1 ? css('--acc') : accent;
        g.beginPath(); g.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.62, 4.5 - k, 0, 7); g.fill();
        g.globalAlpha *= 0.25; g.strokeStyle = accent; g.beginPath(); g.ellipse(cx, cy, rr, rr * 0.62, 0, 0, 7); g.stroke();
      }
    } else { /* pulse: radar sweep that "finds" the blips */
      const sw = t * 4.0 % (Math.PI * 2), R = Math.max(W, H) * 0.7, fade = clamp(1 - (t - 3.9) / 0.6, 0, 1);
      for (let k = 0; k < 6; k++) { const rt = ((t * 0.7 + k / 6) % 1); g.globalAlpha = (1 - rt) * 0.28 * fade; g.strokeStyle = accent; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, rt * R * 0.55, 0, 7); g.stroke(); }
      if (t < 2.7) {
        g.globalAlpha = 0.16 * fade; g.fillStyle = accent; g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R * 0.55, sw - 0.55, sw); g.closePath(); g.fill();
        g.globalAlpha = 0.7; g.strokeStyle = accent; g.lineWidth = 2; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(sw) * R * 0.55, cy + Math.sin(sw) * R * 0.55); g.stroke();
      }
      parts.forEach(p => {
        const a = (p.ang + Math.PI * 2 + 1.5707) % (Math.PI * 2);
        let dlt = (sw - a + Math.PI * 4) % (Math.PI * 2);
        let al = t < 2.7 ? Math.exp(-dlt / 1.25) : 1;
        if (t < 0.15) al = 0;
        g.globalAlpha = al * fade * (t > 2.4 ? clamp(1 - (t - 2.4) / 1.0, 0.0, 1) : 1) + (t > 2.7 ? 0 : 0);
        g.fillStyle = p.c; g.beginPath(); g.arc(p.tx, p.ty, p.r + 0.8, 0, 7); g.fill();
      });
    }
    g.globalAlpha = 1;
    if (now - t0 >= DUR) { finish(); return; }
    raf = requestAnimationFrame(frame);
  }

  /* ---- the sound: whoosh, sub drone, rising arpeggio, impact, chord, sparkles, final chime ---- */
  function impulse(ac, sec, decay) {
    const len = ac.sampleRate * sec, b = ac.createBuffer(2, len, ac.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay); }
    return b;
  }
  function startAudio(vol, st) {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      actx = new AC();
      if (actx.state === 'suspended') { const rp = actx.resume(); if (rp && rp.catch) rp.catch(function () { }); }
      const ac = actx, now = ac.currentTime + 0.05;
      master = ac.createGain(); master.gain.setValueAtTime(0, now); master.gain.linearRampToValueAtTime(vol, now + 0.1); master.connect(ac.destination);
      const comp = ac.createDynamicsCompressor(); comp.connect(master);
      const rev = ac.createConvolver(); rev.buffer = impulse(ac, 2.4, 2.4);
      const revG = ac.createGain(); revG.gain.value = 0.38; rev.connect(revG); revG.connect(comp);
      const out = ac.createGain(); out.connect(comp); out.connect(rev);
      const root = { draw: 130.81, orbit: 146.83, pulse: 123.47 }[st] || 130.81;
      const scale = { draw: [0, 2, 4, 7, 9], orbit: [0, 2, 3, 7, 8], pulse: [0, 3, 5, 7, 10] }[st] || [0, 2, 4, 7, 9];
      const note = (deg, oct) => root * Math.pow(2, (scale[deg % scale.length] + 12 * (oct + Math.floor(deg / scale.length))) / 12);
      const osc = (type, f, t, dur, g0, dest, det) => {
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = type; o.frequency.setValueAtTime(f, now + t); if (det) o.detune.value = det;
        g.gain.setValueAtTime(0.0001, now + t); g.gain.exponentialRampToValueAtTime(g0, now + t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, now + t + dur);
        o.connect(g); g.connect(dest || out); o.start(now + t); o.stop(now + t + dur + 0.05);
        return o;
      };
      const noiseBuf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate); { const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
      const noise = (t, dur, f0, f1, g0, type) => {
        const s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        s.buffer = noiseBuf; f.type = type || 'bandpass'; f.Q.value = 1.2;
        f.frequency.setValueAtTime(f0, now + t); f.frequency.exponentialRampToValueAtTime(f1, now + t + dur);
        g.gain.setValueAtTime(0.0001, now + t); g.gain.linearRampToValueAtTime(g0, now + t + dur * 0.8); g.gain.exponentialRampToValueAtTime(0.0001, now + t + dur + 0.1);
        s.connect(f); f.connect(g); g.connect(out); s.start(now + t); s.stop(now + t + dur + 0.2);
      };
      noise(0.0, 1.65, 180, 5200, 0.55);                    // rising whoosh
      osc('sine', root / 2, 0, 3.6, 0.55);                   // sub drone
      for (let i = 0; i < 12; i++) osc('triangle', note(i % 7 + Math.floor(i / 3), 1), 0.25 + i * 0.105, 0.35, 0.16); // arpeggio climb
      osc('sine', 170, 1.68, 0.55, 0.95, comp).frequency.exponentialRampToValueAtTime(38, now + 2.2); // impact kick
      noise(1.66, 0.35, 9000, 400, 0.5, 'highpass');         // impact crash
      const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200; lp.connect(out);
      [0, 2, 4, 7].forEach((d, i) => { osc('sawtooth', note(d, 0), 1.72, 2.5, 0.07, lp, (i - 1.5) * 6); osc('triangle', note(d, 1), 1.72, 2.5, 0.08, out); });
      for (let i = 0; i < 9; i++) osc('sine', note(Math.floor(Math.random() * 10), 3), 2.2 + i * 0.2, 0.7, 0.05, rev); // sparkles
      osc('sine', 1318.5, 3.45, 1.3, 0.18); osc('sine', 2637, 3.45, 1.0, 0.07); // final chime
      master.gain.setValueAtTime(vol, now + 4.2); master.gain.linearRampToValueAtTime(0, now + 4.75);
    } catch (e) { }
  }
  function stopAudio() {
    try {
      if (master && actx) { master.gain.cancelScheduledValues(actx.currentTime); master.gain.setValueAtTime(master.gain.value, actx.currentTime); master.gain.linearRampToValueAtTime(0, actx.currentTime + 0.25); }
      const a = actx; actx = null; master = null;
      if (a) setTimeout(() => { try { const cp = a.close(); if (cp && cp.catch) cp.catch(function () { }); } catch (e) { } }, 400);
    } catch (e) { }
  }

  function finish() {
    if (!running) return;
    running = false;
    cancelAnimationFrame(raf);
    timers.forEach(clearTimeout); timers = [];
    stopAudio();
    const f = cb; cb = null;
    if (f) f();
  }

  function run(opts, done) {
    if (running) finish();
    running = true; cb = done; lockDone = false; boomDone = false;
    style = opts.style || 'draw';
    const el = $('#splash');
    el.hidden = false; el.className = ''; void el.offsetWidth; el.className = 'sp-' + style;
    $('#spt').innerHTML = 'NerdyBrowser'.split('').map((c, i) => '<span style="--i:' + i + '">' + (i >= 5 ? '<b>' + c + '</b>' : c) + '</span>').join('');
    const lines = [['shield engine', 'ONLINE'], ['blocklists', '380+ domains'], ['fingerprint', 'scrambled'], ['https-only', 'enforced'], ['trackers stopped', '0'], ['you', 'unwatched']];
    $('#spl').innerHTML = lines.map((l, i) => '<div style="--i:' + i + '">' + esc(l[0]) + '<i></i><b' + (i === 4 ? ' id="spn"' : '') + '>' + esc(l[1]) + '</b></div>').join('');
    $('#spb').style.width = '0';
    const g = setup(); void g;
    // count up the "trackers stopped" line
    timers.push(setTimeout(() => {
      const n = $('#spn'), goal = (typeof STATS !== 'undefined' && STATS.blocked) || 0, s0 = performance.now();
      if (!n) return;
      const tick = now => { const k = clamp((now - s0) / 900, 0, 1); n.textContent = Math.round(goal * k).toLocaleString(); if (k < 1 && running) requestAnimationFrame(tick); };
      requestAnimationFrame(tick);
    }, 2500));
    if (opts.sound) startAudio(clamp((opts.vol || 70) / 100, 0, 1) * 0.55, style);
    t0 = performance.now();
    raf = requestAnimationFrame(frame);
  }
  return { run, skip: finish, get running() { return running; } };
})();
