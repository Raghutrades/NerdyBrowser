# NerdyBrowser

A private Android browser. No ads, no trackers, no popups, no account, no analytics.
Built the same way as NerdyReader: a small Java shell + a local web app, built into an APK by GitHub Actions.

## Get the APK (same as NerdyReader)
1. Make a new GitHub repo called `NerdyBrowser`.
2. Upload `build-apk.yml` into `.github/workflows/` (path: `.github/workflows/build-apk.yml`).
3. Upload `NerdyBrowser-source.zip` and your photo `raghu.jpg` to the repo root.
4. Open the Actions tab and wait for the green tick. Download `NerdyBrowser.apk` from Releases (tag `latest`).
5. Install it. Every new build installs over the old one (same signing key, kept in `keystore/`).

## New in v2
- Drag the thin handles between panes to resize them (sizes are remembered). Swap, rotate and reorder panes and tabs.
- True always-full-screen: phone status bar and buttons hidden (swipe from the edge to peek). Toolbar auto-hides while scrolling, and hides fully in Full screen.
- Downloads tab with live progress, and files now save with the right name (videos as .mp4, not .bin).
- Browser-only VPN (WireGuard config, kill switch, auto-connect) and proxy/Tor (Orbot) support.
- YouTube ad skipper, your own hide rules, auto-refresh per tab, desktop-width control, immersive desktop, screen rotation lock, tab pausing.
- New animated welcome with a sound track generated inside the app (3 styles).

## What is inside
- Tabs and split layouts: 11 layouts (side by side, stacked, big + 2, 2x2, 3 columns...). Every pane is its own tab.
  Long-press a link, then Open in other pane.
- Shield: ~380 ad/tracker domains, 4 levels (Off, Standard, Strict, Ultra), per-site off switch, your own blocklist.
- Popup blocking, alert-box blocking, ad-slot hiding, cookie-banner hiding, tracking-link cleaning (utm_, fbclid, gclid...).
- HTTPS-only, no third-party cookies, fingerprint shield, WebRTC block, beacon block, Do-Not-Track + GPC, referrer control.
- Camera, microphone and location are always refused. The only Android permission is internet.
- Burn button, wipe-on-close, optional history (off by default), optional app lock (phone fingerprint/PIN), screenshot block.
- Reader mode, find in page, per-site zoom, text size, desktop site, dark page, per-tab JavaScript and image switches.
- Bookmarks with pins on the start page, export/import, 10 themes + custom accent, toolbar top or bottom, welcome animation (3 styles).
- About page with your photo.

## Where to change things
- Blocklist: `app/src/main/assets/www/data/hosts.txt` (one domain per line).
- About text: `app/src/main/assets/www/js/about.js`.
- Themes: `css/themes.css` and `THEMES` in `js/core.js`.
- Page shield script: `data/inject.js`.

## Honest limits
- It uses Android's built-in Chromium engine (WebView). No browser extensions.
- No browser can hide your IP address. Add a VPN or Android Private DNS for that.
- Ultra shield and WebRTC-off can break some sites; use the shield button to switch off per site.
- Google Safe Browsing is OFF by default (it would talk to Google). You can turn it on in Settings.
