# NerdyBrowser

A private Android browser. No ads, no trackers, no popups, no account, no analytics.
Built the same way as NerdyReader: a small Java shell + a local web app, built into an APK by GitHub Actions.

## Get the APK (same as NerdyReader)
1. Make a new GitHub repo called `NerdyBrowser`.
2. Upload `build-apk.yml` into `.github/workflows/` (path: `.github/workflows/build-apk.yml`).
3. Upload `NerdyBrowser-source.zip` and your photo `raghu.jpg` to the repo root.
4. Open the Actions tab and wait for the green tick. Download `NerdyBrowser.apk` from Releases (tag `latest`).
5. Install it. Every new build installs over the old one (same signing key, kept in `keystore/`).

## New in v3.5
- **YouTube Cinema is now the default look** on YouTube: featured carousel, Netflix rows, a numbered Top 10, a Shorts row, bottom tabs (Home, Shorts, Subs, Search, Classic) and a style sheet (gear icon: rows or grid, hide Shorts, accent colour). Fixed the bug that kept the screen from ever appearing (YouTube forbids some page-building code). Watch pages get a readable dark look. Classic gives normal YouTube back; a small switch stays on screen.
- **Save button is now part of the app, not the page.** One round button sits on the screen (drag it anywhere) when a page has a video or a big picture. Nothing is added to pages any more, so layouts cannot shift, strict sites (YouTube) cannot break it, and Pinterest-style heavy pages no longer slow down. Tap it for the quality and size list. Long-press a picture > Save image (choose size).
- YouTube: the list now also asks YouTube's app-style player for plain links, so more qualities show up. If YouTube refuses, you see a note instead of a broken list.
- Pinterest and its country sites are allowed through the shield (ads still blocked).
- Edge swipe: from the left edge = Back, from the right edge = Forward (Settings > Gestures). Pull-to-refresh only starts at the very top of a page, and not while a scrolled box inside the page is under your finger.
- New clean welcome screen (about 2 seconds, no log lines). Older styles stay in Settings > Welcome style.
- Redesigned menu: header with site and blocked count, quick row (Back, Forward, Reload, Save, Share), grouped sections. Interface style Island is now the default.

## New in v3.4 (downloader fixes)
- The Save button on every picture and video is gone. It caused clutter and slowdowns. There is now ONE small floating button (shows only when a page has a big picture or video). Tap it for the list; drag it away if it covers something. Settings > Device > Show floating Save button.
- Lighter and safer: no more watching every page's network data. Only sites known to hand video links in their data (Instagram, Facebook, X, TikTok, Reddit, Vimeo...) are read, with a strict time limit, so heavy pages like Pinterest no longer freeze or crash.
- Pinterest: pictures now list Original, 736, 474 and 236 sizes; Pinterest video pins are found too.
- Fixed: the floating button was placed off-screen. Pinterest is now treated like a web-app site (fingerprint shield, WebRTC block and similar tweaks relaxed; ads still blocked). Settings footer now says "1.0.1 (build 2)" so you can tell the new build is installed.
- Menu > Media on page now also uses the page's own list of loaded files, and lists the pictures you can see first.

## New in v3.3
- **Save buttons on pictures and videos.** A small Save button sits on the bottom edge of big pictures and on the top corner of videos, also inside embedded players (iframes). Tap it and a list opens with every quality and its size: 1080p, 720p, 480p..., audio only, and pictures in their original size plus smaller copies (1600 / 1024 / 640 px). Tap one to download.
- **Menu > Media on page** lists everything found on the page, for players where the button cannot show (full screen, custom players).
- Where the links come from: the player's own file, `<source>` tags, srcset, the network requests a page makes (mp4, webm, mp3, m4a, HLS .m3u8), and the data that sites hand their players (Instagram, X, TikTok, Facebook, Reddit, YouTube when it exposes plain links).
- HLS streams are joined on the phone into one MP4. Separate video + sound files are joined (no re-encoding) with Android's own muxer.
- When the VPN is on, these downloads run inside the app so they go through the VPN too (Android's download manager would bypass it).
- Settings > Device: **Media downloader** (master switch) and **Show Save buttons**.
- VPN > Advanced > **Create a config for me**: makes a fresh free Cloudflare WARP WireGuard config, or a config for your own server (keys are made on the phone and you get the block to add on the server). Copy / Share buttons, and a one-paste server setup script (`tools/wg-server-setup.sh`) for a small Ubuntu cloud server.

Limits of the media downloader (honest list): DRM-protected streams (Netflix, Hotstar, Spotify and similar) are never saved. DASH (.mpd) streams and live streams are not supported. YouTube hides most of its stream links behind a cipher; only links it exposes in plain form are listed, and they can be slow. Instagram/Facebook/TikTok change their data formats often, so these can stop working after a site update. Some sites refuse downloads outside their own page. Only save what you are allowed to keep: many sites forbid downloading in their terms.

## New in v3.2
- New 3D owl logo for the app icon (plus a themed monochrome icon), the start page and the welcome screen. New Warp welcome animation: starfield, particles forming the owl, aurora light, blinking eyes, light sweep. Settings > Welcome style.
- Interface styles: Classic, Glass, Island, Neon (Settings > Appearance), and two new dark themes, Aurora and Ember.
- Immersive desktop: leaving it puts the screen back to auto-rotate by itself. New Rotate mode "sensor" follows the phone's sensor even when system auto-rotate is off.
- Web apps: Menu > Add to home screen (or the screen icon on a bookmark) puts a shortcut on your phone home screen. It opens straight into that site, full screen with no browser bars. Back goes back in the site, and leaves the app at the first page.
- YouTube Cinema (Settings > Shield > YouTube Cinema switch): a full Netflix-style screen for YouTube. Hero banner, rows of videos, a separate Shorts row, search, categories, endless loading, built from your own feed (home, subscriptions, search). Pick Classic | Cinema | Shorts at the bottom; Classic is normal YouTube. Watch pages get a dark look with Shorts hidden.
- Web-app mode: Spotify, Netflix, Hotstar/JioCinema, SoundCloud, Deezer, WhatsApp Web, Discord, Twitch, Meet and similar sites now work. Ads and trackers are still blocked there; only the tweaks that break playback/login are relaxed (fingerprint shield, WebRTC block, 3rd-party cookie block, autoplay block, Ultra script blocking). Add your own sites in Settings > Shield > "My own web-app sites".
- DRM playback (Widevine) is now allowed. Before, every permission request was refused, which stopped protected music/video. Camera, microphone and location are still always refused.
- Spotify always stays on the phone layout, because its player only plays there. WhatsApp Web opens in desktop layout automatically.
- Music/video tabs are no longer paused when you switch tabs or leave the app.

## New in v3.1
- Adding accounts: the browser now looks like plain Chrome to websites (no app marks, no phone model), sign-in pages (Google, Microsoft, Apple, Yahoo) are left untouched, and logins now stay across restarts (Settings > Data > Stay signed in).
- Import bookmarks from other browsers/apps: Bookmarks > Import (HTML/JSON/CSV/list of links). Sharing a link from any app to NerdyBrowser asks: Open or Save as bookmark.
- Menu > Open in other app.

## New in v3
- Faster and lighter: opening menus no longer reflows the page, tab switching reuses the same view, big panels pause pages so the toolbar never fights them for the engine.
- One-tap VPN: sets itself up (free Cloudflare WARP, no account), only this browser uses it, auto-connects at launch, optional kill switch. Advanced: your own WireGuard config or a proxy.
- Smart downloads: sorted into Downloads/NerdyBrowser/<type>, correct file names, live speed + ETA + speed graph, filters, search, retry, Wi-Fi-only option.
- Gestures: swipe the address bar to switch tabs, pull down to refresh. Options row hides/shows with the small arrow; tab strip shown by default.
- Hide element: tap anything on a page to hide it for good on that site. Blocklist grew to ~570 domains. Notification-prompt spam blocked.

## New in v2
- Drag the thin handles between panes to resize them (sizes are remembered). Swap, rotate and reorder panes and tabs.
- True always-full-screen: phone status bar and buttons hidden (swipe from the edge to peek). Toolbar auto-hides while scrolling, and hides fully in Full screen.
- Downloads tab with live progress, and files now save with the right name (videos as .mp4, not .bin).
- Browser-only VPN (WireGuard config, kill switch, auto-connect) and proxy/Tor (Orbot) support.
- YouTube ad skipper, your own hide rules, auto-refresh per tab, desktop-width control, immersive desktop, screen rotation lock, tab pausing.
- New animated welcome with a sound track generated inside the app (3 styles).

## What is inside
- Tabs and split layouts: 11 layouts (side by side, stacked, big + 2, 2x2, 3 columns...). Every pane is its own tab.
  Long-press a link, then Open in other pane.
- Shield: ~380 ad/tracker domains, 4 levels (Off, Standard, Strict, Ultra), per-site off switch, your own blocklist.
- Popup blocking, alert-box blocking, ad-slot hiding, cookie-banner hiding, tracking-link cleaning (utm_, fbclid, gclid...).
- HTTPS-only, no third-party cookies, fingerprint shield, WebRTC block, beacon block, Do-Not-Track + GPC, referrer control.
- Camera, microphone and location are always refused. The only Android permission is internet.
- Burn button, wipe-on-close, optional history (off by default), optional app lock (phone fingerprint/PIN), screenshot block.
- Reader mode, find in page, per-site zoom, text size, desktop site, dark page, per-tab JavaScript and image switches.
- Bookmarks with pins on the start page, export/import, 10 themes + custom accent, toolbar top or bottom, welcome animation (3 styles).
- About page with your photo.

## Where to change things
- Blocklist: `app/src/main/assets/www/data/hosts.txt` (one domain per line).
- About text: `app/src/main/assets/www/js/about.js`.
- Themes: `css/themes.css` and `THEMES` in `js/core.js`.
- Page shield script: `data/inject.js`.

## Honest limits
- It uses Android's built-in Chromium engine (WebView). No browser extensions.
- No browser can hide your IP address. Add a VPN or Android Private DNS for that.
- Ultra shield and WebRTC-off can break some sites; use the shield button to switch off per site.
- Google Safe Browsing is OFF by default (it would talk to Google). You can turn it on in Settings.
