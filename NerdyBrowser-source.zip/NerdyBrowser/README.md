# NerdyBrowser

A private Android browser. No ads, no trackers, no popups, no account, no analytics.
Built the same way as NerdyReader: a small Java shell + a local web app, built into an APK by GitHub Actions.

## Get the APK (same as NerdyReader)
1. Make a new GitHub repo called `NerdyBrowser`.
2. Upload `build-apk.yml` into `.github/workflows/` (path: `.github/workflows/build-apk.yml`).
3. Upload `NerdyBrowser-source.zip` and your photo `raghu.jpg` to the repo root.
4. Open the Actions tab and wait for the green tick. Download `NerdyBrowser.apk` from Releases (tag `latest`).
5. Install it. Every new build installs over the old one (same signing key, kept in `keystore/`).

## New in v3.2
- New 3D owl logo for the app icon (plus a themed monochrome icon), the start page and the welcome screen. New Warp welcome animation: starfield, particles forming the owl, aurora light, blinking eyes, light sweep. Settings > Welcome style.
- Interface styles: Classic, Glass, Island, Neon (Settings > Appearance), and two new dark themes, Aurora and Ember.
- Immersive desktop: leaving it puts the screen back to auto-rotate by itself. New Rotate mode "sensor" follows the phone's sensor even when system auto-rotate is off.
- Web apps: Menu > Add to home screen (or the screen icon on a bookmark) puts a shortcut on your phone home screen. It opens straight into that site, full screen with no browser bars. Back goes back in the site, and leaves the app at the first page.
- YouTube Cinema (Settings > Shield > YouTube Cinema switch): a full Netflix-style screen for YouTube. Hero banner, rows of videos, a separate Shorts row, search, categories, endless loading, built from your own feed (home, subscriptions, search). Pick Classic | Cinema | Shorts at the bottom; Classic is normal YouTube. Watch pages get a dark look with Shorts hidden.
- Web-app mode: Spotify, Netflix, Hotstar/JioCinema, SoundCloud, Deezer, WhatsApp Web, Discord, Twitch, Meet and similar sites now work. Ads and trackers are still blocked there; only the tweaks that break playback/login are relaxed (fingerprint shield, WebRTC block, 3rd-party cookie block, autoplay block, Ultra script blocking). Add your own sites in Settings > Shield > "My own web-app sites".
- DRM playback (Widevine) is now allowed. Before, every permission request was refused, which stopped protected music/video. Camera, microphone and location are still always refused.
- Spotify always stays on the phone layout, because its player only plays there. WhatsApp Web opens in desktop layout automatically.
- Music/video tabs are no longer paused when you switch tabs or leave the app.

## New in v3.1
- Adding accounts: the browser now looks like plain Chrome to websites (no app marks, no phone model), sign-in pages (Google, Microsoft, Apple, Yahoo) are left untouched, and logins now stay across restarts (Settings > Data > Stay signed in).
- Import bookmarks from other browsers/apps: Bookmarks > Import (HTML/JSON/CSV/list of links). Sharing a link from any app to NerdyBrowser asks: Open or Save as bookmark.
- Menu > Open in other app.

## New in v3
- Faster and lighter: opening menus no longer reflows the page, tab switching reuses the same view, big panels pause pages so the toolbar never fights them for the engine.
- One-tap VPN: sets itself up (free Cloudflare WARP, no account), only this browser uses it, auto-connects at launch, optional kill switch. Advanced: your own WireGuard config or a proxy.
- Smart downloads: sorted into Downloads/NerdyBrowser/<type>, correct file names, live speed + ETA + speed graph, filters, search, retry, Wi-Fi-only option.
- Gestures: swipe the address bar to switch tabs, pull down to refresh. Options row hides/shows with the small arrow; tab strip shown by default.
- Hide element: tap anything on a page to hide it for good on that site. Blocklist grew to ~570 domains. Notification-prompt spam blocked.

## New in v2
- Drag the thin handles between panes to resize them (sizes are remembered). Swap, rotate and reorder panes and tabs.
- True always-full-screen: phone status bar and buttons hidden (swipe from the edge to peek). Toolbar auto-hides while scrolling, and hides fully in Full screen.
- Downloads tab with live progress, and files now save with the right name (videos as .mp4, not .bin).
- Browser-only VPN (WireGuard config, kill switch, auto-connect) and proxy/Tor (Orbot) support.
- YouTube ad skipper, your own hide rules, auto-refresh per tab, desktop-width control, immersive desktop, screen rotation lock, tab pausing.
- New animated welcome with a sound track generated inside the app (3 styles).

## What is inside
- Tabs and split layouts: 11 layouts (side by side, stacked, big + 2, 2x2, 3 columns...). Every pane is its own tab.
  Long-press a link, then Open in other pane.
- Shield: ~380 ad/tracker domains, 4 levels (Off, Standard, Strict, Ultra), per-site off switch, your own blocklist.
- Popup blocking, alert-box blocking, ad-slot hiding, cookie-banner hiding, tracking-link cleaning (utm_, fbclid, gclid...).
- HTTPS-only, no third-party cookies, fingerprint shield, WebRTC block, beacon block, Do-Not-Track + GPC, referrer control.
- Camera, microphone and location are always refused. The only Android permission is internet.
- Burn button, wipe-on-close, optional history (off by default), optional app lock (phone fingerprint/PIN), screenshot block.
- Reader mode, find in page, per-site zoom, text size, desktop site, dark page, per-tab JavaScript and image switches.
- Bookmarks with pins on the start page, export/import, 10 themes + custom accent, toolbar top or bottom, welcome animation (3 styles).
- About page with your photo.

## Where to change things
- Blocklist: `app/src/main/assets/www/data/hosts.txt` (one domain per line).
- About text: `app/src/main/assets/www/js/about.js`.
- Themes: `css/themes.css` and `THEMES` in `js/core.js`.
- Page shield script: `data/inject.js`.

## Honest limits
- It uses Android's built-in Chromium engine (WebView). No browser extensions.
- No browser can hide your IP address. Add a VPN or Android Private DNS for that.
- Ultra shield and WebRTC-off can break some sites; use the shield button to switch off per site.
- Google Safe Browsing is OFF by default (it would talk to Google). You can turn it on in Settings.
